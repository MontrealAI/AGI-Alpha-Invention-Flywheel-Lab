"""Portable FRONTIER OMEGA execution and evaluation."""
