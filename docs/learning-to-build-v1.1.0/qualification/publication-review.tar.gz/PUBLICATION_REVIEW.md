# Learning to Build 1.1.0: separate publication review

Review recorded: 2026-11-08T00:21:12.755649+00:00

## Scope and independence

A separate assistant agent reviewed the manuscript, source/results binding,
rendering, release workflow and extracted-package operation. It did not author
the scientific candidate or the manuscript under review. It did author the
narrow installer boundary repair and the browser QA script. Another agent in
the same team reviewed the browser script and its failure handling. Neither
review is an external audit, a laboratory acceptance or fresh scientific
confirmation.

The checkout HEAD at this checkpoint is `7f08da58f356e04fba6b18952b1fe66f4a9e3e8f`. Local continuation edits are
present, so the following file hashes, rather than HEAD alone, bind this review:

| Artifact | SHA-256 |
| --- | --- |
| Canonical 38-page PDF | `aa537cc769148bd287e34d239284b658716464686220912ef1a54eacf60c214c` |
| Versioned HTML reader | `d2895eb29baa2c53b127936787ac11983c7738124f494a3d782aec98ebd9318b` |
| Construction results JSON | `c7653971b95506093a9fedb1b1a0f18e14b78aa253e941cd4a0111e33f929ef8` |
| Browser QA script | `4901680529544f61b706b3da167a82a667e2f06a4c2a97e4ce1762b627eea1e4` |

## Scientific narrative and PDF rendering

No substantive claim inflation was found in the reviewed narrative. It preserves
the classical nucleus validation count failure, all six successor strategies
selecting the same recipe, the whole-cell boundary failures, and zero demonstrated
primary evaluation savings. It separates the fixed pretrained specialist's
source qualification from successor qualification and retained-method advantage.
It identifies exposed fields, unknown pretraining overlap, reference-assisted
oracle inputs and the limited causal interpretation of that diagnostic.

Measured execution costs are separated from unknown or excluded setup,
acquisition, evaluation, authoring, human work, historical work, pretraining and
monetary costs. The publication projection is not described as a pass of the
original rejected raw tree.

All 38 PDF pages were rendered and visually inspected. No clipping, overlap,
broken result table, figure/caption problem or missing reference was observed.
The canonical-source verifier, finite-study check and 22 website structural
checks passed at the prior review checkpoint. The exact final candidate still
requires its own publication binding and required gates.

## Extracted installer finding and repair

The prior extracted-package gate failed because an unrelated enclosing Git
workspace was mistaken for the publication's owning repository. Its original
FAILED receipt and all eleven referenced command logs remain unchanged in the
compact setup-boundary evidence packet. The repair distinguishes the canonical
checkout from an extracted source edition and preserves absolute-path,
symlink and worktree protections.

Seven focused tests passed in normal and optimized Python. Setup from a copied
candidate inside the enclosing Git workspace passed using verified cached
assets (7.4250 seconds wall; 7.3627 seconds recorded parent/command CPU). An actual
one-field specialist operation reproduced the retained prediction bytes
(53.1238 seconds wrapper wall; 52.2477 seconds instrument CPU). This is exposed
reproduction, not a new scientific result or a substitute for operating the
final downloaded archive.

## Authored-reader browser QA

`scripts/verify_learning_reader.cjs` uses only Node built-ins and an installed
Chrome. It reads the local versioned HTML, PDF and evidence image, opens a new
browser profile, and writes to a new output directory. It does not edit product
files, install dependencies, reuse signed-in profiles or follow remote links.

It checks the title and edition, the displayed PDF hash, source/release link
targets, actual lazy-image decoding, strict absence of horizontal document
overflow, and keyboard opening/closing of all nine disclosures. It captures the
hero, evidence and downloads at 1440 × 1000 desktop and 390 × 844 mobile viewport
settings. Receipts bind input hashes, browser/version identity, check outcomes,
PNG hashes/dimensions and elapsed time. Existing outputs are never overwritten;
startup, abnormal shutdown and cleanup failures retain a failed receipt.

The separate static reviewer found a potential shutdown hang and cleanup path
that could prevent the failure receipt. The corrected script bounds browser
shutdown, cleans only its own spawned process group, releases inherited pipe
handles, records cleanup errors, and fails on an abnormal exit. A count-only
disclosure-presence check was also strengthened to identify method, French and
citation disclosures. The reviewer rechecked these changes and reported no
remaining substantive static finding.

Syntax, help, explicit missing-browser handling, source/output separation and
failed-output preservation passed on the script hash above. **No Chrome process
was launched locally.** The local environment's earlier socket policy block was
not retried or escalated. Actual CDP execution, browser rendering and screenshots
remain pending on the authorized standard Ubuntu Actions runner.

Run from the repository with the three versioned reader inputs present:

```bash
node scripts/verify_learning_reader.cjs \
  --site "$GITHUB_WORKSPACE/docs/research" \
  --output "$RUNNER_TEMP/learning-reader-browser-qa"
```

Expected output: `READER_QA.json`, browser logs, and six PNGs named
`desktop-hero`, `desktop-evidence`, `desktop-downloads`, `mobile-hero`,
`mobile-evidence` and `mobile-downloads`. A successful run exits 0 and records
PASS. Upload the output even on failure and inspect all screenshots before
integration. The script must be included in sparse checkout.

This QA tests one Chrome engine and two emulated viewport sizes. It does not
establish other-browser/device compatibility, remote download availability,
embedded PDF plugin rendering, live publication or scientific validity. The
live reader and actual release assets still require the established final
publication checks.

## Final 39-page candidate addendum

The earlier 38-page PDF review above is a preserved checkpoint, **not a claim
that the same rendered pages represent the final candidate**. The lead's final
canonical manuscript has 39 pages and SHA-256:

`127888a4586f33066608cf9408f692edb2d3b8ea4d1fb9d8dc9a63ccd9355754`

The lead reports visually reviewing all 39 revised pages, then adding an
abstract sentence naming the order replay and failed frozen composition. The
final abstract page was separately rendered and inspected; the other 38 final
page rasters match the reviewed revised version. The lead's source-bound
`PDF_VISUAL_REVIEW.json` records this review. This agent verified the final PDF
hash and read that receipt, but did not repeat the final 39-page visual review.
The build was reported clean without warnings. The initial review's scientific
scope findings remain a checkpoint; the lead owns the final revised narrative
and its added diagnostic evidence.

The browser QA script is frozen at SHA-256
`4901680529544f61b706b3da167a82a667e2f06a4c2a97e4ce1762b627eea1e4`.
Its static validation used the explicitly recorded earlier reader/PDF/image
inputs and is not a visual pass of either reader revision. It accepts the final
three local versioned inputs without requiring other research-library files:
`file://` navigation opens the fixed local HTML, PDF hrefs resolve against that
local URL, and the displayed PDF digest must match the actual local PDF.
Remote page requests are blocked; other local/remote page links are inspected
as targets and are not followed. The actual candidate browser run and screenshot
inspection remain pending in the authorized GitHub Actions workflow.
