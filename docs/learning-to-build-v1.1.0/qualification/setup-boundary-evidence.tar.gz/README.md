# Extracted-source setup failure and repair

The original candidate gate remains **FAILED**. Its `CANDIDATE_VERIFICATION.json`
and all eleven referenced command logs are preserved byte for byte in
`prior-failed/`; their hashes match that original receipt. The first ten commands
succeeded. The last command failed before installation or inference because
`setup_incumbent.py` treated an unrelated enclosing `/workspace/.git` as the
publication's own checkout and rejected sibling runtime and cache directories.

`source-before/setup_incumbent.py` is the exact failed extracted installer.
`source-after/` preserves the repaired installer, its seven focused regression
tests and the updated setup guidance. The repair protects a canonical repository
checkout as a whole, or the extracted edition itself when used from an archive.
It preserves absolute-path and resolved-symlink checks and handles Git worktrees.

Both normal and optimized Python test runs passed all seven cases. A copied
candidate edition inside the same enclosing Git workspace then verified its
existing pinned runtime and three cached upstream artifacts, passed preflight
and the frozen no-inference contract, and became `READY_FOR_REPRODUCTION`.
No dependency installation or download was needed for this repair check.

The candidate also performed real inference on the first official BBBC039 test
metadata entry. The resulting prediction matched retained bytes exactly. This
was one exposed field and demonstrates operation of the packaged instrument; it
is **not fresh scientific confirmation**, a new qualification result or a learning
advantage. The operation receipt and detailed instrument receipt retain the
input, output, evaluator-source and model hashes and measured timings. Raw input
images and model weights are intentionally not copied into this small packet;
the source package's acquisition and setup instructions identify them.

`QUALIFICATION.json` binds the candidate construction files, commands, source
snapshots, measured setup/operation/test times and limitations. `SHA256SUMS`
binds every other file in this packet. Monetary billing and human work remain
unknown. Do not add these repair checks to the original 116-field inference
cost as if they were part of that scientific comparison.

## Reproduction

From an extracted edition containing the repaired source:

```bash
python -B -m unittest discover -s construction -p test_setup.py -v
python -O -B -m unittest discover -s construction -p test_setup.py -v
python -B construction/setup_incumbent.py --skip-install \
  --venv /absolute/existing/pinned-venv \
  --cache /absolute/existing/model-cache \
  --data-cache /absolute/existing/data-cache \
  --output /absolute/new/setup-receipt
/absolute/existing/pinned-venv/bin/python -B construction/release_operate.py \
  --origin candidate --cache /absolute/existing/data-cache \
  --weights /absolute/existing/model-cache/cpdino-vitb \
  --incumbent-evidence /absolute/extracted/evidence/incumbent \
  --output /absolute/new/operation-receipt
```

Use new output directories. The cached runtime and assets must match the frozen
registration. Omit `--skip-install` for the documented installer path when a new
pinned runtime is needed. The full exact commands and original absolute paths
remain in the preserved receipts. Final release rebinding, exact-candidate CI
and operation from actual downloaded release assets are separate required gates.

This review was performed by another agent in the same assistant session. It
authored this narrow installer repair, so the main research team must review
the code change; this packet is not an external audit.
