#!/usr/bin/env python3
"""Retain read-only review and reconstruction qualification receipts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/fad12dbaa4fb/learning-to-build')
SOURCE = ROOT / 'docs/learning-to-build-v1.1.0/construction'
OBSERVED = Path('/workspace/scratch/fad12dbaa4fb/ltb-reproduction-20261107')
WORK = Path(__file__).resolve().parent
PYTHON = '/workspace/scratch/fad12dbaa4fb/ltb-venv/bin/python'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, contents):
    with (WORK / name).open('x') as stream:
        json.dump(contents, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def command(name, argv):
    started = time.perf_counter()
    before = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (WORK / (name + '.stdout')).open('xb') as out, (WORK / (name + '.stderr')).open('xb') as err:
        result = subprocess.run(argv, cwd=SOURCE, stdout=out, stderr=err)
    after = resource.getrusage(resource.RUSAGE_CHILDREN)
    write(name + '.command.json', {
        'command': argv, 'cwd': str(SOURCE), 'exit_code': result.returncode,
        'actual_child_cpu_seconds': after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime,
        'actual_wall_seconds': time.perf_counter() - started,
        'stdout_sha256': digest(WORK / (name + '.stdout')),
        'stderr_sha256': digest(WORK / (name + '.stderr')),
        'scope': 'Command boundary; inner process timings are nested and must not be added to this boundary.'})
    if result.returncode != 0:
        raise RuntimeError('Review command failed; retained logs: ' + name)


def independent_inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('Unexpected symlink')
        if path.is_file():
            contents = path.read_bytes()
            result[path.relative_to(root).as_posix()] = {'bytes': len(contents),
                                                       'sha256': hashlib.sha256(contents).hexdigest()}
    return result


def main():
    checker_output = json.loads((WORK / 'LIMITED_SAVED_OUTPUT_AUDIT.stdout.json').read_text())
    for name, expected in checker_output['source_bindings'].items():
        if digest(SOURCE / name) != expected:
            raise ValueError('Saved-output audit source mismatch: ' + name)
    if digest(SOURCE / 'check.py') != checker_output['verifier_sha256']:
        raise ValueError('Saved-output audit checker mismatch')
    write('LIMITED_SAVED_OUTPUT_AUDIT_CAPTURE.json', {
        'schema': 'learning-to-build/reviewer-tool-output-capture/v1',
        'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
        'tool_session': 87725, 'observed_exit_code': 0,
        'command': [PYTHON, '-B', str(SOURCE / 'check.py'), '--cache',
                    '/workspace/scratch/fad12dbaa4fb/ltb-data-cache', '--classical',
                    str(OBSERVED / 'classical-projection'), '--incumbent', str(OBSERVED / 'incumbent'),
                    '--saved-masks-only'],
        'output': 'LIMITED_SAVED_OUTPUT_AUDIT.stdout.json',
        'output_sha256': digest(WORK / 'LIMITED_SAVED_OUTPUT_AUDIT.stdout.json'),
        'capture_method': 'JSON returned in full by write_stdin for completed session87725; copied into this file with JSON whitespace normalized. No --output file was requested from check.py. This is an assistant-preserved tool-output record, not an original on-disk checker receipt.',
        'scope': 'Limited saved-output audit:312 saved fields rescored,136 unique classical predictions regenerated. No donor/calibration prediction replay and no neural inference replay.',
        'actual_cpu_seconds_reported_by_checker': checker_output['actual_cpu_seconds'],
        'actual_wall_seconds_reported_by_checker': checker_output['actual_wall_seconds'],
        'source_bindings_rechecked_against_current_bytes': True,
        'independence': 'Same-session internal reviewer did not author the frozen experiment or checker. Reviewer authored projection.py later; no independent-review claim for own utility.',
        'fresh_confirmation': False})
    command('projection-tests', [PYTHON, '-B', '-m', 'unittest', 'test_projection', '-v'])
    command('setup-review-tests', [PYTHON, '-B', '-m', 'unittest', 'test_setup', '-v'])
    command('evidence-extract', [PYTHON, '-B', str(SOURCE / 'evidence.py'), '--extract', str(WORK / 'extracted')])
    command('projection-reconstruct', [PYTHON, '-B', str(SOURCE / 'projection.py'), '--evidence',
                                       str(WORK / 'extracted'), '--reconstruct', str(WORK / 'raw-reconstructed')])
    command('projection-verify', [PYTHON, '-B', str(SOURCE / 'projection.py'), '--evidence', str(WORK / 'extracted')])
    started, cpu = time.perf_counter(), time.process_time()
    original = independent_inventory(OBSERVED / 'classical')
    reconstructed = independent_inventory(WORK / 'raw-reconstructed')
    if original != reconstructed or len(original) != 416:
        raise ValueError('Reconstructed raw tree does not equal original416files')
    sys.path.insert(0, str(SOURCE))
    import check
    root = WORK / 'raw-reconstructed'
    ledger = json.loads((root / 'RUN_STATE.json').read_text())
    expected = {'PROTOCOL.json', 'REGISTRATION.json', 'RESULTS.json', 'RUN_STATE.json', 'STATUS.json'}
    recorded_stage_hashes = {}
    for stage, record in ledger['stages'].items():
        for name, sha in record['files'].items():
            full = stage + '/' + name
            expected.add(full)
            recorded_stage_hashes[full] = sha
    verifier = check.Evidence(root)
    for name in sorted(expected):
        got = verifier.hash(name)
        if name in recorded_stage_hashes and got != recorded_stage_hashes[name]:
            raise ValueError('Recorded canonical stage file changed')
    extras = sorted(set(verifier.actual) - expected)
    if len(expected) != 278 or len(extras) != 138:
        raise ValueError('Unexpected canonical/residual count')
    try:
        verifier.inventory()
    except check.VerificationError as error:
        if not str(error).startswith('Unaccounted evidence files: '):
            raise
        rejection = str(error)
    else:
        raise ValueError('Original raw strict inventory unexpectedly accepted')
    write('RAW_RECONSTRUCTION_INDEPENDENT_CHECK.json', {
        'schema': 'learning-to-build/raw-reconstruction-review/v1', 'status': 'VERIFIED_BYTE_RECONSTRUCTION',
        'source_utility_sha256': digest(SOURCE / 'projection.py'), 'checker_sha256': digest(SOURCE / 'check.py'),
        'original_raw_files': len(original), 'reconstructed_raw_files': len(reconstructed),
        'original_and_reconstructed_relative_paths_and_bytes_equal': True,
        'strict_inventory_status': 'REJECTED_EXPECTED', 'strict_inventory_error': rejection,
        'canonical_files_derived_from_run_state': len(expected), 'unaccounted_residual_files': len(extras),
        'unaccounted_relative_paths': extras,
        'numerical_replay_performed_this_check': False,
        'scope': 'Independent byte comparison to preserved original rawtree and actual check.Evidence.inventory gate. Canonical used-file set derived from retained RUN_STATE stage inventories, not from projection utility. This is inventory-component verification, not a new complete scientific replay.',
        'actual_cpu_seconds': time.process_time() - cpu,
        'actual_wall_seconds': time.perf_counter() - started})
    write('SETUP_REPAIR_REVIEW.json', {
        'schema': 'learning-to-build/internal-review/v1', 'status': 'ACCEPTED',
        'independence': 'Separate same-session internal assistant reviewer; did not author setup_incumbent.py repair, test_setup.py, or INCUMBENT_SETUP.md. Not an external audit.',
        'files': {name: digest(SOURCE / name) for name in ('setup_incumbent.py', 'test_setup.py', 'INCUMBENT_SETUP.md')},
        'reviewed_change': 'source_boundary selects the owning canonical checkout/worktree only; an ambient enclosing Git marker does not expand an extracted source edition boundary. Resolved paths into protected source remain rejected.',
        'focused_regression_tests': 7, 'test_receipt': 'setup-review-tests.command.json',
        'substantive_findings': [],
        'limitations': 'This review did not repeat environment installation or model inference. Source repair and path tests do not replace source-bound retained runtime/preflight/operation receipts.'})
    print(json.dumps({'status': 'COMPLETE', 'work': str(WORK), 'files_reconstructed': 416,
                      'raw_strict_inventory': 'REJECTED_EXPECTED'}))


if __name__ == '__main__':
    main()
