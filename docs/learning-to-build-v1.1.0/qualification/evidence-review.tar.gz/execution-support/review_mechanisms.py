#!/usr/bin/env python3
"""Separate reviewer checks of exposed diagnostic and single repair evidence."""
import time
START, CPU = time.perf_counter(), time.process_time()
from datetime import datetime
import hashlib
import io
import json
from pathlib import PurePosixPath
import sys
import tarfile

import review_projection as review


def require(condition, message):
    if not condition:
        raise ValueError(message)


def content_id(contents):
    return {'bytes': len(contents), 'sha256': hashlib.sha256(contents).hexdigest()}


def archive(kind):
    base = review.SOURCE / kind
    evidence = json.loads((base / 'EVIDENCE.json').read_text())
    files = {}
    archive_bytes = (base / 'OBSERVED_RUN.tar.gz').read_bytes()
    require(content_id(archive_bytes) == evidence['observed_run_archive'], kind + ' archive identity')
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as stored:
        for member in stored:
            path = PurePosixPath(member.name)
            require(member.isfile() and not path.is_absolute() and '..' not in path.parts
                    and path.as_posix() == member.name and member.name not in files,
                    'Unsafe or duplicate diagnostic member')
            contents = stored.extractfile(member).read()
            require(len(contents) == member.size, 'Archive member length')
            files[member.name] = contents
    require(len(files) == evidence['archived_files'], kind + ' archive coverage')
    require(files['RESULTS.json'] == (base / 'RESULTS.json').read_bytes(), kind + ' loose result differs')
    require(content_id(files['RESULTS.json']) == evidence['results'], kind + ' result identity')
    require(content_id(files['PROCESS_COST.json']) == evidence['process_cost'], kind + ' process cost identity')
    if kind == 'diagnostics':
        inventory = json.loads(files['OUTPUT_INVENTORY.json'])
        require(set(inventory) | {'OUTPUT_INVENTORY.json', 'RESULTS.json', 'PROCESS_COST.json'} == set(files),
                'Diagnostic output inventory coverage')
        require(all(content_id(files[name]) == expected for name, expected in inventory.items()),
                'Diagnostic output inventory byte identity')
    result = json.loads(files['RESULTS.json'])
    freeze = json.loads((base / 'FREEZE.json').read_text())
    registration_bytes = (base / 'PREREGISTRATION.json').read_bytes()
    registration = json.loads(registration_bytes)
    require(freeze['preregistration'] == content_id(registration_bytes), kind + ' freeze/registration binding')
    require(result['registration_sha256'] == content_id(registration_bytes)['sha256'], kind + ' result/registration binding')
    require(datetime.fromisoformat(freeze['registered_at_utc']) <= datetime.fromisoformat(result['started_at_utc']),
            kind + ' recorded freeze timing')
    bindings = [('diagnostic_program', 'program', 'run.py')] if kind == 'diagnostics' else [
        ('composition_program', 'composition_program', 'composition.py'),
        ('evaluation_program', 'evaluation_program', 'evaluate.py')]
    for freeze_key, evidence_key, name in bindings:
        require(content_id((base / name).read_bytes()) == freeze[freeze_key] == evidence[evidence_key],
                kind + ' source freeze binding')
    return result, registration, files


def main():
    sys.path.insert(0, str(review.SOURCE))
    import check
    import numpy as np
    from PIL import Image
    protocol = json.loads((review.SOURCE / 'PROTOCOL-amendment-2.json').read_text())
    public = check.PublicData('/workspace/scratch/fad12dbaa4fb/ltb-data-cache', protocol)
    accessed = []
    original_pixels = public.pixels
    def pixels(key, name, include_mode=False):
        accessed.append({'archive': key, 'member': name})
        return original_pixels(key, name, include_mode)
    public.pixels = pixels
    fields = protocol['data']['bbbc007']['calibration_ids']
    references = {name: public.case007(name) for name in fields}
    diagnostic, diagnostic_registration, diagnostic_files = archive('diagnostics')
    repair, repair_registration, repair_files = archive('repair')
    require(repair['registration_sha256'] == 'e315d050faa5515a222bf01d696ff90ba29554b69df8ed978be5a2ee29ff5b64',
            'Requested repair registration differs')
    checked = []
    condition_sets = [('diagnostics', diagnostic['numerical_endpoints']['factorial']['conditions'], diagnostic_files),
                      ('repair', repair['numerical_endpoints']['cohorts'], repair_files)]
    for kind, conditions, files in condition_sets:
        for condition, record in conditions.items():
            require({row['field'] for row in record['rows']} == set(fields) and len(record['rows']) == 4,
                    'Unexpected calibration mask coverage')
            scores = []
            for row in record['rows']:
                contents = files[row['mask_path']]
                require(hashlib.sha256(contents).hexdigest() == row['mask_sha256'], 'Encoded prediction identity')
                with Image.open(io.BytesIO(contents)) as image:
                    labels = np.asarray(image).copy()
                label_bytes = json.dumps(list(labels.shape), separators=(',', ':')).encode() + b'\n'
                label_bytes += labels.astype('<u4').tobytes(order='C')
                require(hashlib.sha256(label_bytes).hexdigest() == row['label_array_sha256'], 'Decoded prediction identity')
                metrics = check.score(labels, references[row['field']].truth)
                check.same(metrics, {key: row[key] for key in metrics}, 'separate reference decode/score')
                scores.append({'field': row['field'], **metrics})
            summary = check.aggregate(scores)
            check.same(summary, record['summary'], 'separate field-mean aggregation')
            gate = check.qualified(summary, 'cells', protocol['criteria'])
            declared_gate = record['numerical_calibration_gate_met'] if kind == 'diagnostics' else record['numerical_cohort_gate_met']
            require(gate is declared_gate, 'Frozen calibration gate differs')
            checked.append({'kind': kind, 'condition': condition, 'masks_rescored': 4,
                            'mean_internal_boundary_f1': summary['mean_internal_boundary_f1'],
                            'mean_foreground_dice': summary['mean_foreground_dice'],
                            'mean_relative_count_error': summary['mean_relative_count_error'],
                            'numerical_calibration_gate_met': gate})
    endpoints = repair['numerical_endpoints']
    require(endpoints['status'] == 'COMPLETED_NEGATIVE_CALIBRATION_STOP' and endpoints['test_fields_scored'] == 0
            and endpoints['new_raw_field_neural_operation_performed'] is False
            and endpoints['candidate_completely_qualifies_on_exposed_cohorts'] is False
            and set(endpoints['cohorts']) == {'calibration'}, 'Repair stop/qualification differs')
    expected_repair_files = {'INVOCATION.json', 'RESULTS.json', 'PROCESS_COST.json', 'calibration/metrics.csv'}
    expected_repair_files |= {row['mask_path'] for row in endpoints['cohorts']['calibration']['rows']}
    require(set(repair_files) == expected_repair_files, 'Unreported repair execution output')
    original = review.WORK / 'extracted/incumbent/successor/calibration'
    historical = endpoints['cohorts']['calibration']['historical_constituent_cost_attribution']
    for row in historical:
        receipt = next(p for p in (original / 'fields').glob('*.json')
                       if json.loads(p.read_text())['field'] == row['field'])
        require(review.digest(receipt) == row['source_receipt_sha256'], 'Historical constituent cost source')
        metrics = json.loads(receipt.read_text())['metrics']
        for key, expected_key in [('segmentation_cpu_seconds', 'segmentation_cpu_seconds'),
                                  ('scoring_cpu_seconds', 'scoring_cpu_seconds'),
                                  ('actual_field_cpu_seconds', 'actual_cpu_seconds'),
                                  ('actual_field_wall_seconds', 'actual_wall_seconds')]:
            require(row[key] == metrics[expected_key], 'Historical constituent timing differs')
    review.write('MECHANISM_AND_REPAIR_REVIEW.json', {
        'schema': 'learning-to-build/internal-mechanism-review/v1', 'status': 'ACCEPTED_WITH_STATED_LIMITS',
        'independence': 'Separate same-session internal assistant reviewer did not author either candidate, diagnostic, registration, evaluator or checker. Reviewer inspected source and rescored archived masks using the separately implemented check.PublicData reference decoder and check.score. Not an external audit or fresh scientific confirmation.',
        'review_driver_sha256': review.digest(__file__),
        'checker_sha256': review.digest(review.SOURCE / 'check.py'),
        'source_bindings': {str((review.SOURCE / kind / name).relative_to(review.SOURCE)):
                            review.digest(review.SOURCE / kind / name)
                            for kind, names in [('diagnostics', ('run.py', 'PREREGISTRATION.json', 'FREEZE.json', 'RESULTS.json', 'EVIDENCE.json')),
                                                ('repair', ('composition.py', 'evaluate.py', 'PREREGISTRATION.json', 'FREEZE.json', 'RESULTS.json', 'EVIDENCE.json'))]
                            for name in names},
        'archive_members_verified': {'diagnostics': len(diagnostic_files), 'repair': len(repair_files)},
        'independent_reference_fields': list(references), 'pixel_members_decoded': accessed,
        'successor_test_pixel_decoding_performed': False, 'archived_predictions_independently_rescored': 20,
        'condition_results': checked,
        'substantive_findings': [],
        'required_qualifications': [
            'Order replay executes actual builder.construct but replaces score acquisition with a cached adapter:792 cached evaluator calls are not792 fresh image-inference calls.',
            'The four calibration fields and all original outcomes were already exposed before these diagnostics; prospective code freezing does not make them untouched.',
            'The reference-foreground numerical pass is a reference-assisted diagnostic, not an accepted raw-input method.',
            'Changing seed input also changes the raw foreground branch through its seed union; contrasts identify software branch effects, not isolated biological causal effects.',
            'The single assistant-authored ordinary repair failed the frozen calibration boundary gate and correctly stopped without test scoring or a new full raw-neural operation.',
            'Cached constituent inference has nonzero original cost; attributed field times are nested original work and must not be recharged as incremental execution.',
            'Neither result demonstrates fresh transfer, retained-method learning advantage or complete-cost savings.'],
        'historical_constituent_cost_totals': {key: sum(row[key] for row in historical) for key in
            ('segmentation_cpu_seconds', 'scoring_cpu_seconds', 'actual_field_cpu_seconds', 'actual_field_wall_seconds')},
        'actual_cpu_seconds': time.process_time() - CPU, 'actual_wall_seconds': time.perf_counter() - START,
        'cost_scope': 'This archive/independent-reference rescoring process only; source reading/reasoning and earlier interactive checks are unmeasured. No prediction generation in this pass.'})
    review.command('repair-independent-replay', [review.PYTHON, '-B', str(review.SOURCE / 'repair/evaluate.py'),
                  '--cache', '/workspace/scratch/fad12dbaa4fb/ltb-data-cache', '--incumbent',
                  str(review.WORK / 'extracted/incumbent'), '--output', str(review.WORK / 'repair-replay'),
                  '--verify', '--expected', str(review.SOURCE / 'repair/RESULTS.json')])
    print((review.WORK / 'repair-independent-replay.stdout').read_text())


if __name__ == '__main__':
    main()
