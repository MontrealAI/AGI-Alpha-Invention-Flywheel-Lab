# Independent internal evidence review — LEARNING TO BUILD 1.1

## Verdict and degree of independence

The reviewed evidence supports a qualified existing nucleus specialist, a failed classical nucleus contract, a failed whole-cell successor and zero demonstrated retained-method evaluation savings. The new mechanism diagnostic and single ordinary composition do not change those qualification verdicts. No remaining blocking scientific finding was identified in the reviewed source and evidence. Integration, publication and actual live browser verification are separate obligations; this packet does not claim they were completed.

A separate same-session assistant reviewer performed this review and did not author the registered experiment, specialist, independent checker, new diagnostic, new composition, setup repair or browser QA script. This is an internal project review, not an external audit. The reviewer subsequently authored `construction/projection.py` and its tests; root separately reviewed that utility and independently compared all 416 reconstructed paths/bytes with the preserved original. Root's receipt is retained in `receipts/ROOT_PROJECTION_REVIEW.json`.

## Original experiment, exposure and scoring

The specialist denominator is 116 fields: 50 BBBC039 validation, 50 BBBC039 test, 4 BBBC007 calibration and 12 BBBC007 test. The 100 donor-training fields are additional. Cohorts, thresholds, model/adapter identities and prior exposure were checked. This is an exposed reproduction, not new concealed confirmation. Both source cohorts must qualify; classical r17 fails validation count error 0.216173 against 0.20, whereas the fixed pretrained specialist passes both source cohorts. All six classical successor arms and the specialist fail the frozen whole-cell boundary threshold 0.60. The learned-order/same-content empirical-order primary comparison saves 0 candidate evaluations.

The reviewer verified existing authoritative source bindings and added a LIMITED saved-output audit: 312 saved field predictions rescored (196 classical and 116 specialist), 136 unique classical predictions regenerated, unchanged 278-file classical and 265-file specialist inventories. This did not replay donor/calibration predictions or neural inference. The full JSON returned by tool session 87725 was preserved with normalized JSON whitespace; `LIMITED_SAVED_OUTPUT_AUDIT_CAPTURE.json` explains that check.py had no --output argument, so this is an assistant-preserved tool-output record, not a separately generated original on-disk checker receipt.

## Residual integrity and cost finding

The original raw tree contains 416 files: 278 canonical files and 138 byte-identical residual copies. Every mapping/hash/path partition was checked; original and projected results/run-state bytes match. The original tree still fails strict inventory. Reconstruction restored all 416 paths and bytes into a new directory, independently compared equal to the preserved original, and was rejected by the actual check.Evidence.inventory gate for the 138 residuals. That inventory-component check is not another full numerical replay.

Material finding: the historical `has_unmeasured_interrupted_work=false` predicate only means the retained ledger records no interrupted/orphaned attempt. Equal residual bytes do not establish whether additional execution occurred. Root was asked to preserve the historical flag while adding explicit residual-origin work/cost uncertainty in derived summaries and prose. Measured stage costs remain unchanged; total cost completeness is not established. All original raw bytes, rejection evidence and unresolved provenance remain preserved.

The portable utility verifies the extracted `classical/` plus `classical-residuals/PROJECTION.json` layout, rejects unsafe paths/symlinks/incomplete or overlapping partitions and reconstructs only into a new destination. Ten focused tests passed. CLI:

```sh
python -B construction/projection.py --evidence /absolute/extracted-evidence --reconstruct /absolute/new-original-raw
```

Omit --reconstruct for verification only. This checks byte integrity, not scientific acceptance or the cause/cost of the residuals.

## New mechanism diagnostic and ordinary repair

Both archives, registrations, freeze receipts and source/result bindings were verified:137 diagnostic files and 8 repair files. Using the separate check.PublicData reference decoder, the reviewer decoded only the four registered A9 calibration fields and independently rescored all 20 archived masks (16 factorial + 4 repair), matching all metrics, aggregates and gates. No successor test pixels were decoded in this review. New executions also matched each program's complete frozen numerical endpoints.

The 33 cached-order interventions comprise 30 unique orders; all exhaust 24 candidates and choose r12. They are real calls through builder.construct with cached score acquisition, not 792 fresh inference calls. The six policies were deterministic algorithms over a supplied bank, not six independently prompted language models.

Reference foreground alone raises mean boundary F1 to 0.615828 and meets the numerical calibration gate; reference nuclei alone produce 0.195353; both references produce 0.714909. These are reference-assisted software-branch diagnostics, not accepted raw-input routes. The seed branch also modifies foreground through a seed union, so the contrast is not an isolated biological causal estimate. One individual foreground-reference field remains below 0.60 while the registered cohort mean passes; thresholds were not changed.

The separately frozen ordinary composition used the actual saved specialist foreground union and unchanged r12 raw-DNA seed watershed. It was authored in response to the diagnostic, not generated by the original six construction policies. Independent scoring reproduced calibration boundary F1 **0.296809**, Dice **0.861057**, count error **0.081112**. The candidate fails and stops before test scoring: 0 test fields and no new full raw-neural operation. No tuning or threshold change was observed. The four original constituent timing receipts match; historical inference is attributed, not priced at zero or recharged as incremental work.

These results do not demonstrate fresh transfer, retained-method learning advantage, or complete-cost savings.

## Setup and reader-script review

The setup boundary repair was separately reviewed and all 7 focused tests passed. It protects the owning canonical checkout/worktree or the extracted edition, without treating an unrelated enclosing Git marker as ownership of every sibling directory. This review did not repeat installation or neural inference.

Static reader-script review identified an unbounded shutdown wait, cleanup exceptions that could prevent receipt creation, and a disclosure-presence assertion whose label exceeded its count-only test. The author corrected these and the reviewer rechecked them. Source review is accepted; no Chrome process was launched by this reviewer. Actual rendering, screenshots and live publication remain outside this static review's evidence.

## Costs, contents and reproduction limits

`REVIEW_COSTS.json` lists exact additional observed boundaries and parent/child relationships. The LIMITED audit adds 449.190953561 CPU seconds and 448.861647139 wall seconds. The independent 20-mask/reference-decoder pass adds 3.213029056 CPU seconds and 1.560200925 wall seconds. New diagnostic and repair replay command boundaries add 8.665957/7.025907227 and 3.379151/1.805588893 CPU/wall seconds respectively. Inner PROCESS_COST telemetry is nested and must not be added again. Smaller extraction, projection, inventory and test boundaries are retained individually. Reading/reasoning, initial interactive checks, preparation and actual billing remain incompletely measured; unknown does not mean zero.

`receipts/` contains observed outputs, command logs and qualification checks. `replays/` preserves all newly executed diagnostic/repair outputs. `execution-support/` preserves the reviewer drivers used in this workspace; the portable public reproduction commands remain in the edition. Duplicate extracted original evidence and reconstructed raw trees are omitted because their full byte equality is recorded and the source archive already preserves them. `SOURCE_BINDINGS.json` identifies the reviewed working-tree bytes. `MANIFEST.json` lists every packet member's size and SHA256; it is an inventory, not an external signature or certification.
