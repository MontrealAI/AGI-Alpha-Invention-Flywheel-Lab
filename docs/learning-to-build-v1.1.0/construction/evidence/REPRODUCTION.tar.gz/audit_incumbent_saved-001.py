#!/usr/bin/env python3
"""Audit the completed 116-field saved-neural run without model inference.

This retained orchestration driver imports the frozen independent checker. It
does not call its classical replay, load neural weights, or change producer
outputs. Invocation/recovery/operator records are reconciled separately from
scientific rescoring. A failed audit gets a new, numbered REJECTED receipt;
the requested positive receipt is never overwritten or created on failure.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
FROZEN_CHECKER = "7925052c4891600fd9958f31fd51296e2cb96be9343792bd725c0dde3f7fe142"
DRIVER_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
SPLITS = ("source_validation", "source_test", "successor_calibration", "successor_test")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_new(path, record):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def import_checker(source):
    path = source / "check.py"
    require(digest(path) == FROZEN_CHECKER, "The independent checker differs from the frozen reviewed source")
    name = "_ltb_frozen_saved_neural_audit"
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, "Cannot import the frozen checker")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class ObservedRecords:
    def __init__(self, root, checker):
        self.root, self.checker, self.records = root, checker, {}

    def file(self, relative):
        path = self.root / relative
        require(path.is_file() and not path.is_symlink()
                and path.resolve().is_relative_to(self.root), "Missing or unsafe observed record: " + relative)
        row = dict(path=relative, bytes=path.stat().st_size, sha256=digest(path))
        if relative in self.records:
            require(row == self.records[relative], "Observed record changed while reading: " + relative)
        self.records[relative] = row
        return path

    def read(self, relative):
        return self.checker.load_json(self.file(relative))

    def finish(self):
        for name in tuple(self.records):
            self.file(name)
        return [self.records[name] for name in sorted(self.records)]


def command(records, prefix, source):
    c = records.checker
    result = records.read(prefix + ".json")
    started = records.read(prefix + ".started.json")
    c.same(result["schema"], "agi-alpha/overnight022-command-resource/v1", prefix + " schema")
    c.same(result["exit_code"], 0, prefix + " terminal exit")
    c.same(started["command"], result["command"], prefix + " command")
    c.same(started["started_utc"], result["started_utc"], prefix + " start")
    c.same(started["status"], "STARTED_FINAL_RECEIPT_REQUIRED", prefix + " start status")
    require(datetime.fromisoformat(result["finished_utc"]) >= datetime.fromisoformat(result["started_utc"]),
            "Reversed invocation timestamps: " + prefix)
    c.nonnegative_times(result, ("wall_seconds", "children_user_cpu_seconds",
                                "children_system_cpu_seconds", "total_measured_command_cpu_seconds"), prefix)
    argv = result["command"]
    require(isinstance(argv, list) and all(isinstance(x, str) for x in argv)
            and str(source / "incumbent.py") in argv, "Invocation used a different program: " + prefix)
    records.file(prefix + ".stdout")
    records.file(prefix + ".stderr")
    return result


def option(argv, name):
    require(argv.count(name) == 1, "Missing or repeated command option: " + name)
    index = argv.index(name)
    require(index + 1 < len(argv), "Missing command option value: " + name)
    return argv[index + 1]


def stdout_objects(path, checker):
    """Retain non-JSON log text while strictly parsing every JSON object."""
    text = path.read_text(encoding="utf-8")
    decoder = json.JSONDecoder()
    objects, other_lines, offset = [], [], 0
    while offset < len(text):
        while offset < len(text) and text[offset].isspace():
            offset += 1
        if offset == len(text):
            break
        if text[offset] == "{":
            _, end = decoder.raw_decode(text, offset)
            objects.append(checker.json_text(text[offset:end]))
            offset = end
        else:
            end = text.find("\n", offset)
            end = len(text) if end < 0 else end
            other_lines.append(text[offset:end])
            offset = end
    return objects, other_lines


def reconcile_observed(records, source, cache, protocol, result):
    c = records.checker
    main = command(records, "incumbent-command-001", source)
    argv = main["command"]
    require("run" in argv and "--resume" not in argv, "Main record is not the original complete run")
    require(Path(option(argv, "--output")).resolve() == records.root / "incumbent"
            and Path(option(argv, "--cache")).resolve() == cache,
            "Main command targeted different output or public inputs")
    context = records.read("incumbent-invocation-context.json")
    c.same(context["schema"], "learning-to-build/incumbent-reproduction-context/v1", "observed context schema")
    c.same(context["implementation_files"], result["identity"]["implementation_files"], "observed source files")
    for key in ("protocol_sha256", "registration_sha256"):
        c.same(context["incumbent_" + key], result["identity"][key], "observed " + key)
    c.same(context["fresh_holdout_evaluation"], False, "observed exposure")
    require(datetime.fromisoformat(context["recorded_at_utc"]) <= datetime.fromisoformat(main["started_utc"]),
            "Invocation context was recorded after the command began")
    choices = context["prior_classical_choices"]
    c.same(choices["choices_written_before_incumbent_inference"], True, "recorded choice ordering")
    selected_path = records.root / "classical-projection/successor/SELECTIONS_BEFORE_TEST.json"
    require(digest(selected_path) == choices["sha256"], "Observed six-choice identity differs")
    selected = c.load_json(selected_path)
    c.same(sorted(selected), sorted(c.ARMS), "observed six choices")
    c.same(choices["arms"], sorted(c.ARMS), "context six choices")
    for name, expected in context["setup_receipts"].items():
        require(digest(records.file("incumbent-setup-003/" + name)) == expected,
                "Observed pre-inference setup receipt differs: " + name)
    setup = records.read("incumbent-setup-003/SETUP.json")
    c.same(setup["status"], "READY_FOR_REPRODUCTION", "observed setup readiness")
    c.same(setup["runtime_verified"], result["identity"]["runtime_versions"], "observed run runtime")
    require(Path(option(argv, "--weights")).resolve() == Path(setup["weights"]).resolve(),
            "Main command used a different model path from verified setup")
    objects, other = stdout_objects(records.file("incumbent-command-001.stdout"), c)
    expected_events = []
    for split in SPLITS:
        for field in protocol["cohorts"][split]:
            expected_events.append(dict(split=split, completed_field=field,
                                        new_fields=len(expected_events) + 1))
    require(len(expected_events) == 116 and len(objects) == 117,
            "Observed stdout does not contain all 116 events and the terminal result")
    c.same(objects[:-1], expected_events, "observed registered field order and denominator")
    c.same(objects[-1], result, "observed terminal stdout result")
    require(len(result["sessions"]) == 1 and result["sessions"][0]["status"] == "COMPLETE"
            and result["sessions"][0]["new_fields"] == 116, "Observed invocation/session coverage differs")

    expected_source = {name: result["identity"][name]
                       for name in ("protocol_sha256", "registration_sha256", "implementation_files")}
    records.file("incumbent_postrun_verification.py")
    records.read("incumbent-resume-before.json")
    for prefix, receipt_name, schema in (
            ("incumbent-resume-001", "incumbent-resume-check.json", "learning-to-build/incumbent-resume-check/v1"),
            ("incumbent-operator-command-001", "incumbent-operator-verification.json", "learning-to-build/incumbent-operator-verification/v1")):
        command(records, prefix, source)
        receipt = records.read(receipt_name)
        c.same(receipt["schema"], schema, receipt_name + " schema")
        c.same(receipt["status"], "PASS", receipt_name + " gate")
        c.same(receipt["exit_code"], 0, receipt_name + " exit")
        c.same(receipt["source_bindings"], expected_source, receipt_name + " source")
        require(receipt["verification_source_sha256"] == digest(records.file("incumbent_postrun_verification.py")),
                "Postrun receipt generator changed")
        for suffix, key in ((".json", "command_receipt_sha256"), (".stdout", "stdout_sha256"), (".stderr", "stderr_sha256")):
            require(receipt[key] == digest(records.file(prefix + suffix)), "Postrun command/log changed")
    resume = records.read("incumbent-resume-check.json")
    c.same(resume["observed_status"], "ALREADY_COMPLETE", "completed resume status")
    c.same(resume["predictions_performed_this_invocation"], 0, "resume inference count")
    c.same(resume["unchanged"], True, "resume unchanged bytes")
    for key, actual in (("results_sha256", digest(records.root / "incumbent/RESULTS.json")),
                        ("completion_json_sha256", digest(records.root / "incumbent/COMPLETION.json"))):
        require(resume[key + "_before"] == resume[key + "_after"] == actual,
                "Resume result/seal identity differs")
    operation = records.read("incumbent-operator-verification.json")
    c.same(operation["observed_status"], "OPERATED", "raw operator status")
    c.same(operation["fields_operated"], 1, "raw operator count")
    c.same(operation["field"], protocol["cohorts"]["source_test"][0], "raw operator selected field")
    for key in ("raw_input_matches_registered_member", "prediction_matches_retained_bytes",
                "measurements_match_retained_field", "source_bindings_match_registered_run"):
        c.same(operation[key], True, "raw operator " + key)
    for key in ("reference_inputs_to_operator", "fresh_scientific_confirmation"):
        c.same(operation[key], False, "raw operator " + key)
    for key, relative in (("operation_receipt_sha256", "incumbent-operator/OPERATION.json"),
                          ("input_receipt_sha256", "incumbent-operator-input/INPUT.json"),
                          ("prediction_sha256", "incumbent-operator/labels.png"),
                          ("measurements_sha256", "incumbent-operator/measurements.csv")):
        require(operation[key] == digest(records.file(relative)), "Retained operator record changed: " + key)
    return dict(terminal_returncode=0, logged_unique_fields=116,
                registered_field_order_matches=True, final_stdout_matches_results=True,
                source_runtime_and_input_bindings_match=True,
                prior_six_choice_sha256=choices["sha256"], context_precedes_recorded_command_start=True,
                non_json_stdout_lines=len(other), postrun_receipts_passed_and_bound=True,
                scope="Recorded invocation, output and postrun-receipt reconciliation. No new inference; hashes do not independently prove historical model execution or elapsed time.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--cache", required=True, type=Path)
    parser.add_argument("--observed", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    source, cache, observed, output = [p.resolve() for p in (args.source, args.cache, args.observed, args.output)]
    require(not output.exists() and output.parent.is_dir(), "Choose a new audit receipt in an existing directory")
    require(not output.is_relative_to(observed / "incumbent") and not output.is_relative_to(source),
            "Keep the audit receipt outside frozen source and sealed producer evidence")
    started_at = datetime.now(timezone.utc).isoformat()
    started, cpu = time.perf_counter(), time.process_time()
    try:
        c = import_checker(source)
        primary_protocol, registration, runtime = c.source_contract()
        protocol = c.load_json(source / "INCUMBENT_PROTOCOL-amendment-2.json")
        records = ObservedRecords(observed, c)
        result = c.load_json(observed / "incumbent/RESULTS.json")
        seal = c.load_json(observed / "incumbent/COMPLETION.json")
        c.same(result["status"], "COMPLETE", "completed incumbent")
        c.same(seal["schema"], "learning-to-build/incumbent-completion/v1", "completed incumbent seal")
        reconciliation = reconcile_observed(records, source, cache, protocol, result)
        public = c.PublicData(cache, primary_protocol)
        verifier = c.Verifier(public, primary_protocol, registration, replay_search=False)
        incumbent = c.verify_incumbent(verifier, observed / "incumbent")
        require(verifier.saved_fields == 116 and not verifier.replayed,
                "Unexpected saved-field denominator or classical prediction execution")
        bindings = records.finish()
        for key, expected in public.archives.items():
            path = cache / (key + ".zip")
            require(path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"],
                    "Public archive changed during audit: " + key)
        c.source_contract()
        require(digest(source / "check.py") == FROZEN_CHECKER
                and digest(Path(__file__)) == DRIVER_SHA256, "Audit source changed while executing")
        receipt = dict(
            schema="learning-to-build/independent-incumbent-check/v1", status="VERIFIED",
            started_at_utc=started_at, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
            verifier_sha256=FROZEN_CHECKER, audit_driver_sha256=DRIVER_SHA256,
            protocol_sha256=c.PINNED["PROTOCOL-amendment-2.json"], source_bindings=c.PINNED,
            runtime_versions=runtime, public_archives=public.archives,
            classical_coverage="NOT_CHECKED", incumbent_coverage="ALL_116_SAVED_PREDICTIONS",
            saved_prediction_fields_rescored=verifier.saved_fields,
            unique_classical_predictions_regenerated=0, incumbent=incumbent,
            observed_invocation_receipts=bindings, observed_run_reconciliation=reconciliation,
            actual_cpu_seconds=time.process_time() - cpu, actual_wall_seconds=time.perf_counter() - started,
            scientific_confirmation="EXPOSED_DATA_REPRODUCTION_NOT_NEW_CONFIRMATION",
            independence="Frozen separate reference decoder/scorer and complete saved-mask audit. Common project authorship; no external laboratory certification.",
            limits=["No neural inference or classical replay is executed by this audit.",
                    "Invocation and postrun receipts are separately bound; hashes do not prove historical model execution or elapsed time.",
                    "No new biological, clinical, commercial or unseen-data confirmation claim is established."])
        write_new(output, receipt)
        print(json.dumps(receipt, sort_keys=True, allow_nan=False))
        return 0
    except Exception as error:
        receipt = dict(schema="learning-to-build/independent-incumbent-check/v1", status="REJECTED",
                       started_at_utc=started_at, recorded_at_utc=datetime.now(timezone.utc).isoformat(),
                       verifier_expected_sha256=FROZEN_CHECKER, audit_driver_sha256=DRIVER_SHA256,
                       error_type=type(error).__name__, error=str(error),
                       actual_cpu_seconds=time.process_time() - cpu, actual_wall_seconds=time.perf_counter() - started)
        index = 1
        while True:
            failed = output.with_name(output.stem + f".REJECTED-{index:03d}.json")
            try:
                write_new(failed, receipt)
                break
            except FileExistsError:
                index += 1
        print(json.dumps(dict(receipt, retained_failure_receipt=failed.name), sort_keys=True, allow_nan=False))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
