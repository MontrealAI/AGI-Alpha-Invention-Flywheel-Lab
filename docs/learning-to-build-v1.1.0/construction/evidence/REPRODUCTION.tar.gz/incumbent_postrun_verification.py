#!/usr/bin/env python3
"""Verify the completed-run resume and one raw-image operator reproduction.

This receipt generator performs no neural inference and changes no frozen
source or completed evidence. The actual commands are executed separately by
the repository's command-resource wrapper, retaining stdout and stderr.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def read(path):
    return json.loads(path.read_text(), object_pairs_hook=unique)


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()


def inventory(root, exclude_seal=False):
    result = []
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), "Evidence symlink")
        if path.is_file() and not (exclude_seal and path == root / "COMPLETION.json"):
            result.append({"path": path.relative_to(root).as_posix(),
                           "bytes": path.stat().st_size, "sha256": sha(path)})
    return result


def source_bindings(source):
    registration = read(source / "INCUMBENT_REGISTRATION-amendment-2.json")
    require(sha(source / "INCUMBENT_REGISTRATION-amendment-2.json") ==
            "a0ff81e25aa9782921a04f58b6062ec7be86a4538156ad6f3dee77945a17764f", "Different frozen registration")
    bindings = {name: sha(source / name) for name in registration["implementation_files"]}
    require(bindings == registration["implementation_files"], "Changed registered source")
    protocol_sha = sha(source / "INCUMBENT_PROTOCOL-amendment-2.json")
    require(protocol_sha == registration["protocol_sha256"], "Different incumbent protocol")
    return {"protocol_sha256": protocol_sha,
            "registration_sha256": sha(source / "INCUMBENT_REGISTRATION-amendment-2.json"),
            "implementation_files": bindings}


def complete_snapshot(source, run):
    bindings = source_bindings(source)
    result, identity, seal = read(run / "RESULTS.json"), read(run / "IDENTITY.json"), read(run / "COMPLETION.json")
    require(result["status"] == "COMPLETE" and read(run / "STATUS.json")["status"] == "COMPLETE", "Incomplete result")
    require(result["identity"] == identity, "Result and saved identity differ")
    require(result["sessions"] == read(run / "SESSIONS.json"), "Session records differ")
    require(all(identity[key] == value for key, value in bindings.items()), "Run source binding differs")
    members = inventory(run, exclude_seal=True)
    tree_sha = hashlib.sha256(canonical(members).encode()).hexdigest()
    require(seal["schema"] == "learning-to-build/incumbent-completion/v1" and
            seal["files"] == members and seal["tree_sha256"] == tree_sha, "Completed tree changed")
    return {"results_sha256": sha(run / "RESULTS.json"),
            "completion_json_sha256": sha(run / "COMPLETION.json"),
            "completion_tree_sha256": tree_sha,
            "inventory_sha256": hashlib.sha256(canonical(inventory(run)).encode()).hexdigest(),
            "source_bindings": bindings}


def command_receipt(base, name):
    path = base / (name + ".json")
    receipt = read(path)
    require(receipt["schema"] == "agi-alpha/overnight022-command-resource/v1" and receipt["exit_code"] == 0, "Command failed")
    started = read(base / (name + ".started.json"))
    require(started["command"] == receipt["command"] and started["started_utc"] == receipt["started_utc"], "Command start receipt differs")
    return receipt, {"command_receipt_sha256": sha(path),
                     "stdout_sha256": sha(base / (name + ".stdout")),
                     "stderr_sha256": sha(base / (name + ".stderr"))}


def rows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def write_new(path, value, run):
    require(not path.resolve().is_relative_to(run.resolve()), "Cannot add files to the completed evidence tree")
    value.update(recorded_at_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                 verification_source_sha256=sha(Path(__file__)))
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps(value, indent=2, sort_keys=True, allow_nan=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("capture-resume", "verify-resume", "verify-operator"))
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--base", type=Path, required=True)
    args = parser.parse_args()
    source, base = args.source.resolve(), args.base.resolve()
    run = base / "incumbent"
    snapshot = complete_snapshot(source, run)
    if args.command == "capture-resume":
        write_new(base / "incumbent-resume-before.json",
                  {"schema": "learning-to-build/incumbent-resume-before/v1", **snapshot}, run)
        return
    if args.command == "verify-resume":
        before = read(base / "incumbent-resume-before.json")
        command, hashes = command_receipt(base, "incumbent-resume-001")
        require("run" in command["command"] and "--resume" in command["command"], "Not a resume command")
        require(str(run) in command["command"], "Resume targeted a different output")
        require(before["recorded_at_utc"] <= command["started_utc"], "Before snapshot was not recorded before resume")
        observed = read(base / "incumbent-resume-001.stdout")
        require(observed["status"] == "ALREADY_COMPLETE" and observed["predictions_performed_this_invocation"] == 0, "Resume performed new predictions or was incomplete")
        require(observed["results_sha256"] == snapshot["results_sha256"] and observed["completion_tree_sha256"] == snapshot["completion_tree_sha256"], "Resume reported another result")
        require(all(before[key] == value for key, value in snapshot.items()), "Completed run changed during resume")
        result = {"schema": "learning-to-build/incumbent-resume-check/v1", "status": "PASS",
                  "exit_code": command["exit_code"], "observed_status": observed["status"],
                  "predictions_performed_this_invocation": observed["predictions_performed_this_invocation"],
                  "unchanged": True, "source_bindings": snapshot["source_bindings"], **hashes}
        for key in ("results_sha256", "completion_json_sha256", "completion_tree_sha256", "inventory_sha256"):
            result[key + "_before"], result[key + "_after"] = before[key], snapshot[key]
        write_new(base / "incumbent-resume-check.json", result, run)
        return
    command, hashes = command_receipt(base, "incumbent-operator-command-001")
    argv = command["command"]
    require("operate" in argv and "--dna" in argv and "--actin" not in argv, "Not a DNA-only operator command")
    require(argv[argv.index("--task") + 1] == "nuclei", "Different operator task")
    operation_root = base / "incumbent-operator"
    require(argv[argv.index("--output") + 1] == str(operation_root), "Different operator output")
    operation = read(operation_root / "OPERATION.json")
    require(read(base / "incumbent-operator-command-001.stdout") == operation, "Observed output differs from saved operation")
    require(operation["status"] == "OPERATED" and operation["task"] == "nuclei" and
            operation["reference_inputs_used"] is False and operation["accuracy_on_supplied_images_established"] is False,
            "Different operator status or claim scope")
    identity = read(run / "IDENTITY.json")
    require(operation["identity"] == {key: value for key, value in identity.items() if key != "archives"}, "Operator source/configuration/runtime differs from registered run")
    protocol = read(source / "INCUMBENT_PROTOCOL-amendment-2.json")
    field = protocol["cohorts"]["source_test"][0]
    acquisition = read(base / "incumbent-operator-input/INPUT.json")
    require(acquisition["field"] == field and acquisition["selection"] == "first_official_source_test_entry", "Different operator field")
    require(Path(acquisition["file"]).name == acquisition["file"], "Unexpected raw-input path")
    masks = read(run / "source/test/MASKS.json")
    saved = masks[field]
    raw = base / "incumbent-operator-input" / acquisition["file"]
    raw_sha = sha(raw)
    require(argv[argv.index("--dna") + 1] == str(raw), "Different supplied DNA input")
    require(raw_sha == acquisition["member_sha256"] == acquisition["extracted_file_sha256"] ==
            operation["inputs"]["dna"]["sha256"] == saved["sources"]["dna"]["sha256"], "Raw input differs from registered archive member")
    require(acquisition["member"] == saved["sources"]["dna"]["member"] and
            acquisition["archive_sha256"] == identity["archives"]["bbbc039_images"]["sha256"], "Raw source archive binding differs")
    prediction_sha = sha(operation_root / "labels.png")
    require(prediction_sha == saved["sha256"] == sha(run / "source/test" / saved["path"]) == operation["outputs"]["labels.png"]["sha256"], "Operator prediction differs from retained bytes")
    measurements_sha = sha(operation_root / "measurements.csv")
    require(measurements_sha == operation["outputs"]["measurements.csv"]["sha256"], "Operator measurement bytes changed")
    expected = [{key: value for key, value in row.items() if key != "field"}
                for row in rows(run / "source/test/measurements.csv") if row["field"] == field]
    require(rows(operation_root / "measurements.csv") == expected and len(expected) == operation["objects"], "Operator measurements differ from retained field")
    result = {"schema": "learning-to-build/incumbent-operator-verification/v1", "status": "PASS",
              "exit_code": command["exit_code"], "observed_status": operation["status"],
              "source_origin": "registered-working-source", "field": field,
              "fields_operated": 1, "field_selection": "first_official_source_test_entry",
              "raw_input_matches_registered_member": True, "prediction_matches_retained_bytes": True,
              "measurements_match_retained_field": True, "source_bindings_match_registered_run": True,
              "reference_inputs_to_operator": False, "fresh_scientific_confirmation": False,
              "raw_input_sha256": raw_sha, "registered_member_sha256": acquisition["member_sha256"],
              "prediction_sha256": prediction_sha, "retained_prediction_sha256": saved["sha256"],
              "measurements_sha256": measurements_sha,
              "operation_receipt_sha256": sha(operation_root / "OPERATION.json"),
              "input_receipt_sha256": sha(base / "incumbent-operator-input/INPUT.json"),
              "source_bindings": snapshot["source_bindings"], **hashes}
    write_new(base / "incumbent-operator-verification.json", result, run)


if __name__ == "__main__":
    main()
