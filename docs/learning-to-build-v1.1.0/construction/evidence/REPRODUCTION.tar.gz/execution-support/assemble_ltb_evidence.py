#!/usr/bin/env python3
"""Assemble only complete, independently checked continuation evidence.

One-time authoring utility. The public evidence.py creates the deterministic
archive from this staging directory; no producer output is edited here.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess

WORK = Path('/workspace/scratch/fad12dbaa4fb')
REPO = WORK / 'learning-to-build'
SOURCE = REPO / 'docs/learning-to-build-v1.1.0/construction'
OBSERVED = WORK / 'ltb-reproduction-20261107'
STAGING = WORK / 'ltb-evidence-staging-20261107'
REGISTERED = '64d6d30da4a5da7c8905d9a106d9e2a996a29e4d'
READ_IDENTITIES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path = Path(path)
    contents = path.read_bytes()
    identity = {'bytes': len(contents), 'sha256': hashlib.sha256(contents).hexdigest()}
    require(path not in READ_IDENTITIES or READ_IDENTITIES[path] == identity,
            'A validated JSON input changed: ' + str(path))
    READ_IDENTITIES[path] = identity
    return json.loads(contents)


def binding(path, relative_to=OBSERVED):
    path = Path(path)
    return {'path': path.relative_to(relative_to).as_posix(),
            'bytes': path.stat().st_size, 'sha256': digest(path)}


def inventory(directory):
    return {p.relative_to(directory).as_posix(): {'bytes': p.stat().st_size, 'sha256': digest(p)}
            for p in sorted(directory.rglob('*')) if p.is_file()}


def main():
    require(not STAGING.exists(), 'Preserve an existing staging directory; choose a new path')
    classical = read(OBSERVED / 'classical-projection/RESULTS.json')
    neural = read(OBSERVED / 'incumbent/RESULTS.json')
    cc = read(OBSERVED / 'PROJECTED_CLASSICAL_INDEPENDENT_CHECK-002.json')
    nc = read(OBSERVED / 'INCUMBENT_INDEPENDENT_CHECK.json')
    invocation = read(OBSERVED / 'incumbent-command-001.json')
    require(classical['status'] == neural['status'] == 'COMPLETE', 'Incomplete producer output')
    require(cc['status'] == nc['status'] == 'VERIFIED', 'Independent verification is incomplete')
    require(cc['classical']['results_sha256'] == digest(OBSERVED / 'classical-projection/RESULTS.json'), 'Classical audit differs')
    require(nc['incumbent']['results_sha256'] == digest(OBSERVED / 'incumbent/RESULTS.json'), 'Neural audit differs')
    require(cc['verifier_sha256'] == nc['verifier_sha256'] == digest(SOURCE / 'check.py'), 'Verifier source differs')
    specification = importlib.util.spec_from_file_location('ltb_summary_contract', SOURCE / 'summarize.py')
    formatter = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(formatter)
    formatter.verification_scope(cc, nc)
    for name in ('incumbent-resume-check.json', 'incumbent-operator-verification.json',
                 'incumbent-resume-001.json', 'incumbent-operator-command-001.json'):
        require((OBSERVED / name).is_file(), 'Missing observed recovery/operation receipt: ' + name)
    for name in ('incumbent-command-001.json', 'incumbent-resume-001.json',
                 'incumbent-operator-command-001.json'):
        command_receipt = read(OBSERVED / name)
        require(command_receipt['schema'] == 'agi-alpha/overnight022-command-resource/v1' and
                type(command_receipt['exit_code']) is int and command_receipt['exit_code'] == 0,
                'Observed command did not finish successfully: ' + name)
    identity = read(OBSERVED / 'incumbent/IDENTITY.json')
    expected_bindings = {key: identity[key] for key in
                         ('protocol_sha256', 'registration_sha256', 'implementation_files')}
    resume = read(OBSERVED / 'incumbent-resume-check.json')
    require(resume['schema'] == 'learning-to-build/incumbent-resume-check/v1' and
            resume['status'] == 'PASS' and resume['observed_status'] == 'ALREADY_COMPLETE' and
            type(resume['exit_code']) is int and resume['exit_code'] == 0,
            'Resume did not record a successful completed invocation')
    require(type(resume['predictions_performed_this_invocation']) is int and
            resume['predictions_performed_this_invocation'] == 0 and resume['unchanged'] is True,
            'Resume was not unchanged and idempotent')
    for key, actual in (
            ('results_sha256', digest(OBSERVED / 'incumbent/RESULTS.json')),
            ('completion_json_sha256', digest(OBSERVED / 'incumbent/COMPLETION.json')),
            ('completion_tree_sha256', read(OBSERVED / 'incumbent/COMPLETION.json')['tree_sha256'])):
        require(resume[key + '_before'] == resume[key + '_after'] == actual,
                'Resume identity differs: ' + key)
    require(resume['inventory_sha256_before'] == resume['inventory_sha256_after'],
            'Resume changed its inventory')
    require(resume['source_bindings'] == expected_bindings, 'Resume source differs from registered run')
    operator = read(OBSERVED / 'incumbent-operator-verification.json')
    require(operator['schema'] == 'learning-to-build/incumbent-operator-verification/v1' and
            operator['status'] == 'PASS' and operator['observed_status'] == 'OPERATED' and
            type(operator['exit_code']) is int and operator['exit_code'] == 0,
            'Raw-image operator did not pass')
    require(operator['source_origin'] == 'registered-working-source' and
            type(operator['fields_operated']) is int and operator['fields_operated'] == 1 and
            operator['field_selection'] == 'first_official_source_test_entry',
            'Raw-image operation has a different scope')
    for key in ('raw_input_matches_registered_member', 'prediction_matches_retained_bytes',
                'measurements_match_retained_field', 'source_bindings_match_registered_run'):
        require(operator[key] is True, 'Missing operator verification: ' + key)
    require(operator['reference_inputs_to_operator'] is False and
            operator['fresh_scientific_confirmation'] is False, 'Wrong raw-operation claim')
    require(operator['source_bindings'] == expected_bindings, 'Operator source differs from registered run')
    require(operator['raw_input_sha256'] == operator['registered_member_sha256'], 'Operator raw input differs')
    require(operator['prediction_sha256'] == operator['retained_prediction_sha256'] ==
            digest(OBSERVED / 'incumbent-operator/labels.png'), 'Operator prediction differs')
    require(operator['measurements_sha256'] == digest(OBSERVED / 'incumbent-operator/measurements.csv') and
            operator['operation_receipt_sha256'] == digest(OBSERVED / 'incumbent-operator/OPERATION.json'),
            'Operator output receipt differs')
    for receipt, prefix in ((resume, 'incumbent-resume-001'),
                            (operator, 'incumbent-operator-command-001')):
        require(receipt['command_receipt_sha256'] == digest(OBSERVED / (prefix + '.json')) and
                receipt['stdout_sha256'] == digest(OBSERVED / (prefix + '.stdout')) and
                receipt['stderr_sha256'] == digest(OBSERVED / (prefix + '.stderr')),
                'Observed command/log identity differs: ' + prefix)

    # Check every byte from the recovered registered continuation, not a handpicked subset.
    paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', REGISTERED,
                                     'docs/learning-to-build-v1.1.0'], cwd=REPO, text=True).splitlines()
    registered_files = []
    for name in paths:
        original = subprocess.check_output(['git', 'show', f'{REGISTERED}:{name}'], cwd=REPO)
        require((REPO / name).read_bytes() == original, 'Registered source changed: ' + name)
        registered_files.append({'path': name, 'bytes': len(original),
                                 'sha256': hashlib.sha256(original).hexdigest()})
    require(len(registered_files) == 54, 'Unexpected recovered source inventory')

    projection = read(OBSERVED / 'classical-residuals/PROJECTION.json')
    raw = OBSERVED / 'classical'
    projected = OBSERVED / 'classical-projection'
    residuals = OBSERVED / 'classical-residuals'
    raw_inventory = inventory(raw)
    require(len(raw_inventory) == projection['raw_file_count'] == 416, 'Raw inventory changed')
    require(len(inventory(projected)) == projection['projected_file_count'] == 278, 'Projection inventory changed')
    mapped_paths = [row['raw_path'] for row in projection['inclusion_mapping'] + projection['residual_mapping']]
    require(len(set(mapped_paths)) == len(mapped_paths) and set(mapped_paths) == set(raw_inventory),
            'Projection mapping is not a unique complete partition of observed raw files')
    require(set(projection['observed_raw_files']) == set(raw_inventory), 'Recorded raw inventory coverage differs')
    projected_paths = [row['projected_path'] for row in projection['inclusion_mapping']]
    require(len(set(projected_paths)) == len(projected_paths) and set(projected_paths) == set(inventory(projected)),
            'Projection destination mapping coverage differs')
    residual_paths = [row['preserved_path'] for row in projection['residual_mapping']]
    require(len(set(residual_paths)) == len(residual_paths) and
            set(residual_paths) == set(inventory(residuals)) - {'PROJECTION.json'},
            'Residual destination mapping coverage differs')
    for name, row in raw_inventory.items():
        recorded = projection['observed_raw_files'][name]
        require(row['bytes'] == recorded['bytes'] and row['sha256'] == recorded['sha256'],
                'Recorded observed raw identity differs: ' + name)
    for row in projection['inclusion_mapping']:
        require(digest(raw / row['raw_path']) == digest(projected / row['projected_path']) == row['sha256'], 'Projection byte mismatch')
    for row in projection['residual_mapping']:
        require(digest(raw / row['raw_path']) == digest(residuals / row['preserved_path']) ==
                digest(projected / row['canonical_counterpart']) == row['sha256'], 'Residual byte mismatch')
    require(len(projection['residual_mapping']) == 138, 'Residual inventory changed')

    copies = {'classical-projection': 'classical', 'classical-residuals': 'classical-residuals',
              'incumbent': 'incumbent', 'incumbent-setup-001': 'incumbent-setup-001',
              'incumbent-setup-002': 'incumbent-setup-002', 'incumbent-setup-003': 'incumbent-setup-003',
              'incumbent-setup-standalone-004': 'incumbent-setup-standalone-004',
              'incumbent-operator': 'incumbent-operator'}
    known_dirs = set(copies) | {'classical', 'incumbent-operator-input'}
    actual_dirs = {p.name for p in OBSERVED.iterdir() if p.is_dir()}
    require(actual_dirs <= known_dirs, 'Review unexpected observation directories: ' + str(actual_dirs - known_dirs))
    source_inventories = {name: inventory(OBSERVED / name) for name in copies}
    flat_copies = [(path, path.name) for path in sorted(OBSERVED.iterdir()) if path.is_file()]
    flat_copies += [
        (OBSERVED / 'incumbent-operator-input/INPUT.json', 'incumbent-operator-input/INPUT.json'),
        (WORK / 'ltb-data-cache/FETCH.json', 'input-acquisition/FETCH.json'),
        (WORK / 'ltb-quality/FINITE_REPRODUCTION.json', 'finite-companion/FINITE_REPRODUCTION.json'),
        (REPO / 'scripts/measure_overnight022.py', 'execution-support/measure_overnight022.py'),
        (Path(__file__).resolve(), 'execution-support/assemble_ltb_evidence.py'),
    ]
    require((REPO / 'scripts/measure_overnight022.py').read_bytes() ==
            subprocess.check_output(['git', 'show', REGISTERED + ':scripts/measure_overnight022.py'], cwd=REPO),
            'Resource wrapper differs from the retained registered-source commit')
    flat_copies += [(path, 'input-acquisition/' + path.name)
                    for path in (WORK / 'ltb-data-cache').glob('*_FETCH_FAILURE.json')]
    flat_identities = {target: {'bytes': path.stat().st_size, 'sha256': digest(path)}
                       for path, target in flat_copies}
    require(len(flat_identities) == len(flat_copies), 'Duplicate flat receipt destination')
    STAGING.mkdir()
    for source, target in copies.items():
        shutil.copytree(OBSERVED / source, STAGING / target)
    for path, target in flat_copies:
        require(not path.is_symlink(), 'Unexpected receipt symlink')
        (STAGING / target).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, STAGING / target)

    important = [
        'PROJECTED_CLASSICAL_INDEPENDENT_CHECK.json', 'PROJECTED_CLASSICAL_INDEPENDENT_CHECK-002.json',
        'CLASSICAL_INDEPENDENT_CHECK.json', 'INCUMBENT_INDEPENDENT_CHECK.REJECTED-001.json',
        'CHECKER_PREPARATION_SCHEMA_FIX.json', 'CHECKER_RECHECK_LAUNCH_FAILURE_001.json',
        'CHECKER_RECHECK_INVOCATIONS.json',
        'CHECKER_RECHECKS_COMPLETED.json', 'OBSERVATION_STABILITY_AFTER_RECHECKS.json',
        'check-before-loading-schema-fix.py', 'audit_incumbent_saved-001.py',
        'INCUMBENT_INDEPENDENT_CHECK.json', 'PROJECTION_IDEMPOTENT_RESUME.json',
        'HISTORICAL_FAILURE_REPLAY.json', 'DATA_ACQUISITION_OBSERVATION.json',
        'IDEMPOTENT_RESUME_RECEIPT_FAILURE_001.json', 'incumbent-setup-summary.json',
        'incumbent-invocation-context.json', 'incumbent-command-001.json',
        'incumbent-resume-001.json', 'incumbent-resume-check.json',
        'incumbent-operator-command-001.json', 'incumbent-operator-verification.json',
        'incumbent-operator/OPERATION.json', 'incumbent-operator-input/INPUT.json',
        'incumbent-setup-001/SETUP.json', 'incumbent-setup-002/SETUP.json',
        'incumbent-setup-003/SETUP.json', 'incumbent-setup-standalone-004/SETUP.json',
        'classical-residuals/PROJECTION.json', 'incumbent/COMPLETION.json',
    ]
    provenance = {
        'schema': 'learning-to-build/reproduction-provenance/v1',
        'edition': '1.1.0',
        'status': 'COMPLETE_NEW_REPRODUCTION_WITH_DISCLOSED_CHECKPOINT_PROJECTION',
        'assembled_at_utc': datetime.now(timezone.utc).isoformat(),
        'evidence_role': 'New reproduction of an already exposed registered comparison. Not recovered historical result bytes or a fresh confirmation.',
        'repository': 'https://github.com/MontrealAI/AGI-Alpha-Invention-Flywheel-Lab',
        'source': {
            'original_publication_main_commit': '2d1b3a2c1dab8235f2c7bef40bf9a36da1d62d7d',
            'recovered_registered_source_commit': REGISTERED,
            'additive_engineering_checkpoint': '7f08da58f356e04fba6b18952b1fe66f4a9e3e8f',
            'registered_source_files_all_unchanged': True,
            'registered_source_files': registered_files,
            'checker_sha256': digest(SOURCE / 'check.py'),
            'setup_sha256': digest(SOURCE / 'setup_incumbent.py'),
            'assembly_source': binding(STAGING / 'execution-support/assemble_ltb_evidence.py', STAGING),
            'command_resource_wrapper': binding(STAGING / 'execution-support/measure_overnight022.py', STAGING),
            'final_publication_source_identity': 'Bound separately by PUBLICATION.json and the qualified Git commit; no circular self-commit claim is made here.'
        },
        'historical_availability': {
            'original_full_unpushed_result_archive_recovered': False,
            'retained_registration_and_amendment_sources_recovered': True,
            'earlier_result_descriptions_exposed_before_this_run': True,
            'missing_historical_costs': None,
            'focused_failure_replays': 'New focused executions of preserved source snapshots; not the absent original full runs.'
        },
        'input_archives': cc['public_archives'],
        'input_acquisition_receipt': binding(STAGING / 'input-acquisition/FETCH.json', STAGING),
        'comparisons': {
            'classical_arms': 6, 'shared_recipe_bank': 24,
            'equal_donor_history_primary_pair': ['updated_no_artifact', 'same_content_empirical'],
            'all_six_primary_choices_saved_before_specialist_inference': True,
            'selections_sha256': digest(projected / 'successor/SELECTIONS_BEFORE_TEST.json'),
            'practical_specialist_is_separate_from_equal_content_primary_pair': True,
            'pretraining_overlap_excluded': False,
            'external_laboratory_acceptance_observed': False,
            'fresh_scientific_confirmation': False
        },
        'classical_projection': {
            'raw_files': 416, 'projected_files': 278, 'retained_residual_files': 138,
            'archive_classical_directory_contains': 'Unchanged canonical completed-checkpoint projection',
            'mapping': 'classical-residuals/PROJECTION.json',
            'mapping_original_projection_directory_name': 'classical-projection',
            'archive_projection_directory_name': 'classical',
            'raw_tree_reconstructable': True,
            'numerical_edits': False, 'cost_exclusions': False,
            'residual_cause': 'UNKNOWN; no attribution is inferred from duplicate bytes.'
        },
        'verification': {
            'classical': 'Full independent reference decoding/rescoring and frozen classical generator replay; 2632 distinct predictions and 196 saved fields.',
            'neural': 'All 116 saved fields independently rescored from original references; this audit does not rerun inference.',
            'actual_neural_execution': 'Separate observed complete 116-field invocation with source/runtime/input bindings.',
            'review_independence': 'Separate implementations and preparation roles with common project authorship; not external peer review or laboratory certification.',
            'recovery_and_raw_operator': 'Observed completed-run idempotent resume and one first-official-test raw-image operation are separately recorded.',
            'candidate_and_downloaded_package_operation': 'Performed separately after packaging. A public OPERATION_RECEIPT.json is added to the release only after actual downloaded-source operation passes; it is not inferred from this scientific archive.',
            'checker_repair': 'The first saved-neural audit rejected an incorrect key path in the additive checker: the pinned loading record is nested at preflight.loading. Prior checker/driver source and the failed audit are retained. The corrected checker is bound to PROJECTED_CLASSICAL_INDEPENDENT_CHECK-002.json and INCUMBENT_INDEPENDENT_CHECK.json, including a new full classical replay. Registered producers, acceptance criteria, model and predictions are unchanged.',
            'retained_orchestration_drivers': 'These preserve the original observed layout and command paths. Use construction/check.py for portable scientific verification of an extracted archive, and new absolute work paths for a new execution.',
        },
        'actual_runtime': {
            'classical_and_scoring': cc['runtime_versions'],
            'pretrained': read(OBSERVED / 'incumbent-setup-003/SETUP.json')['runtime_verified'],
            'scientific_run_system_site_packages': True,
            'separate_default_isolated_install_verified': True,
            'separate_install_receipt': 'incumbent-setup-standalone-004/SETUP.json',
            'same_environment_for_complete_neural_run': True,
            'entire_transitive_binary_and_host_identity_frozen': False
        },
        'cost_boundaries': {
            'classical_completed_stage_cpu_seconds': classical['completed_stage_cpu_seconds'],
            'classical_completed_stage_wall_seconds': classical['completed_stage_wall_seconds'],
            'neural_sessions_recorded_in': 'incumbent/RESULTS.json',
            'setup_attempts_included': ['incumbent-setup-001', 'incumbent-setup-002', 'incumbent-setup-003', 'incumbent-setup-standalone-004'],
            'failed_and_superseded_checks_retained': True,
            'timing_rule': 'Receipt boundaries overlap. Do not add nested command and session CPU totals or parallel wall times as project duration.',
            'unknown_not_zero': ['missing historical runs', 'complete authoring effort', 'upstream pretraining', 'actual host/model billing', 'unmeasured bootstrap/source probes'],
            'new_explicit_paid_transactions_in_this_reproduction': 0,
            'customer_acceptance_or_sales_observed_in_this_reproduction': False,
            'revenue_profit_or_human_productivity_comparison_established': False
        },
        'preservation': {
            'included': 'All complete producer outputs, independent check receipts, original raw rejection, explicit projection and residual bytes, setup attempts, focused failures, logs and recovery/operator evidence.',
            'excluded': 'Public input archives/raw DNA input pixels, third-party weights/upstream package archives and environments, private correspondence drafts, and temporary editorial/browser artifacts.',
            'exclusion_rule': 'Identified public upstream inputs are retrieved separately. No reported scientific prediction, adverse result or measured cost is removed.',
            'receipt_bindings': [binding(STAGING / name, STAGING) for name in important]
        }
    }
    for source, target in copies.items():
        require(inventory(OBSERVED / source) == source_inventories[source] == inventory(STAGING / target),
                'Source evidence changed while staging: ' + source)
    for path, target in flat_copies:
        expected = flat_identities[target]
        require(path.stat().st_size == (STAGING / target).stat().st_size == expected['bytes'] and
                digest(path) == digest(STAGING / target) == expected['sha256'],
                'Receipt or log changed while staging: ' + target)
    require(inventory(raw) == raw_inventory, 'Observed raw classical evidence changed during assembly')
    for path, expected in READ_IDENTITIES.items():
        require(path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'],
                'A validated input changed before assembly completed: ' + str(path))
    # No COMPLETE provenance is written until every source and copy is stable.
    (STAGING / 'REPRODUCTION.json').write_text(json.dumps(provenance, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': 'ASSEMBLED', 'staging': str(STAGING),
                      'files': len(inventory(STAGING)), 'registered_files_unchanged': len(registered_files)}, indent=2))


if __name__ == '__main__':
    main()
