# AGI ALPHA Flywheel: developer instructions

## Current mandate

Build publicly in this repository: visible branches/PRs, GitHub Actions, qualified integration and releases, then an actual released-system run. Check current main, exact candidate source, current owners and existing work before changing anything; old completed assignments are not active ownership. Use the canonical `AGENTS.md`, not a competing `Agent.md`.

Read [the developer/mechanism guide](docs/harness/DEVELOPER_GUIDE.md), [operator guide](docs/connected014/OPERATOR.md) and [resource policy](docs/harness/RESOURCE_POLICY.md). These current instructions supersede older blanket failure-file retention, stale campaign renewal gates and obsolete owner labels. Historical source snapshots, outcomes and permissions still describe their original scope.

## Invent the complete productive arrangement

The defining shift is **from optimizing an enterprise to constructing the conditions under which better enterprises become possible**. Discover the valuable outcome, the means of producing and verifying it, and the arrangement that makes each participant's involvement worthwhile—together. The object of invention is the complete productive arrangement, not a transaction counter, a catalogue of mechanisms or dependence on this machine.

Search jointly over beneficiary outcomes, production methods, measurement/verification, financing, incentives and allocation of work and risk. The missing means may be an interface, process, instrument, representation, contract or coordination arrangement rather than a new algorithm. Compare strong existing complete alternatives, including human-plus-AI, self-service, partners and no purchase. Participation must be voluntary and worthwhile under explicit outside options; never force demand, hide risks, manufacture dependency or infer consent from modeled surplus. A proposed contract or partner is not an executed agreement or spending authority.

Aim to expand the valuable outcomes that can be sustainably achieved through voluntary cooperation. Count construction, search, unsuccessful attempts, acquisition, production, checking, maintenance, financing and residual obligations. Use real available native cash for actions; uncertain future value is a planning input, not revenue or funding. Profit supports continuation, but maximizing transaction count or organizational complexity is not the objective.

Seek a connected sequence: cycle one creates a useful capability, information, relationship, productive asset or unrestricted earnings that makes a specific successor economically reachable. Demonstrate the successor's acceptance and full costs, and distinguish **financed by**, **enabled by**, and merely **later than**. For a new causal enabling claim, compare against the strongest feasible route without that cycle-created asset under matched starting resources. Better equipment is not by itself a better inventor: improved discovery of such sequences is a further claim requiring fresh equal-content and strong conventional controls. This mission is not a claim that the current finite mechanisms have already delivered a full transformational breakthrough.

## Learn, consolidate, delete

- After an attempt, keep a short **tried → outcome → why (or unknown) → next/avoid** lesson. Consolidate repeated lessons by failure class; improve the fix, regression or applicability rule rather than accumulating transcripts.
- Delete redundant terminal failure logs, ZIPs, dumps and intermediate output from the current Git tree after extracting the useful lesson. Keep useful code even when one experiment loses. Do not replace deleted bulk with another archive or an ever-growing failure catalogue.
- Keep working mechanisms, compact successful results, reproducible inputs/procedures, acceptance checks and essential source provenance. Preserve complete accounting: incurred costs including failed attempts, refunds, liabilities, reservations and uncertainty. Do not erase losses, cherry-pick seeds or relabel failure as success.
- Before deletion, check actual readers, manifests, source maps, recovery needs and tests. A historical hash mention alone is not a permanent storage requirement: point descriptive historical references to a pinned commit. Migrate genuine executable dependencies safely; never claim removed inputs remain self-contained.
- Preserve live/needed recovery state, keys and account authority. Use normal recoverable commits; do not rewrite Git history, purge remote artifacts/releases irreversibly or change access without the required authorization. Never publish secrets.
- Keep [lean lessons](docs/packaging/LEAN_EXPERIMENTS.md) concise. Review retained material by usefulness, applicability and replacement value, pruning obsolete duplicates. Finite memory cannot retain infinite information: the goal is continued learning through compression and selective retention, not unlimited lossless memory. This policy is not a claim that automatic memory compaction is implemented.

## Execute safely and quickly

Use existing authorized resources and actual platform limits; do not invent CPU/memory/disk grants or repeated renewal approvals for ordinary authorized engineering. Keep experiments finite and preregister their comparisons, stopping conditions and costs. Preserve security, resource-safety and qualification guards; do not retroactively turn an old limit failure into a pass. No extra purchases, paid external services, real transactions, outreach, private-data access or credential changes without appropriate authority.

The operating entry point is `python3 -m connected_enterprise run --output /absolute/new/enterprise`. Reuse `JournalAccount` and the mandatory adaptive `Account`, not another ledger. Audit current cash and obligations and reserve atomically before every paid action. Future profits are not spendable cash. Resume/upgrade authenticated accounts without reseeding, copying balances or discarding liabilities. Audit and recovery must reject unsafe histories independently of the producer.

## Use strong mechanisms; earn claims

Start at the frontier of relevant knowledge: consult current primary sources and the strongest proven methods, reuse established results and work on the actual gap rather than rediscovering basics. Keep research bounded and decision-relevant, not an endless literature-screening gate. Use competent strong comparators and disclose assumptions and unknowns.

Adopt strong mechanisms from established theory, economics, engineering and successful historical practice without demanding a new research proof for each adoption. Cite the basis, check assumptions/applicability and test correct implementation. Game-theoretic optimality is conditional on its model, information and incentives; historical success supports use, not universality. Ordinary profitable activity does not require a novel invention advantage. Reserve new research proofs for genuinely new claims beyond established knowledge and expected human foresight. Routine correctness, security, cash-conservation and truthful outcome checks still apply; they are not a new research project at every step.

Use structural mapping, executable strategy construction/composition, evidence-grounded criticism, independent verification, adjudicated repair and applicability-aware retained procedures when they improve a real decision or outcome. See the guide for actual call paths, optional policies and limitations. A named module, template, mock or developer-written repair is not demonstrated autonomous discovery. When claiming a new retained-method advantage, compare on fresh work against equal-content ordinary reuse and strong conventional controls; include acquisition and verification costs. Do not impose that research claim as a prerequisite for using an established mechanism. Keep the incumbent when a relevant comparison shows it wins. Do not force invention or fixed R&D spending into profitable commerce.

Report commercial success, invention, retained-method advantage and physical/scientific expansion separately. Transformational work must remove a consequential constraint and validate the enabling instrument; routine repair is not automatically transformation. Optimality claims apply only to the tested feasible set, information and assumptions, never to all strategies or markets.

### Practical invention and operating loop

1. Discover and compare valuable complete outcomes jointly with their production and participation arrangements. Then freeze the selected permissions and acceptance contract for execution; distinguish hard constraints from assumptions and prerequisites of the current method. Do not silently relax acceptance after seeing results. Start from the strongest applicable known complete alternative.
2. Identify the binding constraint. Compare direct execution, reuse, causal transfer, complementary composition, a missing connector/instrument, and changing the process so the constraint no longer matters. Change the means, not the required outcome.
3. Make the proposal executable: permitted inputs, current state, prerequisites, actions/branches, outputs, effects, complete costs and stopping conditions. Check interfaces and shared resources; a sequence of impressive names is not a working mechanism.
4. Let evidence-grounded criticism propose a checkable counterexample or discriminating test. Adjudicate before repair. Resolve important uncertainty, act acceptably despite it, remove the dependency, or stop; consider that all initial explanations may be wrong.
5. Prefer production that carries source/dependency evidence over repeatedly reconstructing it. Reuse compatible generic work, but establish current task acceptance and authority. Critic agreement and internally consistent references alone do not establish truth.
6. Keep the useful executable instrument, concise applicability/avoidance lesson and, when supported, its constructor. Prune redundant terminal files. A working tool, successful transfer and a better discovery procedure are separate achievements.
7. Choose the next action jointly across profitable delivery, acquisition, reuse, enabling research and retaining cash. Use actual available funds and obligations, not forecast profit. Do not force novelty, a fixed research share or a fixed mechanism sequence.

Use the guide's [practical recipes](docs/harness/DEVELOPER_GUIDE.md#practical-recipes) for conditions, outputs, real call paths and remaining gaps. Established methods need applicability and implementation checks, not a fresh invention claim; new beyond-established-knowledge claims need evidence proportionate to that claim.

## Objective and completion

Build for open-ended profitable expansion: **no arbitrary ceiling on buyers, businesses, services, transactions or profit**. US$3 billion trailing-year profit after complete modeled costs remains a notification milestone, not a maximum. Support US$100 billion annual profit as an engineering stress case, not an upper limit or an achieved result; larger supported cases must remain possible. Profit is not revenue, cash, valuation or cumulative multi-year profit. Separate native executed/audited simulation, conditional projections and actual commerce. State horizon, capital, cost scope, uncertainties and outstanding obligations; unknown model/host billing remains unknown. Simulation does not establish actual customers or revenue, and no scale outcome is guaranteed.

Remove arbitrary business-scale rejection limits rather than merely raising their constants. Use scalable state, streaming/batching or equivalent execution and validated aggregation, with meaningful workload and financial-conservation tests—not just large-integer acceptance. Finite experiment horizons and actual platform capacity, liquidity, obligations, permissions and security remain enforceable. A resource-bounded checkpoint is not a universal commercial ceiling. Do not weaken guards or alter historical cohorts to manufacture scale.

Completion requires source-matched tests, independent review, normal qualified merge, public release and verified operation from that release—not just a plan, local pass or successful workflow badge. Report blockers exactly and continue independent useful work. Never claim a message was delivered, a task is active, a merge happened or a result is qualified without a receipt. Update concise developer guidance when an implementation or its qualification changes; preserve historical facts without preserving unnecessary bulk.

