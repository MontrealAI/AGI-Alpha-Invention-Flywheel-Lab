#pragma once
#include "../ops/normalization.hpp"
#include "../core.hpp"
#include "../shared/percentile.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <utility>

namespace vcr::transforms {
inline ChannelPlan channel_parameters(const Normalize&, const Array&, Random&) { return {}; }

namespace normalization_detail {
using percentile_detail::percentile;
using percentile_detail::sorted_percentile;
// The robust scale: 1.4826 MAD, else the first usable fallback.
VCR_HD inline double robust_scale(double mad, double deviation, double span) {
    double scale = 1.4826 * mad;
    if (std::isfinite(scale) && scale >= 1e-6) return scale;
    if (std::isfinite(deviation) && std::fabs(deviation) >= 1e-6) return std::fabs(deviation);
    if (std::isfinite(span) && std::fabs(span) / 2 >= 1e-6) return std::fabs(span) / 2;
    return 1;
}
// (x-lower)/span, or (x-median)/(span/2); zero span gives zeros or scale one.
VCR_HD inline double percentile_scale(double low, double high, bool median) {
    const double scale = median ? .5 * (high - low) : high - low;
    if (std::isfinite(scale) && scale >= 1e-6) return scale;
    return median ? 1 : 0;
}
template<class T> VCR_HD T clamp_to(T x, double low, double high) {
    const T lo = T(low), hi = T(high);
    return x < lo ? lo : x > hi ? hi : x;
}
template<class T> VCR_HD T finite_or_zero(double x) {
    const T value = T(x);
    return std::isfinite(value) ? value : T(0);
}

// Retain the reader's fixed segment boundaries and ordered float64 sums.
// Transform pipelines have no internal CPU worker pool.
template<class F> void for_parts(std::size_t count, F&& fn) {
    for (std::size_t i = 0; i < count; ++i) fn(i);
}
inline void require_finite(double v) {
    if (!std::isfinite(v)) throw std::invalid_argument("normalization requires finite crop values");
}
// Unmasked float32 z-score needs neither extrema nor overflow rescaling:
// even FLT_MAX squared, summed over a size_t-sized image, fits in double.
// Four independent sums expose SIMD without reassociating compiler flags.
// Keep the mean/subtraction wide for small deviations on a large baseline.
inline void zscore_float(float* values, std::size_t n, double eps) {
    if (!n) return;
    double sums[4]={};
    std::size_t i=0;
    for (;i+4<=n;i+=4)
        for (int j=0;j<4;++j) sums[j]+=double(values[i+j]);
    double sum=(sums[0]+sums[1])+(sums[2]+sums[3]);
    for (;i<n;++i) sum+=double(values[i]);
    require_finite(sum);
    const double mean=sum/double(n);
    double squares[4]={}; i=0;
    for (;i+4<=n;i+=4)
        for (int j=0;j<4;++j) { const double d=double(values[i+j])-mean; squares[j]+=d*d; }
    double squared=(squares[0]+squares[1])+(squares[2]+squares[3]);
    for (;i<n;++i) { const double d=double(values[i])-mean; squared+=d*d; }
    if (!squared) { std::fill(values,values+n,0.f); return; }
    const double divisor=std::max(std::sqrt(squared/double(n)),eps);
    const double inverse=1/divisor;
    for (i=0;i<n;++i) values[i]=float((double(values[i])-mean)*inverse);
}
// Fixed segments and ordered reductions: the answer does not depend on worker
// count or completion order. Statistics use float64, on the converted output.
template <class T>
void normalize_crop(T* values, std::size_t n, const Normalize& t, const std::uint8_t* valid)
{
    if (!n) return;
    if constexpr (std::is_same_v<T,float>) {
        // Up to 2^29 values, a constant float32 image has an exact double
        // sum (24 significand bits + 29 count bits). Larger arrays retain
        // the extrema check so mean rounding cannot turn a constant into ±1.
        if (t.mode==Normalization::ZScore && !t.nonzero && !valid && n <= (std::size_t{1}<<29)) {
            zscore_float(values,n,t.eps);
            return;
        }
    }
    const bool nonzero = t.mode == Normalization::ZScore && t.nonzero;
    const auto skip = [&](std::size_t i) { return (valid && !valid[i]) || (nonzero && values[i] == T{0}); };
    constexpr std::size_t grain = 65536;
    const std::size_t parts = (n + grain - 1) / grain;
    struct Stats {
        double lo = std::numeric_limits<double>::infinity();
        double hi = -std::numeric_limits<double>::infinity();
        double sum = 0;
        std::size_t count = 0;
    };
    std::vector<Stats> stats(parts);
    for_parts(parts, [&](std::size_t part) {
        // Accumulate in registers, publishing once per segment. Updating the
        // shared vector in this loop causes false sharing between workers.
        Stats s;
        for (std::size_t i = part * grain; i < std::min(n, (part + 1) * grain); ++i) {
            if (skip(i)) continue;
            const double v = values[i];
            require_finite(v);
            s.lo = std::min(s.lo, v); s.hi = std::max(s.hi, v);
            s.sum += v; ++s.count;
        }
        stats[part] = s;
    });
    double lo = stats[0].lo, hi = stats[0].hi;
    std::size_t count = 0;
    for (const auto& s : stats) { lo = std::min(lo, s.lo); hi = std::max(hi, s.hi); count += s.count; }
    if (!count || (lo == hi && t.eps == 0)) {
        for_parts(parts, [&](std::size_t p) {
            std::fill(values + p * grain, values + std::min(n, (p + 1) * grain), T{0});
        });
        return;
    }
    double scale = 1, center = lo, divisor = hi - lo;
    if (t.mode == Normalization::MinMax) {
        if (!std::isfinite(divisor)) { scale = 2; center = lo / scale; divisor = hi / scale - center; }
        divisor = std::max(divisor, t.eps / scale);
    } else {
        const double magnitude = std::max(std::abs(lo), std::abs(hi));
        // Scale extreme finite doubles so sums of squared deviations cannot
        // overflow/underflow. Ordinary CT values take the unscaled path.
        if (magnitude > 1e150 || magnitude < 1e-150) {
            scale = magnitude;
            for_parts(parts, [&](std::size_t p) {
                double sum = 0;
                for (std::size_t i = p * grain; i < std::min(n, (p + 1) * grain); ++i)
                    if (!skip(i)) sum += static_cast<double>(values[i]) / scale;
                stats[p].sum = sum;
            });
        }
        center = 0;
        for (const auto& s : stats) center += s.sum / static_cast<double>(count);
        for_parts(parts, [&](std::size_t p) {
            double squared = 0;
            for (std::size_t i = p * grain; i < std::min(n, (p + 1) * grain); ++i) {
                if (skip(i)) continue;
                const double d = static_cast<double>(values[i]) / scale - center;
                squared += d * d;
            }
            stats[p].sum = squared;
        });
        double variance = 0;
        for (const auto& s : stats) variance += s.sum / static_cast<double>(count);
        divisor = std::max(std::sqrt(variance), t.eps / scale);  // population standard deviation, ddof=0
    }
    if constexpr(std::is_same_v<T,float>) if(t.mode==Normalization::MinMax && scale==1 && std::isfinite(float(divisor)) && divisor!=0) {
        const float low=float(center), range=float(divisor);
        for(std::size_t i=0;i<n;++i) values[i]=(values[i]-low)/range;
        return;
    }
    // Unselected nonzero voxels (outside a validity mask) use the same formula.
    for_parts(parts, [&](std::size_t p) {
        for (std::size_t i = p * grain; i < std::min(n, (p + 1) * grain); ++i)
            values[i] = (nonzero && values[i] == T{0}) || divisor == 0 ? T{0}
                : static_cast<T>((static_cast<double>(values[i]) / scale - center) / divisor);
    });
}
// Surface volumes are uint8, so their float crops hold at most 256 distinct
// values. Then every order statistic is a histogram bin, and the output is a
// 256-entry table of the same per-value expression: the result is identical
// to the general path below. The CUDA backend counts the bins on the device
// and builds the same table with uint8_order_table.
// The bin of a value that is an integer in [0, 255]; -0.0 has none, because
// the general path keeps its sign.
template<class T> VCR_HD bool uint8_bin(T v, unsigned& b) {
    if (!(v >= T(0) && v <= T(255)) || std::signbit(v)) return false;
    b = static_cast<unsigned>(v);
    return T(b) == v;
}
// Counts the selected values into 256 bins; false, when a value has no bin.
template<class T>
bool uint8_histogram(const T* values, std::size_t n, const std::uint8_t* valid, unsigned long long* count) {
    std::fill(count, count + 256, 0ull);
    for (std::size_t i = 0; i < n; ++i) {
        unsigned b;
        if (!uint8_bin(values[i], b)) return false;
        if (!valid || valid[i]) ++count[b];
    }
    return true;
}
// The output value of each bin. False selects the general path: no value is
// selected, or the robust scale is degenerate (its std fallback is an ordered
// float64 sum over the voxels). Options holds Normalize's mode and percentiles.
template<class T, class Options>
bool uint8_order_table(const unsigned long long* count, const Options& t, T* table) {
    std::array<std::size_t, 256> below{};  // number of selected values < bin + 1
    std::size_t selected = 0;
    for (std::size_t b = 0; b < 256; ++b) below[b] = selected += count[b];
    if (!selected) return false;
    const auto bin_at = [&](std::size_t k) {  // value of rank k
        return std::size_t(std::upper_bound(below.begin(), below.end(), k) - below.begin());
    };
    const auto order = [&](auto&& map, double percent) {
        return sorted_percentile([&](std::size_t k) { return map(bin_at(k)); }, selected, percent);
    };
    const auto raw = [](std::size_t b) { return double(T(b)); };
    const bool clip = t.mode == Normalization::Percentile || t.clip;
    double low = raw(bin_at(0)), high = raw(bin_at(selected - 1));
    if (clip) { low = order(raw, t.lower); high = order(raw, t.upper); }
    // Clamping is monotone, so ranks of the clipped values are ranks of the bins.
    const auto clipped = [&](std::size_t b) { return double(clip ? clamp_to(T(b), low, high) : T(b)); };
    double center, scale;
    if (t.mode == Normalization::Percentile) {
        scale = percentile_scale(low, high, t.median);
        center = t.median ? order(clipped, 50) : low;
        if (scale == 0) { std::fill(table, table + 256, T{0}); return true; }
    } else {
        center = order(clipped, 50);
        std::array<std::pair<double, std::size_t>, 256> deviations;
        std::size_t used = 0;
        for (std::size_t b = 0; b < 256; ++b)
            if (count[b]) deviations[used++] = {std::abs(clipped(b) - center), std::size_t(count[b])};
        std::sort(deviations.begin(), deviations.begin() + used);
        std::array<std::size_t, 256> upto{};
        for (std::size_t j = 0, total = 0; j < used; ++j) upto[j] = total += deviations[j].second;
        const double mad = sorted_percentile([&](std::size_t k) {
            return deviations[std::size_t(std::upper_bound(upto.begin(), upto.begin() + used, k) - upto.begin())].first;
        }, selected, 50);
        scale = 1.4826 * mad;
        if (!(std::isfinite(scale) && scale >= 1e-6)) return false;
    }
    for (std::size_t b = 0; b < 256; ++b) table[b] = finite_or_zero<T>((clipped(b) - center) / scale);
    return true;
}
// Returns false, without touching values, when the general path must run.
template<class T>
bool normalize_order_uint8(T* values, std::size_t n, const Normalize& t, const std::uint8_t* valid) {
    std::array<unsigned long long, 256> count;
    std::array<T, 256> table;
    if (!uint8_histogram(values, n, valid, count.data()) || !uint8_order_table(count.data(), t, table.data())) return false;
    for (std::size_t i = 0; i < n; ++i) values[i] = table[static_cast<unsigned>(values[i])];
    return true;
}
template<class T>
void normalize_order(T* values, std::size_t n, const Normalize& t, const std::uint8_t* valid) {
    if (!n) return;
    if (normalize_order_uint8(values, n, t, valid)) return;
    std::vector<T> selected;
    double sum = 0;
    for (std::size_t i = 0; i < n; ++i) {
        require_finite(double(values[i]));
        if (!valid || valid[i]) { selected.push_back(values[i]); sum += double(values[i]); }
    }
    const double lo = double(*std::min_element(selected.begin(), selected.end()));
    const double hi = double(*std::max_element(selected.begin(), selected.end()));
    double deviation = 0;
    if (t.mode == Normalization::Robust) {
        // Population standard deviation before clipping, for the fallback scale.
        const double mean = sum / double(selected.size());
        for (auto v : selected) deviation += (double(v) - mean) * (double(v) - mean);
        deviation = std::sqrt(deviation / double(selected.size()));
    }
    const bool clip = t.mode == Normalization::Percentile || t.clip;
    double low = lo, high = hi;
    if (clip) {
        low = percentile(selected, t.lower); high = percentile(selected, t.upper);
        for (std::size_t i = 0; i < n; ++i) values[i] = clamp_to(values[i], low, high);
        for (auto& v : selected) v = clamp_to(v, low, high);
    }
    double center, scale;
    if (t.mode == Normalization::Percentile) {
        scale = percentile_scale(low, high, t.median);
        center = t.median ? percentile(selected, 50) : low;
        if (scale == 0) { std::fill(values, values + n, T{0}); return; }
    } else {
        center = percentile(selected, 50);
        std::vector<double> deviations(selected.size());
        for (std::size_t i = 0; i < selected.size(); ++i) deviations[i] = std::abs(double(selected[i]) - center);
        scale = robust_scale(percentile(deviations, 50), deviation, high - low);
    }
    for (std::size_t i = 0; i < n; ++i) values[i] = finite_or_zero<T>((double(values[i]) - center) / scale);
}
template<class T> void normalize_fixed(T* values, std::size_t n, const Normalize& t) {
    for (std::size_t i = 0; i < n; ++i) {
        require_finite(double(values[i]));
        values[i] = finite_or_zero<T>((double(clamp_to(values[i], t.low, t.high)) - t.center) / t.scale);
    }
}
template<class T> void normalize_channel(T* values, std::size_t n, const Normalize& t, const std::uint8_t* valid) {
    if (t.mode == Normalization::Fixed) normalize_fixed(values, n, t);
    else if (t.mode == Normalization::Robust || t.mode == Normalization::Percentile) normalize_order(values, n, t, valid);
    else normalize_crop(values, n, t, valid);
}
// Per-voxel selection for masked statistics; empty when none is valid.
inline std::vector<std::uint8_t> valid_voxels(const Sample& s, const std::string& key, std::size_t channel) {
    const auto& f = s.at(key);
    if (!s.count(f.target.valid)) return {};
    const auto& mask = s.at(f.target.valid).array;
    const auto n = product(mask.spatial()), offset = (mask.shape[0] == 1 ? 0 : channel) * n;
    std::vector<std::uint8_t> valid(n); bool any = false;
    for (std::size_t i = 0; i < n; ++i) any |= bool(valid[i] = mask.get(offset + i) != 0);
    if (!any) valid.clear();
    return valid;
}
} // namespace normalization_detail
inline void apply(const Normalize& t, Sample& s, const Parameters& p) {
    for (const auto& c : p.channels) {
        auto& a = s.at(c.key).array;
        const auto n = product(a.spatial());
        const auto valid = t.masked ? normalization_detail::valid_voxels(s, c.key, c.channel) : std::vector<std::uint8_t>{};
        const auto* flags = valid.empty() ? nullptr : valid.data();
        if (a.bytes == 4) normalization_detail::normalize_channel(static_cast<float*>(a.data())+c.channel*n,n,t,flags);
        else normalization_detail::normalize_channel(static_cast<double*>(a.data())+c.channel*n,n,t,flags);
    }
    restore_valid(s);
}
} // namespace vcr::transforms
