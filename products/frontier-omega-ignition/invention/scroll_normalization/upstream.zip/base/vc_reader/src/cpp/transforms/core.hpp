#pragma once
// Independent of Python, Torch, the reader, and process-global RNG/thread state.
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <limits>
#include <map>
#include <memory>
#include <numeric>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <variant>
#include <vector>
#include "../rounding.hpp"

// Helpers shared by CPU and CUDA implementations.
#ifdef __CUDACC__
#define VCR_HD __host__ __device__
#else
#define VCR_HD
#endif
// Hot CPU loops also get an AVX2 clone, chosen at load time on x86-64 ELF (Linux) builds.
// The clone has no FMA, so each lane performs the same IEEE operations as the baseline
// SSE2 code: results are bit-identical. Elsewhere (macOS, arm64 NEON, CUDA) this is empty.
// GCC only: Clang (through 21) rejects target_clones on function templates.
#if defined(__x86_64__) && defined(__ELF__) && defined(__GNUC__) && !defined(__clang__) && !defined(__CUDACC__) && !defined(VCR_NO_TARGET_CLONES)
#ifndef VCR_CLONE_ISA
#ifdef VCR_CLONE_FMA
#define VCR_CLONE_ISA "arch=x86-64-v3"  // AVX2 with FMA: contracted products round once
#else
#define VCR_CLONE_ISA "avx2"
#endif
#endif
#define VCR_TARGET_CLONES __attribute__((target_clones(VCR_CLONE_ISA, "default")))
#else
#define VCR_TARGET_CLONES
#endif

namespace vcr::transforms {
inline void require(bool ok, const char* message) {
    if (!ok) throw std::invalid_argument(message);
}
inline void require(bool ok, const std::string& message) {
    if (!ok) throw std::invalid_argument(message);
}
inline void probability(double p) { require(std::isfinite(p) && p >= 0 && p <= 1, "probability must be in [0, 1]"); }
using Shape = std::vector<std::size_t>;
inline std::size_t product(const Shape& shape) {
    std::size_t n = 1;
    for (auto s : shape) {
        require(s == 0 || n <= std::numeric_limits<std::size_t>::max() / s, "shape overflow");
        n *= s;
    }
    return n;
}
struct Grid {
    Shape shape, stride;
    std::size_t size;
    explicit Grid(Shape s) : shape(std::move(s)), stride(shape.size()), size(product(shape)) {
        require(!shape.empty() && shape.size() <= 3 && size, "expected nonempty 1D, 2D or 3D spatial grid");
        std::size_t step = 1;
        for (auto a = shape.size(); a-- > 0;) { stride[a] = step; step *= shape[a]; }
    }
    std::size_t coord(std::size_t i, std::size_t a) const { return i / stride[a] % shape[a]; }
};
inline std::string axes(std::size_t dim) { require(dim == 2 || dim == 3, "expected 2D or 3D spatial data"); return dim == 3 ? "zyx" : "yx"; }
inline int axis(char c, std::size_t dim) {
    auto pos = axes(dim).find(c); require(pos != std::string::npos, "axis is not present in the sample"); return int(pos);
}

struct Random {
    std::uint64_t state;
    VCR_HD std::uint64_t next() {
        auto z = (state += UINT64_C(0x9e3779b97f4a7c15));
        z = (z ^ (z >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
        z = (z ^ (z >> 27)) * UINT64_C(0x94d049bb133111eb);
        return z ^ (z >> 31);
    }
    VCR_HD double uniform() { return (double(next() >> 11) + 0.5) * 0x1.0p-53; }
    bool chance(double p) { probability(p); return uniform() < p; }
    std::size_t index(std::size_t n) {
        require(n > 0, "cannot sample an empty choice");
        auto threshold = (std::uint64_t(0) - n) % n;
        std::uint64_t value; do { value = next(); } while (value < threshold);
        return value % n;
    }
    double normal() { return std::sqrt(-2 * std::log(uniform())) * std::cos(6.2831853071795864769 * uniform()); }
    // Noise kernels consume both independent outputs. Keep normal() unchanged:
    // parameter sampling and elastic control lattices retain their RNG stream.
    template<class T = double> std::array<T, 2> normal_pair() {
        // Match image precision for the expensive transcendental operations.
        // uniform() is strictly positive, including after conversion to float.
        const T radius = std::sqrt(T(-2) * std::log(T(uniform())));
        const T angle = T(6.2831853071795864769) * T(uniform());
        return {radius * std::cos(angle), radius * std::sin(angle)};
    }
};
inline std::uint64_t split_seed(std::uint64_t base, const std::string& name) {
    // Stable across processes, standard libraries, and platforms.
    for (unsigned char c : name) { base ^= c; base *= UINT64_C(1099511628211); }
    Random r{base}; return r.next();
}
// A seed from identifiers (epoch, sample index, path...), each an integer in decimal or a
// string. Stable like split_seed; an integer and a string with the same text differ.
struct SeedPart { bool text = false; std::string value; };
inline SeedPart seed_part(std::string value) { return {true, std::move(value)}; }
inline SeedPart seed_part(std::int64_t value) { return {false, std::to_string(value)}; }
inline std::uint64_t make_seed(const std::vector<SeedPart>& parts) {
    std::uint64_t value = UINT64_C(14695981039346656037);
    for (const auto& part : parts)
        value = split_seed(value, (part.text ? "s" : "i") + std::to_string(part.value.size()) + ":" + part.value);
    return value;
}
struct Uniform { double low, high; };
struct Normal { double mean = 0, std = .1; };
struct Choice { std::vector<double> values; };
// A value supplied per sample at call time (params={name: value}); it draws no
// random numbers, so other parameters keep their streams.
struct Named { std::string name; };
using Scalar = std::variant<double, Uniform, Normal, Choice, Named>;
using NamedValues = std::map<std::string, double>;
inline const NamedValues*& named_values() { thread_local const NamedValues* values = nullptr; return values; }
struct NamedScope {
    const NamedValues* previous;
    explicit NamedScope(const NamedValues* values) : previous(named_values()) { named_values() = values; }
    ~NamedScope() { named_values() = previous; }
    NamedScope(const NamedScope&) = delete;
};
inline double draw(const Scalar& value, Random& r) {
    double result = std::visit([&](const auto& v) -> double {
        using T = std::decay_t<decltype(v)>;
        if constexpr (std::is_same_v<T, double>) return v;
        else if constexpr (std::is_same_v<T, Uniform>) {
            require(std::isfinite(v.low) && std::isfinite(v.high) && v.low <= v.high, "invalid uniform range");
            return v.low + (v.high - v.low) * r.uniform();
        } else if constexpr (std::is_same_v<T, Normal>) {
            require(std::isfinite(v.mean) && std::isfinite(v.std) && v.std >= 0, "invalid normal distribution");
            return v.mean + v.std * r.normal();
        } else if constexpr (std::is_same_v<T, Choice>) return v.values[r.index(v.values.size())];
        else {
            const auto* values = named_values();
            require(values && values->count(v.name), "missing per-sample parameter: " + v.name);
            return values->at(v.name);
        }
    }, value);
    require(std::isfinite(result), "sampled parameter must be finite"); return result;
}
inline int draw_integer(const Scalar& value, Random& r) {
    if (const auto* u = std::get_if<Uniform>(&value)) {
        require(u->low >= 0 && u->high <= 100000 && u->low <= u->high &&
                std::floor(u->low) == u->low && std::floor(u->high) == u->high, "invalid integer range");
        return int(u->low) + int(r.index(std::size_t(u->high - u->low + 1)));
    }
    auto v = draw(value, r);
    require(v >= 0 && v <= 100000 && std::floor(v) == v, "expected nonnegative integer parameter"); return int(v);
}

// Aligned storage with copy-on-write input views. Array copies always own their
// data; the binding retains borrowed owners until export. Nearest/permutation
// operations copy bytes, including
// int64/uint64 labels that cannot be represented exactly as floating point.
struct Array {
    Shape shape;
    char kind = 'f';
    std::size_t bytes = 4;
    std::unique_ptr<std::uint64_t[]> storage;
    const void* borrowed = nullptr;
    std::string owner;
    bool writable = false;
    // Optional destination for this view's copy-on-write (e.g. its slot of a batch output),
    // of the array's size. Copies of the array never carry it.
    void* spare = nullptr;
    // Optional float32 destination of this uint8 image's widened form (its batch output slot).
    void* widened = nullptr;
    Array() = default;
    void allocate(bool clear) {
        const auto words = std::max<std::size_t>(1, (size() * bytes + 7) / 8);
        storage = std::make_unique_for_overwrite<std::uint64_t[]>(words);
        if (clear) std::fill_n(storage.get(), words, 0);
    }
    Array(const Array& other) : shape(other.shape), kind(other.kind), bytes(other.bytes) {
        if (!other.data()) return;
        allocate(false);
        if (size()) std::memcpy(storage.get(), other.data(), size() * bytes);
    }
    Array& operator=(const Array& other) {
        if (this != &other) { Array copy(other); *this = std::move(copy); }
        return *this;
    }
    Array(Array&&) noexcept = default;
    Array& operator=(Array&&) noexcept = default;
    Array(Shape s, char k = 'f', std::size_t b = 4, const void* input = nullptr,
          std::string source = {}, bool inplace = false, bool zero = true)
        : shape(std::move(s)), kind(k), bytes(b), borrowed(input), owner(std::move(source)), writable(inplace) {
        require((k == 'f' && (b == 4 || b == 8)) || ((k == 'i' || k == 'u') && (b == 1 || b == 2 || b == 4 || b == 8)) || (k == 'b' && b == 1), "unsupported array dtype");
        require(size() <= (std::numeric_limits<std::size_t>::max() - 7) / b, "array size overflow");
        if (!borrowed) allocate(zero);
    }
    // For kernels that write every output element before exposing the array.
    static Array uninitialized(Shape shape, char kind, std::size_t bytes) {
        return Array(std::move(shape), kind, bytes, nullptr, {}, false, false);
    }
    std::size_t size() const { return product(shape); }
    void* data() {
        if (borrowed && !writable && spare) {
            if (size()) std::memcpy(spare, borrowed, size() * bytes);
            borrowed = spare; spare = nullptr; writable = true;
        }
        if (borrowed && !writable) {
            allocate(false);
            if (size()) std::memcpy(storage.get(), borrowed, size() * bytes);
            borrowed = nullptr; owner.clear();
        }
        return borrowed ? const_cast<void*>(borrowed) : storage.get();
    }
    const void* data() const { return borrowed ? borrowed : storage.get(); }
    // Writable storage for kernels that overwrite every element: the spare without copying,
    // the existing storage when writable, else new uninitialized storage.
    void* fresh() {
        if (borrowed && !writable && spare) { borrowed = spare; spare = nullptr; writable = true; }
        else if (borrowed && !writable) { allocate(false); borrowed = nullptr; owner.clear(); }
        return data();
    }
    Shape spatial() const { require(shape.size() >= 2, "expected a channel-first spatial array"); return Shape(shape.begin() + 1, shape.end()); }
    template<class F> decltype(auto) typed(F&& f) const {
        if (kind == 'f') { if (bytes == 4) return f(static_cast<const float*>(data())); return f(static_cast<const double*>(data())); }
        if (kind == 'b' || kind == 'u') {
            if (bytes == 1) return f(static_cast<const std::uint8_t*>(data()));
            if (bytes == 2) return f(static_cast<const std::uint16_t*>(data()));
            if (bytes == 4) return f(static_cast<const std::uint32_t*>(data()));
            return f(static_cast<const std::uint64_t*>(data()));
        }
        if (bytes == 1) return f(static_cast<const std::int8_t*>(data()));
        if (bytes == 2) return f(static_cast<const std::int16_t*>(data()));
        if (bytes == 4) return f(static_cast<const std::int32_t*>(data()));
        return f(static_cast<const std::int64_t*>(data()));
    }
    double get(std::size_t i) const { return typed([&](const auto* p) { return double(p[i]); }); }
    void require_exact_values() const {
        if ((kind != 'i' && kind != 'u') || bytes != 8) return;
        typed([&](const auto* p) {
            for (std::size_t i = 0; i < size(); ++i)
                require(p[i] >= -9007199254740991. && p[i] <= 9007199254740991.,
                        "value-based label transforms require integer IDs within +/- (2**53 - 1)");
        });
    }
    template<class T> static T checked_cast(double v) {
        if constexpr (std::is_integral_v<T>) {
            // An exclusive power-of-two upper bound also works on platforms
            // where long double cannot represent UINT64_MAX exactly.
            double upper = std::ldexp(1., std::numeric_limits<T>::digits);
            double lower = std::is_signed_v<T> ? -upper : 0;
            require(std::isfinite(v) && v >= lower && v < upper && std::trunc(v) == v,
                    "value is not representable in target dtype");
        }
        return static_cast<T>(v);
    }
    void set(std::size_t i, double v) {
        data();
        typed([&](const auto* p) {
            using T = std::remove_cv_t<std::remove_pointer_t<decltype(p)>>;
            const_cast<T*>(p)[i] = checked_cast<T>(v);
        });
    }
    void copy_element(std::size_t to, const Array& src, std::size_t from) {
        require(kind == src.kind && bytes == src.bytes, "copy dtype mismatch");
        std::memcpy(static_cast<char*>(data()) + to * bytes, static_cast<const char*>(src.data()) + from * bytes, bytes);
    }
    template<class Value = double> std::vector<Value> channel(std::size_t c) const {
        require_exact_values();
        auto n = product(spatial()); require(c < shape[0], "channel out of bounds");
        std::vector<Value> result(n);
        typed([&](const auto* p) { for (std::size_t i = 0; i < n; ++i) result[i] = Value(p[c * n + i]); });
        return result;
    }
    template<class Value> void channel(std::size_t c, const std::vector<Value>& values) {
        auto n = product(spatial()); require(c < shape[0] && values.size() == n, "channel shape mismatch");
        if (kind == 'f') {
            if (bytes == 4) { auto* p = static_cast<float*>(data()) + c * n; for (std::size_t i = 0; i < n; ++i) p[i] = static_cast<float>(values[i]); }
            else std::copy(values.begin(), values.end(), static_cast<double*>(data()) + c * n);
        } else {
            data();
            typed([&](const auto* p) {
                using T = std::remove_cv_t<std::remove_pointer_t<decltype(p)>>;
                auto* dest = const_cast<T*>(p) + c * n;
                for (std::size_t i = 0; i < n; ++i) dest[i] = checked_cast<T>(values[i]);
            });
        }
    }
};

enum class Role { Image, Label, Scalar, Valid, Points, Vectors, VectorField, NormalField, CoordinateField };
struct Target {
    Role role = Role::Image;
    double fill = 0;
    std::string valid = "padding_mask", components = "zyx", outside = "keep";
    bool normalize = false, external = true;
    bool refill = true;  // images: voxels outside the validity mask return to `fill` after each transform
    bool operator==(const Target&) const = default;
};
// Whether a target holds continuous values (labels and validity masks do not).
inline bool continuous(const Target& target) { return target.role != Role::Label && target.role != Role::Valid; }
// The usual training sample: image, label mask, and validity of the image's padding.
inline std::map<std::string, Target> default_targets() {
    Target mask, valid;
    mask.role = Role::Label;
    valid.role = Role::Valid;
    return {{"image", Target{}}, {"mask", mask}, {"padding_mask", valid}};
}
struct Field { Array array; Target target; std::string source; std::vector<Array> pyramid; };
using Sample = std::map<std::string, Field>;
inline bool sparse(Role r) { return r == Role::Points || r == Role::Vectors; }
inline bool directional(Role r) { return r == Role::Vectors || r == Role::VectorField || r == Role::NormalField; }
// uint8 images hold intensities 0..255 (the reader's CT dtype). They stay uint8 until a transform
// needs float32: value-only transforms read them directly, others first widen them, exactly
// (float(x) == x), so results equal those of the same values given as float32. Every image
// leaves a pipeline as float32.
inline bool narrow(const Array& a) { return a.kind == 'u' && a.bytes == 1; }
inline bool narrow_image(const Field& f) { return f.target.role == Role::Image && narrow(f.array); }
// Other continuous uint8 targets are widened when a run starts.
inline bool narrow_continuous(const Field& f) { return continuous(f.target) && narrow(f.array); }
VCR_TARGET_CLONES inline void widen_values(const std::uint8_t* __restrict in, float* __restrict out, std::size_t n) {
    for (std::size_t i = 0; i < n; ++i) out[i] = float(in[i]);
}
// Uninitialized float32 storage of a's shape: its batch slot when it has one.
inline Array widened_storage(const Array& a) {
    if (!a.widened) return Array::uninitialized(a.shape, 'f', 4);
    return Array(a.shape, 'f', 4, a.widened, {}, true);
}
inline void widen(Array& a) {
    if (!narrow(a)) return;
    auto out = widened_storage(a);
    widen_values(static_cast<const std::uint8_t*>(std::as_const(a).data()), static_cast<float*>(out.data()), a.size());
    a = std::move(out);
}
inline void widen_images(Sample& s) { for (auto& [name, f] : s) if (narrow_image(f)) widen(f.array); }
inline Shape sample_shape(const Sample& s) {
    for (const auto& [name, f] : s) if (!sparse(f.target.role)) return f.array.spatial();
    throw std::invalid_argument("sample needs a spatial array");
}
inline void validate(const Sample& s, bool values = true) {
    auto shape = sample_shape(s); auto names = axes(shape.size());
    require(std::all_of(shape.begin(), shape.end(), [](auto extent) { return extent > 0; }), "spatial dimensions must be nonempty");
    for (const auto& [name, f] : s) {
        const auto& a = f.array; const auto& t = f.target;
        if (sparse(t.role)) require(a.shape.size() == 2 && a.shape[1] == shape.size(), name + ": expected (N, D)");
        else require(a.shape.size() >= 3 && a.shape[0] && a.spatial() == shape, name + ": expected channel-first matching spatial shape");
        if (t.role != Role::Label && t.role != Role::Valid)
            require(a.kind == 'f' || narrow(a), name + ": continuous targets require uint8, float32 or float64");
        if (sparse(t.role) || directional(t.role) || t.role == Role::CoordinateField) {
            auto component_dim = t.role == Role::CoordinateField && t.external ? a.shape[0] : shape.size();
            auto order = t.components; std::sort(order.begin(), order.end()); auto expected = axes(component_dim); std::sort(expected.begin(), expected.end());
            require(order == expected, name + ": invalid component order");
            if (!sparse(t.role)) require(a.shape[0] == component_dim, name + ": one channel per component required");
        }
        // Dispatch once. Integer targets are inherently finite; construct error
        // messages only on failure, never in the voxel loop.
        const auto n = a.size();
        if (values && a.kind == 'f') a.typed([&](const auto* values) {
            using V = std::remove_cv_t<std::remove_pointer_t<decltype(values)>>;
            if constexpr (std::is_floating_point_v<V>) {
                // Integer OR reduction vectorizes without relaxed floating-point
                // flags. All-ones exponents identify both infinities and NaNs.
                using Bits = std::conditional_t<sizeof(V) == 4, std::uint32_t, std::uint64_t>;
                constexpr Bits exponent = sizeof(V) == 4 ? Bits(0x7f800000u) : Bits(UINT64_C(0x7ff0000000000000));
                Bits invalid = 0;
                for (std::size_t i = 0; i < n; ++i) invalid |= (std::bit_cast<Bits>(values[i]) & exponent) == exponent;
                if (invalid) throw std::invalid_argument(name + ": nonfinite input; use a validity mask for missing data");
            }
        });
        if (values && t.role == Role::Valid) a.typed([&](const auto* values) {
            for (std::size_t i = 0; i < n; ++i)
                if (values[i] != 0 && values[i] != 1)
                    throw std::invalid_argument(name + ": validity masks must contain only zero or one");
        });
        if (t.role == Role::Image && s.count(t.valid)) {
            const auto& mask = s.at(t.valid);
            require(mask.target.role == Role::Valid && (mask.array.shape[0] == 1 || mask.array.shape[0] == a.shape[0]), name + ": invalid validity-mask association");
        }
        require(t.outside == "keep" || t.outside == "drop" || t.outside == "error", "outside must be keep, drop or error");
    }
}
inline void restore_valid(Sample& s) {
    for (auto& [name, f] : s) {
        if (f.target.role != Role::Image || !f.target.refill || !s.count(f.target.valid)) continue;
        const auto& mask = s.at(f.target.valid).array;
        const bool pseudo = f.source.find('\x1f') != std::string::npos;
        require(mask.spatial() == f.array.spatial() &&
                (mask.shape[0] == 1 || mask.shape[0] == f.array.shape[0] ||
                 (pseudo && f.array.shape[0] % mask.shape[0] == 0)), "validity mask no longer matches image channels");
        auto n = product(f.array.spatial());
        // A uint8 image keeps its dtype when the fill is one of its values.
        if (narrow(f.array) && !(f.target.fill >= 0 && f.target.fill <= 255 && std::trunc(f.target.fill) == f.target.fill)) widen(f.array);
        for (std::size_t i = 0; i < f.array.size(); ++i)
            if (!mask.get(mask.shape[0] == 1 ? i % n : i % mask.size())) f.array.set(i, f.target.fill);
    }
}
template<class T> inline double mean(const std::vector<T>& v) { return std::accumulate(v.begin(), v.end(), 0.0) / v.size(); }
template<class T> inline double deviation(const std::vector<T>& v, double m) {
    double sum = 0; for (auto x : v) sum += (x - m) * (x - m);
    return v.size() > 1 ? std::sqrt(sum / (v.size() - 1)) : 0;
}
VCR_HD inline std::size_t reflect(std::int64_t i, std::size_t n) {
    auto p = static_cast<std::int64_t>(2 * n); i = (i % p + p) % p;
    return static_cast<std::size_t>(i < static_cast<std::int64_t>(n) ? i : p - 1 - i);
}
// Convolution boundaries: reflect repeats the edge sample (SciPy "reflect"),
// mirror does not (Torch "reflect"), nearest replicates it (SciPy "nearest").
// Zero pads with zeros (Torch conv padding); only structure tensors use it.
enum class Boundary { Reflect, Mirror, Nearest, Zero };
VCR_HD inline std::size_t mirror(std::int64_t i, std::size_t n) {
    if (n == 1) return 0;
    auto p = std::int64_t(2 * (n - 1)); i = (i % p + p) % p;
    return std::size_t(i < std::int64_t(n) ? i : p - i);
}
namespace filter_detail {
// Index of a neighbour, or -1 for a zero-padded sample.
VCR_HD inline long long neighbour(long long x, long long n, Boundary edge) {
    if (x >= 0 && x < n) return x;
    if (edge == Boundary::Zero) return -1;
    if (edge == Boundary::Nearest) return x < 0 ? 0 : n - 1;
    if (n == 1) return 0;
    const bool mirror = edge == Boundary::Mirror;
    const long long period = mirror ? 2 * (n - 1) : 2 * n;
    x = (x % period + period) % period;
    return x < n ? x : period - x - (mirror ? 0 : 1);
}
}
// any(|x| > limit) over floats: for non-NaN floats |x| orders like its magnitude bits, so the
// largest magnitude (a vectorizable integer max) decides. NaN bit patterns exceed infinity's;
// then the ordinary scan (where |NaN| > limit is false) decides instead.
VCR_TARGET_CLONES inline bool magnitude_exceeds(const float* values, std::size_t n, double limit) {
    std::uint32_t largest = 0;
    for (std::size_t i = 0; i < n; ++i) {
        const auto bits = std::bit_cast<std::uint32_t>(values[i]) & 0x7fffffffu;
        largest = largest < bits ? bits : largest;
    }
    if (largest > 0x7f800000u) return std::any_of(values, values + n, [&](float x) { return std::abs(double(x)) > limit; });
    return std::abs(double(std::bit_cast<float>(largest))) > limit;
}
// Accumulate a few adjacent outputs in registers, then write them once. Tap
// order is unchanged, including the initial addition to zero.
// The source may be narrower than T (uint8 images): each sample converts exactly in the product.
template<class S, class T, class Weight>
VCR_TARGET_CLONES inline void convolve_run(const S* source, T* output, std::size_t count,
                         const std::vector<Weight>& kernel, const std::size_t* offsets) {
    using Acc = std::common_type_t<T, Weight>;
    // Wide blocks keep enough independent accumulators to hide addition latency;
    // every output still sums its taps in order.
    const auto block = [&]<std::size_t lanes>(std::size_t i) {
        std::array<Acc, lanes> sum{};
        for (std::size_t tap = 0; tap < kernel.size(); ++tap) {
            const auto* input = source + offsets[tap] + i;
            const auto weight = kernel[tap];
            for (std::size_t j = 0; j < lanes; ++j) sum[j] += weight * input[j];
        }
        std::copy(sum.begin(), sum.end(), output + i);
    };
    constexpr std::size_t wide = sizeof(Acc) == 4 ? 64 : 32;
    std::size_t i = 0;
    for (; i + wide <= count; i += wide) block.template operator()<wide>(i);
    for (; i + 16 <= count; i += 16) block.template operator()<16>(i);
    for (; i < count; ++i) {
        Acc sum = 0;
        for (std::size_t tap = 0; tap < kernel.size(); ++tap) sum += kernel[tap] * source[offsets[tap] + i];
        output[i] = sum;
    }
}
// Coefficient construction is shared by CPU and CUDA convolution.
template<class T>
inline std::vector<T> gaussian_kernel(double sigma, double truncate, bool full_width) {
    require(sigma > 0 && std::isfinite(sigma) && truncate > 0 && std::isfinite(truncate) && sigma * truncate < 100000, "invalid Gaussian sigma");
    int radius = int(sigma * truncate + .5);
    if (full_width) {
        double extent = sigma * truncate + .5; int size = int(round_half_even(extent));
        if (size % 2 == 0) size += extent - size >= 0 ? 1 : -1;
        radius = std::max(0, (size - 1) / 2);
    }
    // Normalize the small coefficient table in double; full-volume buffers
    // and convolution arithmetic follow the image dtype.
    std::vector<double> weights(2 * radius + 1); double sum = 0;
    for (int d = -radius; d <= radius; ++d) sum += weights[d + radius] = std::exp(-.5 * (d / sigma) * (d / sigma));
    std::vector<T> kernel(weights.size());
    for (std::size_t i = 0; i < weights.size(); ++i) kernel[i] = T(weights[i] / sum);
    return kernel;
}
// Shared one-axis correlation. Weight precision selects the accumulation type.
template<class S, class T, class Weight>
inline void convolve_axis(const S* data, T* tmp, const Grid& g,
                          std::size_t a, const std::vector<Weight>& kernel, Boundary edge, bool reverse=false) {
    const auto radius = int(kernel.size() / 2);
    const auto extent = g.shape[a], step = g.stride[a], block = extent * step;
    const auto boundary = [&](std::int64_t x) { return filter_detail::neighbour(x, extent, edge); };
    if (step == 1) {
        // Extend each row once, retaining the optimized contiguous tap loop.
        std::vector<long long> indices(extent + 2 * radius);
        std::vector<std::size_t> offsets(kernel.size());
        for (std::size_t x = 0; x < indices.size(); ++x) indices[x] = boundary(std::int64_t(x) - radius);
        std::iota(offsets.begin(), offsets.end(), 0);
        if (reverse) std::reverse(offsets.begin(), offsets.end());
        std::vector<T> row(indices.size());
        // Interior samples are the row itself (indices[radius + x] == x); only the margins
        // need the boundary's indices.
        const auto margin = std::min<std::size_t>(std::size_t(radius), indices.size());
        for (std::size_t base = 0; base < g.size; base += extent) {
            for (std::size_t x = 0; x < margin; ++x) row[x] = indices[x] < 0 ? T(0) : data[base + indices[x]];
            std::copy_n(data + base, extent, row.data() + margin);
            for (std::size_t x = margin + extent; x < row.size(); ++x) row[x] = indices[x] < 0 ? T(0) : data[base + indices[x]];
            convolve_run(row.data(), tmp + base, extent, kernel, offsets.data());
        }
    } else {
        std::vector<std::size_t> offsets(extent * kernel.size());
        for (std::size_t x = 0; x < extent; ++x)
            for (std::size_t tap = 0; tap < kernel.size(); ++tap) {
                const auto j = boundary(std::int64_t(x) + (reverse ? radius-std::int64_t(tap) : std::int64_t(tap)-radius));
                offsets[x * kernel.size() + tap] = j < 0 ? std::size_t(-1) : std::size_t(j) * step;
            }
        for (std::size_t base = 0; base < g.size; base += block)
            for (std::size_t x = 0; x < extent; ++x) {
                const auto* row = offsets.data() + x * kernel.size();
                if (edge == Boundary::Zero && std::find(row, row + kernel.size(), std::size_t(-1)) != row + kernel.size()) {
                    using Acc = std::common_type_t<T, Weight>;
                    for (std::size_t i = 0; i < step; ++i) {
                        Acc sum = 0;
                        for (std::size_t tap = 0; tap < kernel.size(); ++tap)
                            if (row[tap] != std::size_t(-1)) sum += kernel[tap] * data[base + row[tap] + i];
                        tmp[base + x * step + i] = T(sum);
                    }
                } else convolve_run(data + base, tmp + base + x * step, step, kernel, row);
            }
    }
}
template<class T, class Weight>
inline void convolve_axis(const std::vector<T>& data, std::vector<T>& tmp, const Grid& g,
                          std::size_t a, const std::vector<Weight>& kernel, Boundary edge, bool reverse=false) {
    convolve_axis(data.data(), tmp.data(), g, a, kernel, edge, reverse);
}
template<class T>
inline void gaussian_blur(std::vector<T>& data, const Grid& g, const std::vector<double>& sigmas, double truncate = 4, Boundary edge = Boundary::Reflect, bool full_width = false) {
    require(sigmas.size() == g.shape.size() && truncate > 0 && std::isfinite(truncate), "invalid Gaussian parameters");
    std::vector<T> tmp(g.size);
    for (std::size_t a = 0; a < sigmas.size(); ++a) {
        auto sigma = sigmas[a]; require(sigma >= 0 && std::isfinite(sigma) && sigma * truncate < 100000, "invalid Gaussian sigma");
        if (!sigma) continue;
        const auto kernel = gaussian_kernel<T>(sigma, truncate, full_width);
        convolve_axis(data, tmp, g, a, kernel, edge);
        data.swap(tmp);
    }
}
// gaussian_blur from `source` into `data` (they may be the same buffer): the blurred axes
// alternate between `data` and one scratch buffer, starting so that the last lands in `data`;
// a copy is needed only when no axis is blurred. Arithmetic is gaussian_blur's.
template<class S, class T>
inline void gaussian_blur_buffer(const S* source, T* data, const Grid& g, const std::vector<double>& sigmas, double truncate, Boundary edge, bool full_width) {
    require(sigmas.size() == g.shape.size() && truncate > 0 && std::isfinite(truncate), "invalid Gaussian parameters");
    std::size_t passes = 0;
    for (auto sigma : sigmas) { require(sigma >= 0 && std::isfinite(sigma) && sigma * truncate < 100000, "invalid Gaussian sigma"); passes += sigma != 0; }
    if (!passes) {
        if constexpr (std::is_same_v<S, T>) { if (source != data) std::copy(source, source + g.size, data); }
        else std::copy(source, source + g.size, data);
        return;
    }
    std::vector<T> scratch(g.size);
    const T* from = nullptr;  // the previous pass' output; the first pass reads `source`
    std::size_t remaining = passes;
    for (std::size_t a = 0; a < sigmas.size(); ++a) {
        if (!sigmas[a]) continue;
        // After this pass `remaining - 1` passes remain; the result must end in `data`.
        T* to = (remaining - 1) % 2 == 0 ? data : scratch.data();
        const auto kernel = gaussian_kernel<T>(sigmas[a], truncate, full_width);
        if (!from) {
            // In place: never read and write one buffer.
            if constexpr (std::is_same_v<S, T>) if (to == source) to = to == data ? scratch.data() : data;
            convolve_axis(source, to, g, a, kernel, edge);
        } else {
            if (to == from) to = to == data ? scratch.data() : data;
            convolve_axis(from, to, g, a, kernel, edge);
        }
        from = to; --remaining;
    }
    if (from != data) std::copy(from, from + g.size, data);
}
struct ChannelOptions {
    double p = 1, p_channel = 1;
    bool shared = false;
    std::vector<std::size_t> channels;
    std::vector<std::string> on;
};
// A compact sampled record, owned by the replay plan. Parameters are
// interpreted by their concrete transform's overload, never a string dispatcher.
struct ChannelPlan {
    std::string key;
    std::size_t channel = 0;
    std::vector<double> values;
    std::vector<float> field;
    std::uint64_t seed = 0;
    // Transient backend-owned field; materialized into field for replay.
    std::shared_ptr<void> device_field;
    // Voxel indices are integers, not floating-point deformation samples.
    std::vector<std::size_t> indices;
    // Device-resident selection state, materialized as indices when recording.
    std::shared_ptr<void> device_selection;
};
struct Parameters {
    std::vector<ChannelPlan> channels;
    Shape shape;
    std::vector<double> matrix, offset;
    std::vector<float> field;
    bool border = false, exact = false;
    std::shared_ptr<void> device_field;
    // Exact integer crop offsets computed from foreground on the device.
    std::shared_ptr<void> device_offset;
    int nearest_mode = 0; // 0: nearest (spatial ties round up), 2: floor (legacy resize)
};
template<class F>
Parameters sample_channels(const Sample& sample, const ChannelOptions& options, Random& r, F&& sample_one) {
    Parameters result; auto base = r.next();
    for (const auto& [name, f] : sample) {
        if (f.target.role != Role::Image || (!options.on.empty() && std::find(options.on.begin(), options.on.end(), name) == options.on.end())) continue;
        Random local{split_seed(base, name)};
        auto channels = options.channels;
        if (channels.empty()) { channels.resize(f.array.shape[0]); std::iota(channels.begin(), channels.end(), 0); }
        ChannelPlan shared;
        if (options.shared) shared = sample_one(f.array, local);
        for (auto c : channels) {
            require(c < f.array.shape[0], "channel out of bounds");
            if (!local.chance(options.p_channel)) continue;
            auto plan = options.shared ? shared : sample_one(f.array, local);
            plan.key = name; plan.channel = c; result.channels.push_back(std::move(plan));
        }
    }
    return result;
}
template<class F> void apply_channels(Sample& s, const Parameters& p, F&& apply_one) {
    for (const auto& c : p.channels) {
        auto& a = s.at(c.key).array;
        if (a.kind == 'f' && a.bytes == 4) {
            auto values = a.channel<float>(c.channel);
            apply_one(values, Grid(a.spatial()), c); a.channel(c.channel, values);
        } else {
            auto values = a.channel(c.channel);
            apply_one(values, Grid(a.spatial()), c); a.channel(c.channel, values);
        }
    }
    restore_valid(s);
}
// For transforms that read uint8 images directly: each such image becomes float32, its planned
// channels written by write(plan, grid, input, output) from the uint8 values and the others
// widened. Returns the plans left for the float path: those of other fields, and every plan of an
// image that plans a channel twice (it is widened, so later plans see earlier results).
template<class F> Parameters narrow_channels(Sample& s, const Parameters& p, F&& write) {
    Parameters rest = p; rest.channels.clear();
    std::map<std::string, std::vector<const ChannelPlan*>> images;
    for (const auto& c : p.channels) {
        if (narrow_image(s.at(c.key))) images[c.key].push_back(&c);
        else rest.channels.push_back(c);
    }
    for (const auto& [key, plans] : images) {
        auto& a = s.at(key).array; const Grid g(a.spatial());
        std::vector<const ChannelPlan*> planned(a.shape[0], nullptr);
        bool repeated = false;
        for (const auto* c : plans) {
            require(c->channel < a.shape[0], "channel out of bounds");
            repeated |= planned[c->channel] != nullptr; planned[c->channel] = c;
        }
        if (repeated) { widen(a); for (const auto* c : plans) rest.channels.push_back(*c); continue; }
        auto out = widened_storage(a);
        const auto* input = static_cast<const std::uint8_t*>(std::as_const(a).data());
        auto* output = static_cast<float*>(out.data());
        for (std::size_t c = 0; c < a.shape[0]; ++c) {
            if (planned[c]) write(*planned[c], g, input + c * g.size, output + c * g.size);
            else widen_values(input + c * g.size, output + c * g.size, g.size);
        }
        a = std::move(out);
    }
    return rest;
}
} // namespace vcr::transforms
