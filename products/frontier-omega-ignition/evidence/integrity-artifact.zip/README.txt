FRONTIER Ω IGNITION | MONTREAL.AI × QUEBEC.AI

This package contains a mission-specific, data-only program and the trusted Python
interpreter and independent comparator that ran it. Use Python 3.10 or newer.
Extract the ZIP into a fresh private directory. Run these commands there:

    python3 -I run.py verify
    python3 -I run.py run < example-input.json

For a new input, replace example-input.json with a file using the same JSON
envelope. A rejected input returns a nonzero exit code and a diagnostic on stderr.
The verifier re-executes positive cases, controls and the conventional comparator.
Review contract.json for exact input policies and acceptance. See artifact.json
for the executable program, receipt.json for observations, and context.json for
the provenance supplied by the parent mission. The interpreter supports no file
reads, network, package installation, subprocesses or tool calls from a program.
Only the fixed CLI reads these package files and the input you explicitly pass.

The issued receipt records local acceptance within this frozen scope. A test of
a digest against a manifest assumes an independently trusted manifest. SHA-256
identifies bytes; it does not establish publisher identity or the truth of claims.
Check the archive digest through a trusted channel before executing the package.
An operator could replace a manifest and contents together. Local verification
is not an external audit or evidence of an economic frontier crossing.

This private delivery can contain mission data and acceptance inputs. Use and
redistribute only under applicable rights; possession does not grant publishing
rights to customer material or any licence to the surrounding repository.
