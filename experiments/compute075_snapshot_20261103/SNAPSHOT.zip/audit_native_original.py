"""Read-only independent reconstruction; never opens an operating account."""
import copy, hashlib, json, sys, time
from pathlib import Path
BASE=Path('/tmp/outlearning_compute075'); SOURCE=Path('/tmp/compute075-finance-source')
sys.path.insert(0,str(SOURCE))
from commercial.ledger import strict_json, digest
from compute075.native import audit_export, public_dependencies
from compute075.service import read_attempt


def read(p): return strict_json(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,label):
    if not ok: raise AssertionError(label)

def choice(profile,price):
    total=price+profile['buyer_friction']
    if price<=profile['budget'] and total<min(profile['value'],profile['direct_self_service'],profile['rival_complete']): return 'certified_supplier'
    if min(profile['direct_self_service'],profile['rival_complete'])<profile['value'] and min(profile['direct_self_service'],profile['rival_complete'])<=profile['budget']:
        return 'direct_self_service' if profile['direct_self_service']<=profile['rival_complete'] else 'rival_complete'
    return 'no_purchase'


def main():
    started=time.perf_counter()
    p=read(BASE/'FINANCIAL_PROTOCOL.json');f=read(BASE/'FINANCIAL_FREEZE.json');result=read(BASE/'financial_execution/RESULTS.json')
    for name,h in f['local_files'].items():require(sha(BASE/name)==h,'local freeze '+name)
    for name,h in f['native_source_files'].items():require(sha(SOURCE/name)==h,'native freeze '+name)
    require(result['terminal'] is True and len(result['arms'])==len(p['arms'])==13,'full finite denominator')
    require(result['protocol_sha256']==sha(BASE/'FINANCIAL_PROTOCOL.json') and result['freeze_sha256']==sha(BASE/'FINANCIAL_FREEZE.json'),'result source binding')
    price=p['posted_price'];check=p['prospect_check']['microUSD_per_buyer'];prospects=p['prospect_check']['prospects_per_arm']
    require(price==2_000_000 and check==20_000 and prospects==2,'frozen known price/search')
    report={'schema':'compute075/independent-financial-protocol-audit-v1','accepted':False,'source_closure':digest(f['native_source_files']),
            'protocol_sha256':sha(BASE/'FINANCIAL_PROTOCOL.json'),'freeze_sha256':sha(BASE/'FINANCIAL_FREEZE.json'),
            'input_result_sha256':sha(BASE/'financial_execution/RESULTS.json'),'arms':[],
            'scope':'AUTHORED_CONDITIONAL_SIMULATION_NOT_OBSERVED_COMMERCE','actual_model_host_billing':None}
    allow={str(BASE/'FINANCIAL_PROTOCOL.json'),str(BASE/'FINANCIAL_FREEZE.json'),str(BASE/'financial_execution/RESULTS.json')}
    deliveries=0
    for i,(arm,out) in enumerate(zip(p['arms'],result['arms'])):
        ap=BASE/'financial_execution'/f'arm_{i:02d}';m=read(ap/'manifest.json');r=read(ap/'account_export.json')
        require(out['id']==arm['id'] and out['finished'] is True and 'failure' not in out,'arm identity/terminal')
        require(digest(m)==out['manifest_sha256'] and digest(r)==out['account_export_sha256'],'manifest/export binding')
        require(r['ledger']['config']['opening']==arm['opening'],'separate starting capital')
        require(r['ledger']['config']['working']==0,'working capital')
        require(r['ledger']['summary']==out['summary'],'reported native balances')
        fresh=audit_export(r,root=SOURCE,manifest=m);require(fresh['accepted'],'independent native replay')
        acts=r['ledger']['actions'];jobs=m['jobs'];require(len(jobs)==2,'two frozen requests')
        packages=[]
        sp=p['cost_scope']['supplier' if arm['supplier']=='participates' else 'supplier_refusal']
        participation=sp['quote']>=sp['complete_cost']+sp['outside_profit']
        buyer=choice(p['buyer_profiles'][arm['buyer']],price)
        for j,job in enumerate(jobs):
            q=job['request'];ident=f'compute075-fin-{i:02d}-{j+1}'
            require(job['id']==q['id']==ident and q['market']['buyer_id']==ident+'-buyer','request/buyer identity')
            require(q['market']['decision']==dict(p['buyer_profiles'][arm['buyer']],price=price,chosen=buyer,
                    provenance='AUTHORED_SCENARIO_NOT_MEASURED_MARKET_OR_BILLING'),'frozen response construction')
            items=copy.deepcopy(p['cost_scope']['per_request']);items['research_construction']=arm['construction'] if j==0 else 0
            require(q['resource']['costs']['items_microUSD']==items,'all modeled costs incl construction')
            total=sum(items.values());packages.append(total)
            require(q['resource']['costs']['total_microUSD']==total,'resource cost arithmetic')
            require(q['resource']['costs']['actual_model_host_billing_microUSD'] is None,'billing remains unknown')
            require(q['resource']['supplier']==dict(sp,participates=participation,provenance='AUTHORED_SCENARIO_NOT_MEASURED_MARKET_OR_BILLING'),'supplier outside option')
            require(q['resource']['allow_seed']==(j==0) and q['resource']['expected_net']==price-total and q['resource']['max_attempts']==p['cost_scope']['max_attempts'],'frozen funding and attempt terms')
            require(q['instance_sha256']==out['input_binding'][j]['instance_sha256'] and sha(SOURCE/q['instance_path'])==out['input_binding'][j]['raw_file_sha256'],'input bytes and result binding')
        # Independently reconstruct the permitted public policy, without importing it.
        if 2*price-sum(packages)-2*check<=0: stage1='decline_nonpositive_best_case_margin'
        elif arm['opening']<2*check: stage1='defer_prospect_check_unfunded'
        elif arm['opening']<2*check+packages[0]+price+200_000: stage1='defer_preflight_liquidity'
        else: stage1='buy_prospect_checks'
        require(out['public_decisions'][0]['decision']==stage1,'public pre-response policy')
        expected_visible = {'posted_price': price, 'package_costs': packages, 'prospect_cost': 2*check, 'available': arm['opening']}
        original_visible_ok = out['public_decisions'][0]['visible'] == expected_visible
        expected_search=2 if stage1=='buy_prospect_checks' else 0
        search=[a for a in acts if a['op']=='cost' and a['args']['id'].startswith('compute075-prospect-')]
        require(len(search)==expected_search,'search/refusal expenses retained')
        for j,a in enumerate(search):
            require(a['args']=={'id':f'compute075-prospect-{i:02d}-{j+1}','amount':check} and a['day']==0,'exact paid search identity/amount/clock')
            require(a['before']['available']>=check,'search had actual native cash')
        if expected_search:
            after='decline_buyer_response' if buyer!='certified_supplier' else 'decline_supplier_response' if not participation else 'produce_first'
            require(out['public_decisions'][1]['decision']==after,'post-response policy')
        else: after=stage1
        offers=[a for a in acts if a['op']=='offer']
        spends=[e for e in r['connected_journal']['entries'] if e['request']['operation']=='spend' and e['status']=='COMPLETE']
        markers=[a for a in acts if a['op']=='cost' and a['args']['id'].startswith('compute075-attempt-')]
        releases=[a for a in acts if a['op']=='event' and a['args']['action']=='release']
        refunds=[a for a in acts if a['op']=='event' and a['args']['action']=='refund']
        claims=[a for a in acts if a['op']=='claim']
        if after!='produce_first':
            require(not offers and not spends and not markers and not releases and not refunds and not claims,'declined arm cannot transact')
            expected_revenue=0;expected_cost=expected_search*check; expected_deliveries=0
        else:
            limited=arm['delivery_mode'] in ('late','claim_1000000')
            count=1 if limited else 2
            require(len(offers)==len(spends)==len(out['production'])==count,'actual paid production denominator')
            expected_deliveries=0 if arm['delivery_mode']=='late' else count
            require(len(releases)==expected_deliveries,'native exactly-once release')
            expected_revenue=price*expected_deliveries
            expected_cost=2*check+sum(packages[:count])+(1_000_000 if arm['delivery_mode']=='claim_1000000' else 0)
            for j,(offer,spend) in enumerate(zip(offers,spends)):
                clock=p['native_clock']['request'+str(j+1)];job=jobs[j]['id'];order=job+'-order'
                require(offer['args']['id']==order and offer['args']['job_id']==job and offer['args']['price']==price and offer['day']==clock['order'] and offer['args']['deadline']==clock['deadline'],'frozen native order')
                require(spend['receipt']['amount']==packages[j] and spend['receipt']['day']==clock['prepay'],'complete package paid at preregistered time')
                require(spend['receipt']['native_event_sequence']<offer['seq'],'resources preceded order')
                require(spend['receipt']['funding']==('SEED' if j==0 else 'EARNED'),'native seed/earned distinction')
                own_markers=[a for a in markers if read_attempt(SOURCE,m,a['args']['id'])['job_id']==job]
                require(len(own_markers)==(2 if j==0 and arm['delivery_mode']=='corrupt_then_correct' else 1),'all attempts preserved and bounded')
                require(all(a['seq']>offer['seq'] for a in own_markers),'attempts after funded order')
                require(all(a['day']==clock['deadline']+(1 if arm['delivery_mode']=='late' else 0) for a in own_markers),'attempt clock including late')
            if arm['delivery_mode']=='late':
                require(len(refunds)==1 and refunds[0]['day']==3 and not claims,'late valid output refunded')
                require(not any(a['op']=='event' and a['args']['action']=='prepare' for a in acts),'late artifact never prepared')
            else: require(not refunds,'no unexpected refund')
            if arm['delivery_mode']=='claim_1000000':
                require(len(claims)==1 and claims[0]['args']['amount']==1_000_000 and claims[0]['args']['kind']=='ordinary' and claims[0]['day']==3,'exact included support claim')
                settlements=[a for a in acts if a['op']=='resolve_claim'];require(len(settlements)==1 and settlements[0]['args']['resolution']=='pay' and settlements[0]['day']==3,'claim actually paid')
                require(out['summary']['unrestrictedEarned']==0 and out['summary']['cash']>packages[1],'earned-only stop despite seed liquidity')
            else:require(not claims,'no unregistered claims')
        s=out['summary']
        require(s['revenue']==expected_revenue and s['expenses']==expected_cost and s['expensePaid']==expected_cost,'complete revenue/cost reconstruction')
        require(s['profit']==expected_revenue-expected_cost and s['cash']==arm['opening']+expected_revenue-expected_cost,'cash/profit conservation independently derived')
        require(s['payables']==s['custodyRestricted']==s['custodyReserve']==s['tailReserve']==s['reservedInvestment']==0,'terminal obligations and reserves resolved')
        deps=public_dependencies(r,root=SOURCE,manifest=m)
        require(deps==out['public_dependencies'],'exact key-free replay allowlist')
        allow.update(str(SOURCE/x) for x in deps);allow.update((str(ap/'manifest.json'),str(ap/'account_export.json')))
        deliveries+=expected_deliveries
        report['arms'].append({'id':arm['id'],'native_audit':True,'protocol_reconstruction_audit':True,
            'original_pre_check_visible_accepted':original_visible_ok,
            'reconstructed_pre_check_visible':expected_visible,
            'recorded_pre_check_visible_sha256':digest(out['public_decisions'][0]['visible']), 'opening':arm['opening'],
            'revenue':expected_revenue,'expenses':expected_cost,'profit':s['profit'],'accepted_deliveries':expected_deliveries,
            'paid_prospect_checks':expected_search,'resource_packages':len(spends),'metered_attempts':len(markers),
            'key_free_dependencies':len(deps)})
    require(deliveries==result['commercial_delivery_count']==5,'aggregate accepted delivery denominator')
    alias_arms = [a['id'] for a in report['arms'] if not a['original_pre_check_visible_accepted']]
    report.update(accepted=True,accepted_scope='native_financial_replay_and_independent_protocol_reconstruction_only',
        original_observation_trace_qualified=not alias_arms, historical_snapshot_defect_arms=alias_arms,
        historical_snapshot_caveat='Runner stored before_checks.visible by reference; later public.update mutated it. Native costs/actions and frozen source allow separately labeled reconstruction, not retroactive correction of original history.',
        accepted_deliveries=deliveries,arms_checked=len(report['arms']),wall_seconds=time.perf_counter()-started,
        limitations=['Conditional authored prices/costs/capital, not observed market or real profit.','Two requests are same-service continuation, not a different-opportunity enabling claim.','No annualization, release qualification, or full upstream CI.','Original producer output timestamps are runner evidence; mathematical reviewer separately checks freeze and complete math artifacts.'])
    Path('/tmp/compute075-financial-independent-audit.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    Path('/tmp/compute075-financial-public-allowlist.json').write_text(json.dumps({'scope':'PUBLIC_SOURCE_AND_FRESH_SYNTHETIC_EVIDENCE_ONLY','paths':sorted(allow)},indent=2)+'\n')
    print(json.dumps(report,sort_keys=True))

if __name__=='__main__': main()
