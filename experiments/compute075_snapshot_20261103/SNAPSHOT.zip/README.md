# Certified mathematical delivery, with conditional native commerce

Read [the result](experiment/FINANCIAL_RESULT.md) first. This package contains the
original frozen thirteen-arm result, source-bound mathematical outputs, canonical
account exports, independent audits, the separately reconstructed observation history,
and a future-only logging repair. Five outputs were accepted and paid across independent
conditional accounts. No observed market, different-K2 discovery advantage, physical
validation or billion-dollar profit is claimed.

**Preserved defect:** nine initial observation snapshots were mutated by dictionary
aliasing. Both independent audits mark the original observation trace unqualified. Their
reconstructions are separate, not replacements. The original result hash remains
`bd89cf02b1c1115903d8e96c9c975d943115e0e42b1e8b4672495ead3807823d`.

## Inspect and replay without private authority

The frozen native source is on public main
`54f33ce6d3b19d37050717c2c1a4e1e4380caa6b` plus the additive compute075 adapter.
It is a local development snapshot, not a qualified release or full repository CI result.
The exact runtime versions are in `experiment/PINNED_RUNTIME.json`. The data bundle is
869 KB and contains only allowlisted public/synthetic JSON, with shared lists deduplicated.
It contains no account databases, signing keys, recovery files, user messages or private
inputs. Restoration checks the original hash of each complete JSON file before writing.

From this directory, with the recorded Python dependencies already available:

```sh
python3 -B restore_data.py
PYTHONPATH="$PWD/native_source" python3 -B experiment/audit_financial_delivery.py --source "$PWD/native_source" > /tmp/compute075-math-replay.json
PYTHONPATH="$PWD/native_source" python3 -B audit_native.py --experiment "$PWD/experiment" --source "$PWD/native_source" --output /tmp/compute075-native-replay.json --allowlist /tmp/compute075-public-replay-paths.json
(cd experiment && python3 -B -m unittest test_verifier test_trace_snapshots)
```

These commands audit saved evidence. They do not rerun production, open an operating
account, obtain credentials, call a model, access the network or spend money. Native
replay creates temporary local reconstruction state through its ordinary verifier.
The path and metadata-identity adaptations of the audits are documented in
`AUDIT_PORTABILITY.json`; their original sources are included unchanged for provenance. Use the public adapted commands above; the original checkers require the unavailable original metadata bytes.

**Public metadata derivatives:** three nonfinancial metadata fields are sanitized in the two protocol documents and the regression provenance receipt. `experiment/PUBLIC_METADATA_REDACTIONS.json` records exact original/public hashes, changed field paths and unchanged-field projections. The originals remain unchanged privately. Public readers cannot reconstruct or independently verify those three original byte streams; the metadata-only comparison is reviewer-attested. The public auditors disclose this limit rather than presenting derived protocols as byte-identical originals. All native source, mathematical data, original results, account exports and the financial freeze remain byte-identical.

`MANIFEST.json` hashes every distributed file. `DATA_MANIFEST.json` additionally hashes
all forty-four restored raw data files. The mathematical and financial auditors validate
source closures, all twenty-six input bindings, six actual outputs, seven submissions,
five releases and the complete prospective cost/claim/refund decisions. The prospective
repair regression reproduces the logging defect and checks the deep-copy fix without
changing historical results.

## Reading order

- `experiment/FINANCIAL_RESULT.md`: outcome, costs, failures and limitations.
- `experiment/FINANCIAL_PROTOCOL.json` and `FINANCIAL_FREEZE.json`: fixed experiment.
- `experiment/financial_execution/RESULTS.json`: untouched historical result.
- `experiment/FINANCIAL_INDEPENDENT_POST_OUTCOME_AUDIT.json`: mathematical verification and separately labeled observation reconstruction.
- `experiment/FINANCIAL_NATIVE_PROTOCOL_AUDIT.json`: canonical native replay and complete-cost reconstruction.
- `experiment/TRACE_REPAIR.json`: ordinary post-outcome engineering correction.
- `experiment/CONDITIONAL_THRESHOLDS.json`: conditional volume/retention arithmetic, not an executed scale track or demand forecast.

Some dated working records predate final audits; the final audit receipts above are the
current qualification statements. No conditional accounts may be pooled into a claimed
compounding enterprise. The $3.60 construction threshold applies only to this two-order
horizon, not to every possible volume or enterprise.
