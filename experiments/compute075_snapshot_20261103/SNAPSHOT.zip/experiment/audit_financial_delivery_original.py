#!/usr/bin/env python3
"""Read-only artifact/experimental-integrity audit; no native account or solve.

This is not the native engine/financial replay audit. Original faulty historical
snapshots are retained and reported, not repaired by this audit.
"""

import argparse
import ast
import copy
import datetime
import hashlib
import json
import tempfile
from pathlib import Path

import verifier
from producer import make_development
from run_financial import public_seller_policy

ROOT = Path(__file__).parent


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def audit(source):
    result_path = ROOT / "financial_execution/RESULTS.json"
    result_hash = sha(result_path)
    results = read(result_path)
    freeze = read(ROOT / "FINANCIAL_FREEZE.json")
    protocol = read(ROOT / "FINANCIAL_PROTOCOL.json")
    review_protocol = read(ROOT / "FINANCIAL_PROTOCOL_REVIEW.json")
    resources = read(ROOT / "FINANCIAL_PROCESS_RESOURCES.json")
    assert sha(ROOT / "FINANCIAL_FREEZE.json") == "8167c6035f92e2725b2ba8042abacae53fbd9478c4ed9f69a234fcb7171a79f8"
    for name, expected in freeze["local_files"].items():
        assert sha(ROOT / name) == expected, name
    for name, expected in freeze["native_source_files"].items():
        assert sha(source / name) == expected, name
    assert freeze["local_files"]["run_financial.py"] == read(ROOT / "FINANCIAL_PRE_OUTCOME_PORTABILITY_ADDENDUM.json")["current_reviewed_runner_sha256"]
    differing_protocol_fields = sorted(k for k in set(protocol) | set(review_protocol)
                                       if protocol.get(k) != review_protocol.get(k))
    assert differing_protocol_fields == ["frozen_utc", "native_review_gate", "status"]
    assert results["freeze_sha256"] == sha(ROOT / "FINANCIAL_FREEZE.json")
    assert results["protocol_sha256"] == sha(ROOT / "FINANCIAL_PROTOCOL.json")
    assert results["terminal"] is True and not results.get("stopped_on_unexpected_failure", False)
    assert len(results["arms"]) == len(protocol["arms"]) == 13
    assert results["learning_advantage"] == "NOT_TESTED" and results["actual_billing"] is None
    assert resources["returncode"] == 0
    assert resources["complete_subprocess_wall_seconds"] >= results["total_wall_seconds"]
    assert results["total_wall_seconds"] >= sum(a["complete_arm_wall_seconds"] for a in results["arms"])

    tree = ast.parse((ROOT / "run_financial.py").read_text())
    policy = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "public_seller_policy")
    policy_args = {a.arg for a in policy.args.kwonlyargs}
    assert policy_args == {"posted_price", "package_costs", "prospect_cost", "available", "buyer_acceptances", "supplier_accepts"}
    assert {n.id for n in ast.walk(policy) if isinstance(n, ast.Name)} == policy_args | {"all", "sum", "len"}

    # Regenerate only inputs, never invoke the producer's solve function.
    bases = []
    for index, n in enumerate(protocol["request_generation"]["n"]):
        instance = make_development(n, protocol["request_generation"]["seed_base"] + index)
        if index == 1:
            instance["horizontal"] = [[1 if (r // (n // 8)) % 2 == 0 else 4 for _ in range(n + 1)] for r in range(n)]
            instance["vertical"] = [[2 if (c // (n // 8)) % 2 == 0 else 4 for c in range(n)] for _ in range(n + 1)]
            instance["rhs"] = [7 if (c - n // 2) ** 2 + (r - n // 2) ** 2 < (n // 4) ** 2 else -1
                               for r in range(n) for c in range(n)]
        bases.append(instance)

    bindings = []
    outputs = []
    reconstructions = []
    attempt_checks = []
    release_count = 0
    stable = ("accepted", "status", "instance_id", "instance_sha256", "instance_binding",
              "solution_sha256", "residual_sum_squares", "residual_max_abs", "comparison_left",
              "comparison_right", "error_l2_upper_bound_squared", "verifier_source_sha256")
    for arm_index, (scenario, result) in enumerate(zip(protocol["arms"], results["arms"])):
        assert result["id"] == scenario["id"] and result["finished"] is True and "failure" not in result
        folder = ROOT / "financial_execution" / f"arm_{arm_index:02d}"
        manifest = read(folder / "manifest.json")
        record = read(folder / "account_export.json")
        actions = record["ledger"]["actions"]
        assert manifest["source_hashes"] == freeze["native_source_files"]
        assert len(manifest["jobs"]) == len(result["input_binding"]) == 2
        packages = []
        input_by_id = {}
        for index, job in enumerate(manifest["jobs"]):
            request = job["request"]
            expected = copy.deepcopy(bases[index])
            expected["instance_id"] = f"compute075-fin-{arm_index:02d}-{index + 1}"
            input_path = (source / request["instance_path"]).resolve()
            assert input_path.is_relative_to(source.resolve())
            assert read(input_path) == expected
            verifier.validate_instance(expected)
            pin = verifier.canonical_sha256(expected)
            assert pin == request["instance_sha256"] == result["input_binding"][index]["instance_sha256"]
            assert sha(input_path) == result["input_binding"][index]["raw_file_sha256"]
            assert request["resource"]["allow_seed"] == (index == 0)
            packages.append(request["resource"]["costs"]["total_microUSD"])
            input_by_id[job["id"]] = (input_path, pin, index)
            bindings.append({"request_id": job["id"], "instance_sha256": pin})

        native_opening_available = actions[0]["before"]["available"] if actions else record["ledger"]["config"]["opening"]
        public_before = {"posted_price": protocol["posted_price"], "package_costs": packages,
                         "prospect_cost": 2 * protocol["prospect_check"]["microUSD_per_buyer"],
                         "available": native_opening_available}
        first_decision = public_seller_policy(**public_before)
        original_before = result["public_decisions"][0]
        assert first_decision == original_before["decision"]
        discrepancy = original_before["visible"] != public_before
        reconstructions.append({"arm": result["id"], "basis": "reconstruction from frozen source and native opening, not original observation",
                                "original_snapshot_is_faithful": not discrepancy,
                                "reconstructed_precheck_inputs": public_before,
                                "recomputed_decision": first_decision,
                                "original_recorded_decision": original_before["decision"]})
        if first_decision == "buy_prospect_checks":
            assert len(result["public_decisions"]) == 2
            prospect_actions = [a for a in actions if a["op"] == "cost" and a["args"]["id"].startswith("compute075-prospect-")]
            assert len(prospect_actions) == 2
            responses = [e["observed_buyer_acceptance"] for e in result["events"] if e["kind"] == "paid_prospect_check"]
            public_after = dict(public_before, available=prospect_actions[-1]["after"]["available"],
                                buyer_acceptances=responses,
                                supplier_accepts=manifest["jobs"][0]["request"]["resource"]["supplier"]["participates"])
            assert public_after == result["public_decisions"][1]["visible"]
            assert public_seller_policy(**public_after) == result["public_decisions"][1]["decision"]
        else:
            assert len(result["public_decisions"]) == 1

        for produced in result["production"]:
            ident = produced["request_id"]
            ip, pin, index = input_by_id[ident]
            sp = folder / f"solution_{index + 1}.json"
            receipt = verifier.verify(ip, sp, expected_instance_sha256=pin)
            assert receipt["accepted"] is True
            assert all(receipt[k] == produced["certificate"][k] for k in stable)
            assert receipt["solution_sha256"] == produced["solution_sha256"]
            assert produced["method"] == ("pcg" if index == 0 else "direct")
            assert produced["complete_math_wall_seconds"] >= produced["producer_receipt"]["wall_seconds"]
            assert produced["complete_math_wall_seconds"] >= produced["certificate"]["cost"]["wall_ns"] / 1e9
            assert result["complete_arm_wall_seconds"] >= produced["complete_math_wall_seconds"] + produced["native_submission_wall_seconds"]
            paid = next(e["receipt"] for e in result["events"] if e["kind"] == "native_prepaid" and e["request_id"] == ident)
            offers = [a for a in actions if a["op"] == "offer" and a["args"]["job_id"] == ident]
            assert len(offers) == 1
            offer = offers[0]
            assert paid["native_event_sequence"] < offer["seq"]
            assert paid["funding"] == ("SEED" if index == 0 else "EARNED")
            funding = next(a for a in actions if a["op"] == "event" and a["args"]["id"] == ident + "-order" and a["args"]["action"] == "fund")
            assert offer["seq"] < funding["seq"]
            order_events = [a for a in actions if a["op"] == "event" and a["args"]["id"] == ident + "-order" and a["args"]["action"] in ("prepare", "release", "refund")]
            assert order_events and all(funding["seq"] < e["seq"] for e in order_events)
            released = any(e["args"]["action"] == "release" for e in order_events)
            release_count += int(released)
            outputs.append({"arm": result["id"], "request_id": ident, "status": receipt["status"],
                            "solution_sha256": receipt["solution_sha256"], "released": released,
                            "error_l2_upper_bound_squared": receipt["error_l2_upper_bound_squared"],
                            "native_prepaid_sequence": paid["native_event_sequence"], "native_offer_sequence": offer["seq"],
                            "native_fund_sequence": funding["seq"]})

        # Independently check all seven retained submitted mathematical artifacts,
        # including the invalid corruption and valid-but-late output.
        for relative in result["public_dependencies"]:
            if not relative.startswith("compute075/attempts/"):
                continue
            attempt = read(source / relative)
            ip, pin, _ = input_by_id[attempt["job_id"]]
            with tempfile.TemporaryDirectory() as temp:
                path = Path(temp) / "attempt.json"
                path.write_bytes(verifier.canonical_bytes(attempt["artifact"]))
                checked = verifier.verify(ip, path, expected_instance_sha256=pin)
            attempt_checks.append({"arm": result["id"], "request_id": attempt["job_id"], "attempt_path": relative,
                                   "solution_sha256": checked["solution_sha256"], "mathematical_status": checked["status"]})

    assert len(bindings) == len({b["request_id"] for b in bindings}) == len({b["instance_sha256"] for b in bindings}) == 26
    assert len(outputs) == 6 and release_count == results["commercial_delivery_count"] == 5
    assert len(attempt_checks) == 7 and sum(a["mathematical_status"] == "certified" for a in attempt_checks) == 6
    bad_snapshots = [r["arm"] for r in reconstructions if not r["original_snapshot_is_faithful"]]
    assert len(bad_snapshots) == 9
    assert sha(result_path) == result_hash
    return {"schema": "compute075-independent-financial-delivery-audit-v1",
            "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "status": "MATHEMATICS_AND_SOURCE_CHECKS_PASS_WITH_HISTORICAL_TRACE_DEFECT",
            "original_historical_observation_trace_passed": False,
            "source_binding_mathematical_outputs_and_policy_reconstruction_passed": True,
            "freeze_sha256": sha(ROOT / "FINANCIAL_FREEZE.json"), "original_results_sha256": result_hash,
            "audit_source_sha256": sha(__file__), "local_frozen_files_checked": len(freeze["local_files"]),
            "native_frozen_source_files_checked": len(freeze["native_source_files"]),
            "review_to_final_protocol_changes": differing_protocol_fields,
            "completed_arms": 13, "generated_inputs_checked": 26, "actual_math_outputs_checked": 6,
            "submitted_artifacts_checked": 7, "released_deliveries_observed": 5,
            "policy_has_only_public_argument_dependencies": True,
            "trace_defect": {"affected_arms": bad_snapshots,
                             "cause": "before_checks.visible aliases the mutable public dict, changed later by public.update",
                             "effect": "earlier log includes later response flags and post-debit cash",
                             "treatment": "original source/results preserved; reconstruct separately and do not present reconstructed inputs as authenticated original observations"},
            "ordering_evidence": "Frozen runner calls prepay and begin_order before solve; retained native sequences show payment before offer/funding and submission. There is no separate trusted wall-clock solve-start event, so this is source-and-native-chronology evidence, not cryptographic execution attestation.",
            "timing": {"complete_subprocess_wall_seconds": resources["complete_subprocess_wall_seconds"],
                       "runner_loop_wall_seconds": results["total_wall_seconds"],
                       "scope": "Math components include solve/diagnostics/write/verification; native components and full arm/launcher timings retain other execution overhead. Launcher excludes earlier construction/review and its own startup. Shared-host observation, not speed comparison or billing."},
            "claim_limits": ["Authored conditional finances, not observed demand or actual profit; actual billing is null.",
                             "Second instance is same-service earned continuation, not different-K2 learning or uniquely enabled opportunity.",
                             "Native engine/replay and dollar-cost reconciliation are separately audited; this audit does not replace them.",
                             "No producer, benchmark, account execution or source modification was performed by this audit."],
            "input_bindings": bindings, "outputs": outputs, "submitted_artifacts": attempt_checks,
            "separate_precheck_reconstructions": reconstructions}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(audit(args.source.resolve()), indent=2))
