"""Conditional arithmetic thresholds, never native profit or a demand forecast."""
from fractions import Fraction
import json
from pathlib import Path


def strict_break_even_count(fixed, contribution):
    return None if contribution<=0 else int(Fraction(fixed,1)//contribution)+1


def calculate(native_results):
    # All amounts below are microUSD. Account money is read, never reconstructed.
    arm=next(a for a in native_results['arms'] if a['id']=='friction_optimistic_cost')
    native_profit=arm['summary']['profit']
    # Aggregation check is only this exact two-order, no-claim authored path.
    observed_formula=2*2_000_000-1_000_000-2*180_000-2*20_000
    if native_profit!=observed_formula:
        raise ValueError('CONDITIONAL_FORMULA_NOT_BOUND_TO_NATIVE_TWO_ORDER_PATH')
    rows=[]
    for fixed in (1_000_000,100_000_000,1_000_000_000,10_000_000_000):
        for conversion in (Fraction(1),Fraction(1,2),Fraction(1,10),Fraction(1,100)):
            for delivery in (Fraction(1),Fraction(19,20),Fraction(1,2)):
                # Unsuccessful accepted work still incurs its supplier/verification
                # package; unsuccessful prospects still incur checks. No support
                # claim is assumed in this plane; extra claims reduce contribution.
                contribution=Fraction(2_000_000)-Fraction(180_000)/delivery-Fraction(20_000)/(conversion*delivery)
                rows.append({'construction_microUSD':fixed,'buyer_conversion_fraction':str(conversion),
                    'accepted_delivery_fraction':str(delivery),'contribution_per_accepted_delivery_microUSD':str(contribution),
                    'strict_break_even_accepted_deliveries':strict_break_even_count(fixed,contribution)})
    retention=[]
    for fixed in (100_000_000,1_000_000_000):
        for converted_customers in (10,100):
            # Assumes repeat orders avoid a new prospect check. This is an explicit
            # hypothetical efficiency, NOT observed retention/onboarding reuse.
            R=strict_break_even_count(Fraction(fixed,converted_customers)+20_000,Fraction(1_820_000))
            retention.append({'construction_microUSD':fixed,'converted_customers':converted_customers,
                'minimum_accepted_orders_per_customer_for_positive_total_surplus':R,
                'condition':'All renew at posted price, new prospect check waived on repeat, no delivery failure or extra claim, no channel/support/price deterioration.'})
    return {'schema':'compute075-conditional-thresholds-v1','native_binding':{'arm':'friction_optimistic_cost','native_profit_microUSD':native_profit,'two_order_formula_matches':True},
            'scope':'Illustrative conditional arithmetic, not an executed scale track, empirical demand, native trailing-year profit or enterprise ceiling.',
            'volume_rows':rows,'retention_rows':retention,
            'binding_unknowns':['Actual construction/model-access/labor bill','Conversion, retained demand and willingness to pay despite free shared code and strong alternatives','Acquisition distribution and channel saturation','Supplier throughput, invalid/late frequency, correction and support tails','Competition and pricing pressure','Required cash before delayed collections and available financing'],
            'no_scale_claim':'The thirteen finite arms cannot validate a $3 billion trailing-365-day result. No volume multiplier creates demand, capacity or spendable future earnings.'}


if __name__=='__main__':
    root=Path(__file__).resolve().parent
    data=calculate(json.loads((root/'financial_execution/RESULTS.json').read_text()))
    (root/'CONDITIONAL_THRESHOLDS.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps(data['native_binding']))
