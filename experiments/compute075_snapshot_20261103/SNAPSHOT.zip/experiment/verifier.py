#!/usr/bin/env python3
"""Independent exact checker for the diffusion-instance-v1 discrete contract.

No supplier implementation, acceptance flag, floating-point norm, or solver is
used. See CONTRACT.md for the mathematical claim and caller trust boundary.
"""

import argparse
import hashlib
import json
import re
import time
from pathlib import Path

VERSION = "diffusion-verifier-v1"
MAX_N = 256
MAX_Q = 60
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_JSON_DEPTH = 8
MAX_INTEGER_DIGITS = 40
MAX_RHS = (1 << 63) - 1
MAX_Z = (1 << 127) - 1
MAX_RATIONAL = (1 << 127) - 1
ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z", re.ASCII)
HASH_RE = re.compile(r"[0-9a-f]{64}\Z", re.ASCII)
INSTANCE_KEYS = {"schema", "instance_id", "n", "q", "tolerance", "horizontal", "vertical", "rhs"}
SOLUTION_KEYS = {"schema", "instance_id", "instance_sha256", "z"}


class Invalid(ValueError):
    """Invalid input; fail closed before certifying a numerical claim."""


def canonical_bytes(value):
    """Canonical JSON for this strict, integer-only, ASCII-string schema."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("utf-8")


def canonical_sha256(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _integer_token(token):
    if len(token.lstrip("-")) > MAX_INTEGER_DIGITS:
        raise Invalid("integer token exceeds digit cap")
    return int(token)


def _no_noninteger(token):
    raise Invalid("non-integer JSON number is forbidden")


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise Invalid("duplicate JSON object key: " + key[:80])
        result[key] = value
    return result


def _bounded_json(raw):
    if len(raw) > MAX_FILE_BYTES:
        raise Invalid("input exceeds byte cap")
    # Bound parser recursion before json.loads; ignore braces inside strings.
    depth = 0
    quoted = False
    escaped = False
    for byte in raw:
        if quoted:
            if escaped:
                escaped = False
            elif byte == 92:
                escaped = True
            elif byte == 34:
                quoted = False
        elif byte == 34:
            quoted = True
        elif byte in (91, 123):
            depth += 1
            if depth > MAX_JSON_DEPTH:
                raise Invalid("JSON nesting exceeds cap")
        elif byte in (93, 125):
            depth -= 1
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=_object,
                          parse_int=_integer_token, parse_float=_no_noninteger,
                          parse_constant=_no_noninteger)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise Invalid("invalid UTF-8 JSON") from exc


def _read(path):
    with open(path, "rb") as stream:
        raw = stream.read(MAX_FILE_BYTES + 1)
    return _bounded_json(raw), raw


def _keys(obj, expected, label):
    if type(obj) is not dict or set(obj) != expected:
        raise Invalid(label + " must have exactly the specified keys")


def _int(value, low, high, label):
    # bool is deliberately not an integer in the contract.
    if type(value) is not int or not low <= value <= high:
        raise Invalid(label + " is not an integer in range")


def _id(value):
    if type(value) is not str or ID_RE.fullmatch(value) is None:
        raise Invalid("invalid instance_id")


def _hash(value, label):
    if type(value) is not str or HASH_RE.fullmatch(value) is None:
        raise Invalid(label + " must be a lowercase SHA-256 hex digest")


def _edges(matrix, rows, columns, label):
    if type(matrix) is not list or len(matrix) != rows:
        raise Invalid(label + " has wrong row count")
    for row in matrix:
        if type(row) is not list or len(row) != columns:
            raise Invalid(label + " has wrong column count")
        if any(type(value) is not int or value not in (1, 2, 4) for value in row):
            raise Invalid(label + " conductance must be exactly 1, 2, or 4")


def validate_instance(instance):
    _keys(instance, INSTANCE_KEYS, "instance")
    if instance["schema"] != "diffusion-instance-v1":
        raise Invalid("wrong instance schema")
    _id(instance["instance_id"])
    _int(instance["n"], 1, MAX_N, "n")
    _int(instance["q"], 0, MAX_Q, "q")
    n = instance["n"]
    tol = instance["tolerance"]
    _keys(tol, {"numerator", "denominator"}, "tolerance")
    _int(tol["numerator"], 0, MAX_RATIONAL, "tolerance numerator")
    _int(tol["denominator"], 1, MAX_RATIONAL, "tolerance denominator")
    _edges(instance["horizontal"], n, n + 1, "horizontal")
    _edges(instance["vertical"], n + 1, n, "vertical")
    if type(instance["rhs"]) is not list or len(instance["rhs"]) != n * n:
        raise Invalid("rhs has wrong dimension")
    for value in instance["rhs"]:
        _int(value, -MAX_RHS, MAX_RHS, "rhs component")


def _validate_solution(solution, instance, digest):
    _keys(solution, SOLUTION_KEYS, "solution")
    if solution["schema"] != "diffusion-solution-v1":
        raise Invalid("wrong solution schema")
    _id(solution["instance_id"])
    if solution["instance_id"] != instance["instance_id"]:
        raise Invalid("instance_id mismatch")
    _hash(solution["instance_sha256"], "solution instance_sha256")
    if solution["instance_sha256"] != digest:
        raise Invalid("solution instance hash mismatch")
    if type(solution["z"]) is not list or len(solution["z"]) != instance["n"] ** 2:
        raise Invalid("z has wrong dimension")
    for value in solution["z"]:
        _int(value, -MAX_Z, MAX_Z, "z component")


def _residual_sum_squares(instance, z):
    """Build every row directly from the edge arrays, using arbitrary integers."""
    n = instance["n"]
    horizontal = instance["horizontal"]
    vertical = instance["vertical"]
    rhs = instance["rhs"]
    scale = (n + 1) ** 2
    denominator = 1 << instance["q"]
    total = 0
    max_abs = 0
    for row in range(n):
        for col in range(n):
            k = row * n + col
            center = z[k]
            left = z[k - 1] if col > 0 else 0
            right = z[k + 1] if col + 1 < n else 0
            above = z[k - n] if row > 0 else 0
            below = z[k + n] if row + 1 < n else 0
            az = scale * (
                horizontal[row][col] * (center - left)
                + horizontal[row][col + 1] * (center - right)
                + vertical[row][col] * (center - above)
                + vertical[row + 1][col] * (center - below)
            )
            residual = az - denominator * rhs[k]
            total += residual * residual
            max_abs = max(max_abs, abs(residual))
    return total, max_abs


def _source_sha256():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def verify(instance_path, solution_path, *, expected_instance_sha256=None):
    """Return a JSON-serializable report; malformed files reject rather than raise.

    The instance path must come from the buyer, not the supplier. Supplying an
    independently pinned expected_instance_sha256 additionally checks that trust
    boundary. CLI exit 0 means certified, 1 means valid but uncertified, 2 invalid.
    Big exact result integers are decimal strings to survive JSON/JS transport.
    """
    wall_start = time.perf_counter_ns()
    cpu_start = time.process_time_ns()
    report = {
        "schema": "diffusion-verification-v1", "verifier_version": VERSION,
        "verifier_source_sha256": _source_sha256(), "accepted": False,
        "status": "invalid", "reason": "not checked",
        "acceptance_scope": "fixed_discrete_model_l2_error_only",
        "cost": {"input_bytes": 0, "nodes_checked": 0, "residual_rows": 0,
                 "edge_weight_reads": 0, "integer_residual_squares": 0},
    }
    try:
        instance, raw_instance = _read(instance_path)
        report["cost"]["input_bytes"] += len(raw_instance)
        validate_instance(instance)
        digest = canonical_sha256(instance)
        report.update(instance_id=instance["instance_id"], instance_sha256=digest,
                      instance_file_sha256=hashlib.sha256(raw_instance).hexdigest())
        if expected_instance_sha256 is not None:
            _hash(expected_instance_sha256, "expected_instance_sha256")
            if digest != expected_instance_sha256:
                raise Invalid("buyer-pinned instance hash mismatch")
            report["instance_binding"] = "buyer_pinned_hash"
        else:
            report["instance_binding"] = "caller_selected_file_no_external_hash_pin"
        solution, raw_solution = _read(solution_path)
        report["cost"]["input_bytes"] += len(raw_solution)
        _validate_solution(solution, instance, digest)
        report["solution_sha256"] = canonical_sha256(solution)
        report["solution_file_sha256"] = hashlib.sha256(raw_solution).hexdigest()
        total, max_abs = _residual_sum_squares(instance, solution["z"])
        n = instance["n"]
        denominator = 1 << instance["q"]
        tol = instance["tolerance"]
        left = total * tol["denominator"] ** 2
        right = (8 * denominator * tol["numerator"]) ** 2
        accepted = left <= right
        report.update(
            accepted=accepted, status="certified" if accepted else "uncertified",
            reason="exact residual bound meets contract" if accepted else "exact residual bound exceeds contract",
            n=n, nodes=n * n, fixedpoint_denominator=str(denominator),
            lambda_min_lower_bound=8, residual_sum_squares=str(total),
            residual_max_abs=str(max_abs), comparison_left=str(left),
            comparison_right=str(right), tolerance=tol,
            error_l2_upper_bound_squared={"numerator": str(total), "denominator": str((8 * denominator) ** 2)},
        )
        report["cost"].update(nodes_checked=n * n, residual_rows=n * n,
                              edge_weight_reads=4 * n * n, integer_residual_squares=n * n)
    except (Invalid, OSError) as exc:
        report["reason"] = str(exc)
    report["cost"]["wall_ns"] = time.perf_counter_ns() - wall_start
    report["cost"]["process_ns"] = time.process_time_ns() - cpu_start
    return report


def verify_batch(jobs):
    """Verify (instance_path, solution_path, pinned_hash) triples, reject repeated IDs.

    All occurrences of a repeated valid instance ID are invalid in this batch.
    This is batch integrity, NOT durable exactly-once delivery or payment state.
    """
    if type(jobs) is not list or len(jobs) > 4096:
        raise Invalid("batch must be a list with at most 4096 jobs")
    reports = [verify(i, s, expected_instance_sha256=h) for i, s, h in jobs]
    counts = {}
    for report in reports:
        if "instance_id" in report:
            ident = report["instance_id"]
            counts[ident] = counts.get(ident, 0) + 1
    for report in reports:
        if counts.get(report.get("instance_id"), 0) > 1:
            report.update(accepted=False, status="invalid", reason="duplicate instance_id in batch")
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("instance")
    parser.add_argument("solution")
    parser.add_argument("--expected-instance-sha256")
    args = parser.parse_args()
    report = verify(args.instance, args.solution,
                    expected_instance_sha256=args.expected_instance_sha256)
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0 if report["accepted"] else (2 if report["status"] == "invalid" else 1)


if __name__ == "__main__":
    raise SystemExit(main())
