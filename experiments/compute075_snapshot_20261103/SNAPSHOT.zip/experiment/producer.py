"""Ordinary scientific solvers producing independently certifiable artifacts.

No claimed novelty: standard sparse direct and Poisson-preconditioned CG routes.
No verifier import: producer's numeric convergence is never acceptance authority.
"""
import hashlib
import json
import math
import time
from pathlib import Path
import numpy as np
from scipy import sparse
from scipy.fft import dstn, idstn
from scipy.sparse.linalg import LinearOperator, cg, spsolve


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()


def instance_hash(instance):
    return hashlib.sha256(canonical(instance)).hexdigest()


def build_matrix(instance):
    n=instance["n"]
    h=np.asarray(instance["horizontal"],dtype=np.float64)
    v=np.asarray(instance["vertical"],dtype=np.float64)
    diagonal=(h[:,:-1]+h[:,1:]+v[:-1,:]+v[1:,:]).ravel()
    right=np.zeros(n*n-1,dtype=np.float64)
    mask=np.arange(n*n-1)%n != n-1
    right[mask]=-h[:,1:n].ravel()
    down=-v[1:n,:].ravel()
    return (n+1)**2*sparse.diags([down,right,diagonal,right,down],[-n,-1,0,1,n],format="csr")


def poisson_preconditioner(n):
    s=np.arange(1,n+1,dtype=np.float64)
    eig=4*(n+1)**2*(np.sin(np.pi*s/(2*(n+1)))**2)
    spectrum=eig[:,None]+eig[None,:]
    def solve(x):
        return idstn(dstn(x.reshape(n,n),type=1,norm="ortho")/spectrum,
                     type=1,norm="ortho").ravel()
    return LinearOperator((n*n,n*n),matvec=solve,dtype=np.float64)


def solve(instance, method="pcg"):
    wall=time.perf_counter();cpu=time.process_time()
    A=build_matrix(instance);f=np.asarray(instance["rhs"],dtype=np.float64)
    setup_wall=time.perf_counter()-wall
    count=0
    def step(_):
        nonlocal count
        count+=1
    if method=="direct":
        u=spsolve(A,f);status=0
    elif method in ("pcg","cg"):
        M=poisson_preconditioner(instance["n"]) if method=="pcg" else None
        tol=instance["tolerance"]["numerator"]/instance["tolerance"]["denominator"]
        # Target a conservative spectral-bound residual, leaving headroom for
        # quantization. This is engineering, not final acceptance.
        u,status=cg(A,f,M=M,rtol=0.,atol=tol,maxiter=20*instance["n"],callback=step)
    else:
        raise ValueError("unsupported method")
    if not np.all(np.isfinite(u)):
        raise ValueError("nonfinite solver output")
    scale=1<<instance["q"]
    z=[int(round(float(x)*scale)) for x in u]
    solution={"schema":"diffusion-solution-v1","instance_id":instance["instance_id"],
              "instance_sha256":instance_hash(instance),"z":z}
    receipt={"method":method,"cpu_seconds":time.process_time()-cpu,
             "wall_seconds":time.perf_counter()-wall,"setup_wall_seconds":setup_wall,
             "iterations":count,"solver_status":int(status),
             "numeric_residual_l2":float(np.linalg.norm(A.dot(np.asarray(z,dtype=np.float64)/scale)-f)),
             "acceptance":None,"acceptance_owner":"independent verifier"}
    return solution,receipt


def make_development(n=16, seed=75, contrast=4, q=60):
    # Authored mathematical workload, not a measured physical device or demand.
    rng=np.random.default_rng(seed)
    choices=np.asarray([1,2,contrast],dtype=np.int64)
    h=rng.choice(choices,size=(n,n+1)).tolist()
    v=rng.choice(choices,size=(n+1,n)).tolist()
    rhs=np.zeros((n,n),dtype=np.int64)
    rhs[n//4:3*n//4,n//4:3*n//4]=10
    rhs[:,n//2:]-=2
    return {"schema":"diffusion-instance-v1","instance_id":f"dev-n{n}-s{seed}-c{contrast}",
            "n":n,"q":q,"tolerance":{"numerator":1,"denominator":100_000_000},
            "horizontal":h,"vertical":v,"rhs":rhs.ravel().tolist()}


if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser();p.add_argument("--instance",type=Path);p.add_argument("--output",type=Path,required=True)
    p.add_argument("--method",choices=["direct","pcg","cg"],default="pcg");p.add_argument("--n",type=int,default=16)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    inp=json.loads(a.instance.read_text()) if a.instance else make_development(a.n)
    sol,receipt=solve(inp,a.method)
    (a.output/"instance.json").write_bytes(canonical(inp))
    (a.output/"solution.json").write_bytes(canonical(sol))
    (a.output/"production.json").write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt,indent=2))
