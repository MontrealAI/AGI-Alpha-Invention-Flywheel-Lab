"""Finite conditional commerce. Never an optimizer with buyer-private access.

Every amount reported as account profit/cash comes from the canonical native
account. Workload timing is measured separately, never converted to human labor.
"""
from __future__ import annotations
import copy
import datetime
import hashlib
import json
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent


def public_seller_policy(*, posted_price, package_costs, prospect_cost, available,
                         buyer_acceptances=None, supplier_accepts=None):
    """Only permitted public facts. No profile, label, value or outside cost."""
    if posted_price*len(package_costs)-sum(package_costs)-prospect_cost <= 0:
        return 'decline_nonpositive_best_case_margin'
    if available < prospect_cost:
        return 'defer_prospect_check_unfunded'
    if buyer_acceptances is None:
        if available < prospect_cost+package_costs[0]+posted_price+200_000:
            return 'defer_preflight_liquidity'
        return 'buy_prospect_checks'
    if not all(buyer_acceptances):
        return 'decline_buyer_response'
    if supplier_accepts is not True:
        return 'decline_supplier_response'
    # Native mandatory exposure is price plus 0.20. Principal reserve is not expense.
    if available < package_costs[0]+posted_price+200_000:
        return 'defer_first_package_and_exposure_unfunded'
    return 'produce_first'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')


def main():
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True,help='Fresh staged canonical source root matching the frozen hashes')
    args=parser.parse_args()
    SOURCE=args.source.resolve()
    freeze=json.loads((HERE/'FINANCIAL_FREEZE.json').read_text())
    for relative,digest in freeze['local_files'].items():
        if sha(HERE/relative)!=digest:raise RuntimeError('LOCAL_FREEZE_CHANGED:'+relative)
    for relative,digest in freeze['native_source_files'].items():
        if sha(SOURCE/relative)!=digest:raise RuntimeError('NATIVE_FREEZE_CHANGED:'+relative)
    protocol=json.loads((HERE/'FINANCIAL_PROTOCOL.json').read_text())
    sys.path.insert(0,str(SOURCE))
    from compute075 import service
    from compute075.native import BusinessAccount,buyer_choice,supplier_choice,cost_contract
    from commercial.ledger import digest as canonical_digest
    from producer import canonical,make_development,solve
    from fresh_workloads import selected_method
    import numpy as np
    output=HERE/'financial_execution';output.mkdir(exist_ok=False)
    private=HERE/'native_private';private.mkdir(exist_ok=False)
    inputs=SOURCE/'compute075/experiment_inputs/finance075_v1';inputs.mkdir(parents=True,exist_ok=False)
    price=protocol['posted_price'];check_cost=protocol['prospect_check']['microUSD_per_buyer']
    report={'schema':'compute075-financial-results-v1','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'protocol_sha256':sha(HERE/'FINANCIAL_PROTOCOL.json'),'freeze_sha256':sha(HERE/'FINANCIAL_FREEZE.json'),
            'scope':protocol['claim_boundaries'],'arms':[],'commercial_delivery_count':0,
            'learning_advantage':'NOT_TESTED','actual_billing':None,'terminal':False}
    start_wall=time.perf_counter();start_cpu=time.process_time()
    for arm_index,arm in enumerate(protocol['arms']):
        arm_start=time.perf_counter();arm_cpu=time.process_time()
        result={'id':arm['id'],'input_binding':[],'public_decisions':[],'events':[],
                'production':[],'scope':'INDEPENDENT_CONDITIONAL_ACCOUNT_NOT_POOLED'}
        report['arms'].append(result)
        account=None
        try:
            # Environment owns private preference profiles. The seller gets only
            # public accept/refuse after the corresponding native prospect debit.
            profile=protocol['buyer_profiles'][arm['buyer']]
            decision=buyer_choice(price=price,**profile)
            supplier_data=protocol['cost_scope']['supplier' if arm['supplier']=='participates' else 'supplier_refusal']
            supplier=supplier_choice(**supplier_data)
            requests=[];instances=[];package_costs=[]
            for index,n in enumerate(protocol['request_generation']['n']):
                instance=make_development(n,protocol['request_generation']['seed_base']+index)
                if index==1:
                    instance['horizontal']=[[1 if (i//max(1,n//8))%2==0 else 4 for j in range(n+1)] for i in range(n)]
                    instance['vertical']=[[2 if (j//max(1,n//8))%2==0 else 4 for j in range(n)] for i in range(n+1)]
                    yy,xx=np.mgrid[:n,:n];rhs=np.where((xx-n/2)**2+(yy-n/2)**2 < (n/4)**2,7,-1)
                    instance['rhs']=rhs.ravel().tolist()
                ident=f'compute075-fin-{arm_index:02d}-{index+1}'
                instance['instance_id']=ident
                path=inputs/(ident+'.json');path.write_bytes(canonical(instance))
                instance_hash=service.verifier.canonical_sha256(instance)
                items=copy.deepcopy(protocol['cost_scope']['per_request'])
                items['research_construction']=arm['construction'] if index==0 else 0
                costs=cost_contract(items);package_costs.append(costs['total_microUSD'])
                request={'id':ident,'instance_path':str(path.relative_to(SOURCE)),
                    'instance_sha256':instance_hash,'delivery_path':f'compute075/deliveries/finance075_v1/{ident}.json',
                    'market':{'buyer_id':ident+'-buyer','decision':decision},
                    'resource':{'costs':costs,'supplier':supplier,'expected_net':price-costs['total_microUSD'],
                                'allow_seed':index==0,'max_attempts':protocol['cost_scope']['max_attempts']}}
                requests.append(request);instances.append(instance)
                result['input_binding'].append({'request_id':ident,'instance_sha256':instance_hash,'raw_file_sha256':sha(path)})
            manifest=service.prepare_manifest(SOURCE,requests)
            arm_path=output/f'arm_{arm_index:02d}';arm_path.mkdir()
            save(arm_path/'manifest.json',manifest)
            result['manifest_sha256']=canonical_digest(manifest)
            result['inputs_frozen_before_production_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            account=BusinessAccount(SOURCE,manifest,private/(arm['id']+'.sqlite'),opening=arm['opening'])
            public={'posted_price':price,'package_costs':package_costs,'prospect_cost':check_cost*2,
                    'available':account.snapshot()['summary']['available']}
            first=public_seller_policy(**public)
            result['public_decisions'].append({'stage':'before_checks','visible':public,'decision':first})
            if first=='buy_prospect_checks':
                for index in range(2):
                    # The account is owned by this single runner. Snapshot/availability
                    # and cost execute under the canonical writer lease, not a copied balance.
                    assert account.audit()['accepted']
                    if account.snapshot()['summary']['available']<check_cost:
                        raise RuntimeError('PROSPECT_CHECK_FUNDS_CHANGED')
                    account.account.cost(f'compute075-prospect-{arm_index:02d}-{index+1}',check_cost,0)
                    result['events'].append({'kind':'paid_prospect_check','request_id':requests[index]['id'],
                        'cost_microUSD':check_cost,'clock':0,'observed_buyer_acceptance':decision['chosen']=='certified_supplier'})
                public.update(available=account.snapshot()['summary']['available'],
                    buyer_acceptances=[decision['chosen']=='certified_supplier']*2,
                    supplier_accepts=supplier['participates'])
                first=public_seller_policy(**public)
                result['public_decisions'].append({'stage':'after_paid_checks','visible':public,'decision':first})
            if first=='produce_first':
                for index,request in enumerate(requests):
                    clock=protocol['native_clock']['request'+str(index+1)]
                    job=request['id'];order=job+'-order'
                    try:
                        prepaid=account.prepay(job,clock['prepay'])
                    except ValueError as exc:
                        if 'AVAILABLE_FUNDS_REQUIRED' not in str(exc):raise
                        result['events'].append({'kind':'deferred_native_funds','request_id':job,'reason':str(exc),
                            'native_snapshot':account.snapshot()['summary']})
                        break
                    result['events'].append({'kind':'native_prepaid','request_id':job,'receipt':prepaid})
                    if index==1 and prepaid['funding']!='EARNED':raise RuntimeError('SECOND_REQUEST_NOT_EARNED')
                    account.begin_order(job,order,request['market']['buyer_id'],decision,clock['order'],clock['deadline'],
                        maturity_day=clock['maturity'],residual=protocol['native_clock']['residual_microUSD'])
                    # Native package and complete offer are in place before fresh solve.
                    wall=time.perf_counter();cpu=time.process_time()
                    artifact,producer_receipt=solve(instances[index],selected_method(instances[index]))
                    solpath=arm_path/f'solution_{index+1}.json';solpath.write_bytes(canonical(artifact))
                    certificate=service.verifier.verify(service.safe_path(SOURCE,request['instance_path']),solpath,
                        expected_instance_sha256=request['instance_sha256'])
                    if not certificate['accepted']:raise RuntimeError('FRESH_COMMERCIAL_PRODUCER_FAILED_CERTIFICATE')
                    rec={'request_id':job,'method':selected_method(instances[index]),
                         'solution_sha256':canonical_digest(artifact),'producer_receipt':producer_receipt,'certificate':certificate,
                         'complete_math_wall_seconds':time.perf_counter()-wall,'complete_math_cpu_seconds':time.process_time()-cpu}
                    result['production'].append(rec)
                    native_wall=time.perf_counter();native_cpu=time.process_time()
                    if index==0 and arm['delivery_mode']=='corrupt_then_correct':
                        bad=copy.deepcopy(artifact);bad['z'][0]+=1<<instances[index]['q']
                        rejected=account.complete_order(order,job,bad,clock['deadline'])
                        if rejected['accepted']:raise RuntimeError('CORRUPTION_ACCEPTED')
                        result['events'].append({'kind':'invalid_attempt_rejected','request_id':job,'certificate':rejected})
                    if index==0 and arm['delivery_mode']=='late':
                        try:account.complete_order(order,job,artifact,clock['deadline']+1)
                        except ValueError as exc:
                            if 'LATE_DELIVERY' not in str(exc):raise
                            result['events'].append({'kind':'late_valid_rejected','request_id':job,'reason':str(exc)})
                        else:raise RuntimeError('LATE_DELIVERY_ACCEPTED')
                        account.refund(order,clock['deadline']+1);account.advance(clock['settle'])
                        rec['native_submission_wall_seconds']=time.perf_counter()-native_wall
                        rec['native_submission_cpu_seconds']=time.process_time()-native_cpu
                        break
                    accepted=account.complete_order(order,job,artifact,clock['deadline'])
                    if not accepted['accepted']:raise RuntimeError('VALID_DELIVERY_NATIVE_REJECTED')
                    account.release(order,clock['deadline'])
                    revenue=account.snapshot()['summary']['revenue']
                    account.release(order,clock['deadline'])
                    if account.snapshot()['summary']['revenue']!=revenue:raise RuntimeError('DUPLICATE_RELEASE_ADDED_REVENUE')
                    result['events'].append({'kind':'accepted_and_released','request_id':job,'duplicate_release_did_not_add_revenue':True})
                    report['commercial_delivery_count']+=1
                    if index==0 and arm['delivery_mode']=='claim_1000000':
                        account.claim(order,order+'-claim',1_000_000,clock['maturity'])
                        account.resolve_claim(order,order+'-claim',order+'-settlement','pay',clock['maturity'])
                        result['events'].append({'kind':'support_claim_paid','microUSD':1_000_000,'clock':clock['maturity']})
                    account.advance(clock['settle'])
                    rec['native_submission_wall_seconds']=time.perf_counter()-native_wall
                    rec['native_submission_cpu_seconds']=time.process_time()-native_cpu
            result['summary']=account.snapshot()['summary']
            result['audit']=account.audit()
            if not result['audit']['accepted']:raise RuntimeError('NATIVE_AUDIT_FAILED')
            record=account.export();save(arm_path/'account_export.json',record)
            result['account_export_sha256']=canonical_digest(record)
            result['public_dependencies']=__import__('compute075.native',fromlist=['public_dependencies']).public_dependencies(record,root=SOURCE,manifest=manifest)
            result['finished']=True
        except Exception as exc:
            result['failure']={'type':type(exc).__name__,'reason':str(exc),'uncertain':'No automatic retry; preserve source, artifacts and native account for inspection.'}
            if account is not None:
                try:
                    result['summary']=account.snapshot()['summary'];save(output/f'failed_arm_{arm_index:02d}_account_export.json',account.export())
                except Exception as inspect_error:result['inspection_error']=str(inspect_error)
            report['stopped_on_unexpected_failure']=True
        finally:
            if account is not None:account.close()
            result['complete_arm_wall_seconds']=time.perf_counter()-arm_start
            result['complete_arm_cpu_seconds']=time.process_time()-arm_cpu
            report['total_wall_seconds']=time.perf_counter()-start_wall
            report['total_cpu_seconds']=time.process_time()-start_cpu
            save(output/'RESULTS.json',report)
            print(json.dumps({'arm':arm['id'],'finished':result.get('finished',False),'summary':result.get('summary'),'failure':result.get('failure')}),flush=True)
        if report.get('stopped_on_unexpected_failure'):break
    report['terminal']=len(report['arms'])==len(protocol['arms']) and not report.get('stopped_on_unexpected_failure')
    report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(output/'RESULTS.json',report)
    print(json.dumps({'terminal':report['terminal'],'arms':len(report['arms']),'accepted_paid_deliveries':report['commercial_delivery_count'],
                      'total_wall_seconds':report['total_wall_seconds']}),flush=True)


if __name__=='__main__':main()
