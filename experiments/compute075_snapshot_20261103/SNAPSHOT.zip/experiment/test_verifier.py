"""Stdlib-only independent assembly and adversarial regression checks."""

import copy
import json
import random
import tempfile
import unittest
from pathlib import Path

import verifier as v


def incidence_apply(instance, x):
    """Independent edge-scatter formulation; deliberately not a row stencil."""
    n = instance["n"]
    answer = [0] * (n * n)
    scale = (n + 1) ** 2

    def edge(p, q, weight):
        xp = 0 if p is None else x[p]
        xq = 0 if q is None else x[q]
        flux = scale * weight * (xp - xq)
        if p is not None:
            answer[p] += flux
        if q is not None:
            answer[q] -= flux

    for row in range(n):
        for col in range(n + 1):
            p = row * n + col - 1 if col > 0 else None
            q = row * n + col if col < n else None
            edge(p, q, instance["horizontal"][row][col])
    for row in range(n + 1):
        for col in range(n):
            p = (row - 1) * n + col if row > 0 else None
            q = row * n + col if row < n else None
            edge(p, q, instance["vertical"][row][col])
    return answer


def fixture(n=2, q=10):
    instance = {"schema": "diffusion-instance-v1", "instance_id": "manufactured-001",
                "n": n, "q": q, "tolerance": {"numerator": 0, "denominator": 1},
                "horizontal": [[(1, 2, 4)[(r + c) % 3] for c in range(n + 1)] for r in range(n)],
                "vertical": [[(1, 2, 4)[(2 * r + c) % 3] for c in range(n)] for r in range(n + 1)],
                "rhs": [0] * (n * n)}
    exact_u = [((i * 7) % 11) - 5 for i in range(n * n)]
    instance["rhs"] = incidence_apply(instance, exact_u)
    solution = {"schema": "diffusion-solution-v1", "instance_id": instance["instance_id"],
                "instance_sha256": v.canonical_sha256(instance),
                "z": [u * (1 << q) for u in exact_u]}
    return instance, solution


class VerifierTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.ip = Path(self.temp.name) / "instance.json"
        self.sp = Path(self.temp.name) / "solution.json"

    def write(self, instance, solution, repin=True):
        if repin:
            solution["instance_sha256"] = v.canonical_sha256(instance)
        self.ip.write_text(json.dumps(instance))
        self.sp.write_text(json.dumps(solution))

    def check(self, instance, solution, repin=True):
        self.write(instance, solution, repin)
        return v.verify(self.ip, self.sp, expected_instance_sha256=v.canonical_sha256(instance))

    def test_known_exact_manufactured(self):
        instance, solution = fixture()
        # Separate explicit known result, not generated solely through helper.
        self.assertEqual(instance["rhs"], [-324, 207, -216, 504])
        result = self.check(instance, solution)
        self.assertTrue(result["accepted"])
        self.assertEqual(result["residual_sum_squares"], "0")
        self.assertEqual(result["cost"]["residual_rows"], 4)
        self.assertEqual(result["cost"]["edge_weight_reads"], 16)
        self.assertEqual(result["instance_binding"], "buyer_pinned_hash")

    def test_corruption(self):
        instance, solution = fixture()
        solution["z"][0] += 1
        result = self.check(instance, solution)
        self.assertFalse(result["accepted"])
        self.assertEqual(result["status"], "uncertified")

    def test_exact_threshold(self):
        instance, solution = fixture(n=1, q=0)
        instance["horizontal"] = [[1, 1]]
        instance["vertical"] = [[1], [1]]
        instance["rhs"] = [0]
        instance["tolerance"] = {"numerator": 2, "denominator": 1}
        solution["z"] = [1]  # A=16, certificate upper bound 2.
        result = self.check(instance, solution)
        self.assertTrue(result["accepted"])
        self.assertEqual(result["comparison_left"], result["comparison_right"])
        instance["tolerance"] = {"numerator": 1999, "denominator": 1000}
        self.assertEqual(self.check(instance, solution)["status"], "uncertified")

    def test_wrong_instance(self):
        instance, solution = fixture()
        instance["rhs"][0] += 1
        self.assertEqual(self.check(instance, solution, repin=False)["status"], "invalid")
        self.write(instance, solution)
        self.assertEqual(v.verify(self.ip, self.sp, expected_instance_sha256="0" * 64)["status"], "invalid")

    def test_boundary_edges_not_ignored(self):
        for axis, row, col in [("horizontal", 0, 0), ("horizontal", 0, 2),
                               ("vertical", 0, 0), ("vertical", 2, 0)]:
            instance, solution = fixture()
            old = instance[axis][row][col]
            instance[axis][row][col] = 2 if old == 1 else 1
            self.assertEqual(self.check(instance, solution)["status"], "uncertified")
        instance, solution = fixture(n=1)
        self.assertTrue(self.check(instance, solution)["accepted"])

    def test_invalid_conductance(self):
        for bad in [0, -1, 3, 8, True, 1.0, "1"]:
            instance, solution = fixture()
            instance["horizontal"][0][0] = bad
            self.assertEqual(self.check(instance, solution)["status"], "invalid")

    def test_ids_dimensions_extra_keys(self):
        for bad in ["", "../evil", "a b", "é", "x" * 129, 1, None]:
            instance, solution = fixture()
            instance["instance_id"] = bad
            self.assertEqual(self.check(instance, solution)["status"], "invalid")
        for mutate in [lambda i, s: s["z"].append(1),
                       lambda i, s: i["rhs"].pop(),
                       lambda i, s: i["vertical"].pop(),
                       lambda i, s: s.update(accepted=True),
                       lambda i, s: s.update(instance_id="another"),
                       lambda i, s: i.update(n=True),
                       lambda i, s: s["z"].__setitem__(0, True)]:
            instance, solution = fixture()
            mutate(instance, solution)
            self.assertEqual(self.check(instance, solution)["status"], "invalid")

    def test_parser_rejects_duplicates_nonintegers_and_depth(self):
        instance, solution = fixture()
        self.write(instance, solution)
        for raw in [b'{"n":1,"n":2}', b'{"q":NaN}', b'{"q":Infinity}',
                    b'{"q":1.0}', b'{"q":1e2}', b'{"q":' + b'9' * 41 + b'}',
                    b'[' * 9 + b']' * 9, b'\xff', b'{} {}']:
            self.ip.write_bytes(raw)
            self.assertEqual(v.verify(self.ip, self.sp)["status"], "invalid")
        # Duplicate nested keys also fail before numerical validation.
        self.ip.write_text('{"tolerance":{"numerator":1,"numerator":0}}')
        self.assertIn("duplicate", v.verify(self.ip, self.sp)["reason"])

    def test_extreme_integer_arithmetic_and_caps(self):
        instance, solution = fixture(n=1, q=60)
        instance["rhs"] = [-v.MAX_RHS]
        solution["z"] = [v.MAX_Z]
        result = self.check(instance, solution)
        self.assertEqual(result["status"], "uncertified")
        self.assertGreater(int(result["residual_sum_squares"]), 1 << 250)
        for target, key, value in [("i", "n", 0), ("i", "n", 257),
                                   ("i", "q", 61), ("i", "q", -1)]:
            i, s = fixture()
            i[key] = value
            self.assertEqual(self.check(i, s)["status"], "invalid")
        instance, solution = fixture()
        solution["z"][0] = 1 << 127
        self.assertEqual(self.check(instance, solution)["status"], "invalid")
        instance, solution = fixture()
        instance["rhs"][0] = 1 << 63
        self.assertEqual(self.check(instance, solution)["status"], "invalid")
        instance, solution = fixture()
        instance["tolerance"]["denominator"] = 0
        self.assertEqual(self.check(instance, solution)["status"], "invalid")

    def test_file_size_limit(self):
        instance, solution = fixture()
        self.write(instance, solution)
        self.ip.write_bytes(b" " * (v.MAX_FILE_BYTES + 1))
        self.assertIn("byte cap", v.verify(self.ip, self.sp)["reason"])

    def test_batch_duplicate_ids_reject_all(self):
        instance, solution = fixture()
        self.write(instance, solution)
        job = (self.ip, self.sp, v.canonical_sha256(instance))
        reports = v.verify_batch([job, job])
        self.assertTrue(all(r["status"] == "invalid" for r in reports))
        self.assertTrue(all(not r["accepted"] for r in reports))

    def test_hash_canonicalization(self):
        instance, solution = fixture()
        self.write(instance, solution)
        a = v.verify(self.ip, self.sp)
        self.ip.write_text(json.dumps(instance, sort_keys=True, indent=4))
        b = v.verify(self.ip, self.sp)
        self.assertTrue(b["accepted"])
        self.assertEqual(a["instance_sha256"], b["instance_sha256"])
        self.assertNotEqual(a["instance_file_sha256"], b["instance_file_sha256"])

    def test_randomized_independent_residuals(self):
        rng = random.Random(20261103)  # Public reproducible engineering tests.
        for _ in range(100):
            n = rng.randrange(1, 8)
            instance, solution = fixture(n=n, q=rng.randrange(0, 20))
            instance["horizontal"] = [[rng.choice((1, 2, 4)) for _ in range(n + 1)] for _ in range(n)]
            instance["vertical"] = [[rng.choice((1, 2, 4)) for _ in range(n)] for _ in range(n + 1)]
            exact_u = [rng.randrange(-10, 11) for _ in range(n * n)]
            instance["rhs"] = incidence_apply(instance, exact_u)
            solution["z"] = [u * (1 << instance["q"]) for u in exact_u]
            self.assertTrue(self.check(instance, solution)["accepted"])
            solution["z"][rng.randrange(n * n)] += rng.choice((-3, -1, 1, 3))
            expected_r = [a - (1 << instance["q"]) * f for a, f in
                          zip(incidence_apply(instance, solution["z"]), instance["rhs"])]
            report = self.check(instance, solution)
            self.assertEqual(int(report["residual_sum_squares"]), sum(r * r for r in expected_r))
            self.assertEqual(report["status"], "uncertified")
            # The exact manufactured solution independently fixes the true error.
            error_numerator_sq = sum((z - u * (1 << instance["q"])) ** 2
                                     for z, u in zip(solution["z"], exact_u))
            self.assertGreaterEqual(sum(r * r for r in expected_r), 64 * error_numerator_sq)


if __name__ == "__main__":
    unittest.main()
