"""Explicit public-metadata identity adaptation; never relax native checks.

Original metadata bytes are unavailable here. Original identities are declared
historical references backed by the packaged review attestation, not hashes of
the redacted public files. Every other local/runtime source remains exact.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
ALLOWED={'FINANCIAL_PROTOCOL.json':'owner','FINANCIAL_PROTOCOL_REVIEW.json':'owner','PINNED_NATIVE_REGRESSIONS.json':'independent_provenance'}
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):
 def pairs(items):
  result={}
  for k,v in items:
   if k in result:raise ValueError('DUPLICATE_METADATA_FIELD')
   result[k]=v
  return result
 return json.loads(Path(p).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE_METADATA')))
def validate_redactions():
 m=read(ROOT/'PUBLIC_METADATA_REDACTIONS.json')
 if m.get('schema')!='compute075/public-metadata-redactions/v1' or set(m.get('files',{}))!=set(ALLOWED):raise ValueError('EXACT_PUBLIC_METADATA_SCOPE_REQUIRED')
 for name,field in ALLOWED.items():
  spec=m['files'][name];p=ROOT/name
  if p.is_symlink() or spec['field_paths']!=['/'+field] or sha(p)!=spec['public_sha256']:raise ValueError('PUBLIC_METADATA_BYTES_CHANGED')
  obj=read(p)
  if obj.get(field)!=spec['public_value']:raise ValueError('PUBLIC_METADATA_REPLACEMENT_CHANGED')
  projection={k:v for k,v in obj.items() if k!=field}
  if hashlib.sha256(canonical(projection)).hexdigest()!=spec['unchanged_fields_canonical_sha256']:raise ValueError('PUBLIC_METADATA_NONREDACTED_FIELDS_CHANGED')
 return m
def original_or_public_identity(path):
 p=Path(path).resolve();m=validate_redactions()
 if p.parent==ROOT and p.name in ALLOWED:return m['files'][p.name]['original_sha256']
 return sha(p)
def disclosure():
 m=validate_redactions()
 return {'scope':m['scope'],'original_metadata_bytes_verified_from_public_package':False,
  'public_hashes_and_nonredacted_projections_verified':True,'native_checks_changed':False,
  'original_hash_basis':'Historical identity plus packaged reviewer attestation; original redacted metadata bytes unavailable.',
  'redaction_manifest_sha256':sha(ROOT/'PUBLIC_METADATA_REDACTIONS.json'),
  'public_protocol_sha256':sha(ROOT/'FINANCIAL_PROTOCOL.json')}
