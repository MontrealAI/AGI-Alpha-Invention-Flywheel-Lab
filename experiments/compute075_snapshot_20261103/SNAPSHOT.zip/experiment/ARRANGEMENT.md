# Certified scientific-compute delivery: candidate 075

## Valuable outcome and economic opening

Deliver a requested discrete scientific solution with a portable, independently checked
error guarantee. The hypothesized larger opening is that automatically formulating,
solving and qualifying many heterogeneous computational jobs could make lower-trust
capacity usable without forcing every buyer to build a bespoke verification team.
Ordinary algorithms are welcome. This is not yet a new industry, trusted-computing
breakthrough or proof of retained learning advantage.

The first concrete output is a heterogeneous two-dimensional diffusion/Poisson field on
a specified positive-conductance grid, with a fixed absolute l2 error tolerance. The accepted
artifact is the fixed-point solution to that discrete mathematical request. It is not
physical validation of a material, plant or operating decision. No equipment is controlled.

Potential buyers are scientific-computing users whose contract explicitly values a
checked solution. They can choose direct trusted computation, competent human plus
conventional software, human-plus-AI engineering, self-service or no purchase. Suppliers
can refuse work or choose their outside option. There are no real customers here.

## First delivery contract

- Input: source-bound integer-conductance Dirichlet problem with an integer right-hand
  side, fixed-point precision and rational error tolerance.
- Output: identified fixed-point field, dimensions, hashes and an independent exact-integer
  residual certificate with a justified spectral error bound.
- Acceptance: the independent verifier accepts the unchanged request and delivered bytes.
  Solver convergence flags, sample checks and approximate residuals cannot replace it.
- Latency: declared per-job simulated deadline; late useful work is still recorded but
  does not collect under the on-time contract. Correction/retry is bounded and costed.
- Price, acquisition, supplier payment, verification, support, refund, collection delay,
  financing and residual-obligation terms: set in a separate finite conditional native
  economic protocol before its outcomes, not inferred from nominal CPU time.
- Privacy, confidentiality, availability and honest supplier incentives are separate
  requirements. A correct answer certificate establishes none of them.

## Strong alternatives and decisive comparison

Use SciPy sparse direct factorization and competent preconditioned conjugate gradients;
allow cached structure/factorizations, vectorized residual checks, ordinary exact/interval
bounds and self-service. The certificate formula is known numerical analysis, not a claimed
algorithmic invention. Strong conventional producers may emit the same certified artifact.

The decision is whether to offer this complete service under stated demand/cost conditions,
or choose a direct trusted/self-service route instead. Account for construction, search,
failed delivery, checking, retries, orchestration, acquisition and remaining obligations.
A favorable price assumption alone cannot establish an opening: first measure actual
completed computation and verification, then identify the complete-cost break-even region.

Commercial success and retained-method advantage are independent claims. The first
episode may establish conditional ordinary commerce without any discovery advantage.
No K1-to-K2 claim will be made until a genuinely different useful successor executes
with frozen retention, equal-content strong controls and full costs. No fictional K2
orders or earned financing will be added merely to complete a story.

## Scope and provenance

Local simulation only, included reasoning and existing Python/SciPy/C++ capabilities.
No API Platform, keys, paid model calls, downloads of model weights, external spending,
customer/provider contact or actual purchases. New identity and directory preserve
grid074's negative result unchanged. Native financial integration uses the repository's
canonical account and verifier, never a second ledger.

Prior-art evidence informing alternatives: AlphaEvolve's established algorithm-construction
work (https://arxiv.org/abs/2506.13131), HELIX verified numerical compilation
(https://arxiv.org/abs/2604.18593), structure-aware dispatch including detection/conversion
cost (https://arxiv.org/abs/2608.22099), and KernelBench-Verified's strong correctness/baseline
comparison (https://github.com/facebookresearch/kernel_bench_verified). Their existence
does not reject an economic opportunity. Their capabilities must not be withheld from
the comparators. KernelBench's paid-API generation path was inspected but not used.
