"""Prospectively specified mathematical instances; not empirical domain data."""
from producer import make_development


def cases():
    for idx,n in enumerate((64,128,192,256)):
        for family in ("iid","layered"):
            seed=202611030750+2*idx+(family=="layered")
            case=make_development(n,seed=int(seed))
            case["instance_id"]=f"compute075-fresh-n{n}-{family}"
            if family=="layered":
                # A different coefficient layout from the development generator.
                # No additional operators or unsupported physics are introduced.
                case["horizontal"]=[[1 if (r//max(1,n//8))%2==0 else 4 for c in range(n+1)] for r in range(n)]
                case["vertical"]=[[2 if (c//max(1,n//8))%2==0 else 4 for c in range(n)] for r in range(n+1)]
                case["rhs"]=[7 if (r-n//3)**2+(c-2*n//3)**2<(n//6)**2 else -1 for r in range(n) for c in range(n)]
            yield case


def selected_method(instance):
    """Development-selected ordinary dispatch, no learned superiority claim."""
    return "pcg" if instance["n"]<=128 else "direct"
