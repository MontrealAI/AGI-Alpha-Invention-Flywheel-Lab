"""One execution only, with complete subprocess resource telemetry."""
import datetime
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
marker=root/'FINANCIAL_PROCESS_START.json'
if marker.exists():raise RuntimeError('EXECUTION_ALREADY_STARTED_INSPECT_PRIOR_OUTCOME')
marker.write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':'Single frozen finite scenario subprocess, not a repeat for improved results.'},indent=2)+'\n')
start=time.perf_counter()
with (root/'FINANCIAL_PROCESS_LOG.txt').open('x') as log:
    completed=subprocess.run([sys.executable,'-B',str(root/'run_financial.py'),'--source',sys.argv[1]],stdout=log,stderr=subprocess.STDOUT)
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'returncode':completed.returncode,'complete_subprocess_wall_seconds':time.perf_counter()-start,
        'child_user_seconds':usage.ru_utime,'child_system_seconds':usage.ru_stime,
        'child_max_rss_platform_units':usage.ru_maxrss,
        'scope':'Includes child startup/imports, source freeze checks, input setup, all native calls, producer, checker, terminal reporting and teardown. Excludes earlier construction/review and this launcher startup. Telemetry is not billing.'}
(root/'FINANCIAL_PROCESS_RESOURCES.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(completed.returncode)
