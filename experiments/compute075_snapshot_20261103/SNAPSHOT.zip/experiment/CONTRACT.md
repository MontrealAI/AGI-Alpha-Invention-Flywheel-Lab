# Certified discrete diffusion contract v1

## Claim and non-claims

For the exact finite-dimensional problem `A u* = f` defined below, an accepted
artifact proves `||z / 2^q - u*||_2 <= tolerance`. The norm is ordinary Euclidean
l2 over all `n*n` interior entries, **not RMS**, a continuum norm, a relative
error, or a physical accuracy claim. This proves no model fidelity, mesh error,
real-world safety, profitability, or economic advantage. There is no PDE solver
inside the checker. Rejection as `uncertified` says this sufficient certificate
failed; it does not prove the true error exceeds tolerance.

This is simulation-only. No controls, paid APIs, credentials, purchase, external
publication, or contact are involved.

## Strict wire format

Both files are UTF-8 JSON objects. Unknown/missing keys, duplicate keys, floats
(including `1.0`), NaN/Infinity, booleans in integer positions, oversized numbers,
wrong lengths, and invalid IDs reject. Each file is capped at 16 MiB, nesting at
8, and integer tokens at 40 decimal digits. Accepted schema strings and IDs are
ASCII. Python arbitrary-precision integers prevent wraparound; range/resource
caps avoid unbounded integer work. These caps are not a complete OS sandbox or
protection against a hostile filesystem/FIFO. Use ordinary local files in an
isolated worker with an external deadline for untrusted submissions.

Instance keys, with no extras:

```
{
  "schema": "diffusion-instance-v1",
  "instance_id": "buyer-case-0001",
  "n": 2,
  "q": 20,
  "tolerance": {"numerator": 1, "denominator": 1000000},
  "horizontal": [[1,2,1],[4,1,2]],
  "vertical": [[1,2],[4,1],[2,1]],
  "rhs": [1,2,3,4]
}
```

`1 <= n <= 256`; `0 <= q <= 60`. IDs match
`[A-Za-z0-9][A-Za-z0-9._-]{0,127}`. RHS values are integers with absolute value
at most `2^63-1`. Tolerance is a nonnegative numerator at most `2^127-1` over a
positive denominator at most `2^127-1`; a nonreduced fraction is allowed. Zero
tolerance requires an exactly zero residual. Every conductance is exactly one
of `{1,2,4}`. There are no optional boundary types, conductance overrides,
source overrides, per-entry IDs, or solver-supplied spectral bounds.

Solution keys, with no extras:

```
{
  "schema": "diffusion-solution-v1",
  "instance_id": "buyer-case-0001",
  "instance_sha256": "<64 lowercase hex characters>",
  "z": [0,0,0,0]
}
```

Each z entry is an integer with absolute value at most `2^127-1`. Its length is
exactly `n*n`. The supplier must not add an acceptance flag or metadata. Store
provenance separately and bind it to the solution hash.

## Coordinates, boundaries, and independent row construction

Interior coordinates `(row,col)` run from `0` to `n-1`. Flattening is row-major,
`k = row*n+col`. Every exterior neighbor has value zero, fixed by the schema.
There are no corner edges, and no unknown boundary entries in `z`.

`horizontal[row]` contains `n+1` edge conductances. Entry 0 joins the left
Dirichlet boundary to `(row,0)`, entry j for `1<=j<n` joins `(row,j-1)` to
`(row,j)`, and entry n joins `(row,n-1)` to the right boundary.

`vertical` has `n+1` rows and n columns. Row 0 joins the top boundary to the
first interior row; row j for `1<=j<n` joins interior rows `j-1` and j; row n
joins the last interior row to the bottom boundary.

For each interior p,

`(A z)_p = (n+1)^2 * sum_over_4_edges c_pq * (z_p - z_q)`.

The two incident rows read the same stored conductance on every interior edge.
This enforces symmetry structurally. Every boundary contribution remains in
the diagonal. The verifier builds these rows itself and does not import the
supplier's matrix assembly or residual routine.

## Analytical certificate, independent of tests

For an interior vector x extended as zero on the boundary, the quadratic form
is `(n+1)^2 * sum_edges c_e * (x_p-x_q)^2`, with each interior edge once and
each boundary edge once. Since every `c_e >= 1`, this dominates the analogous
unit-conductance form. Thus `A >= A0` in the positive-semidefinite ordering.

The 1D unit-conductance Dirichlet tridiagonal matrix has sine eigenvectors
`sin(k*pi*j/(n+1))`, with eigenvalues
`4*sin^2(k*pi/(2*(n+1)))`, for `1<=k<=n`. Direct substitution into the
three-point stencil proves this identity. The 2D matrix is the Kronecker sum
of two such matrices times `(n+1)^2`, so

`lambda_min(A0) = 8*(n+1)^2*sin^2(pi/(2*(n+1))) >= 8`.

The inequality uses the concavity chord bound `sin(t) >= 2*t/pi` on
`0<=t<=pi/2`. The smallest eigenvalue is positive; hence A is SPD and the
unique exact discrete solution exists. With `D=2^q`, residual integer vector
`r=A*z-D*f`, and error `e=z/D-u*`, we have `A*e=r/D`. Spectral decomposition
then gives `||e||_2 <= ||r||_2/(8*D)`.

For tolerance `a/b`, acceptance is **exactly** the integer comparison

`(sum r_i^2)*b^2 <= (8*D*a)^2`.

No floating point, square root, numerical eigenvalue estimate, stochastic test,
producer assertion, or residual subsampling is used in acceptance. Numerical
small-grid eigenvalue tests below are implementation checks, not this proof.

Primary source cross-checks: the [Durham University finite-difference course
exercise](https://durham-comp4187.github.io/exercises/finite-differences/)
states the 1D sine eigenvalue formula. [SciPy's official LaplacianNd
documentation](https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.LaplacianNd.html)
documents the signed discrete Laplacian and Dirichlet construction. The
weighted dominance and constant-8 argument above are derived here. Sources
accessed 2026-11-03. No source content is executed or trusted for acceptance.

## Hash binding, interface, and journal integration

Canonical JSON is Python `json.dumps(obj,sort_keys=True,separators=(',',':'),
ensure_ascii=True,allow_nan=False).encode('utf-8')` for validated documents.
The instance SHA-256 covers **all** contract fields, including tolerance, ID,
q, dimensions, edges, and RHS. It is independent of JSON whitespace/key order.
The report also includes raw-file hashes, a canonical solution hash, and the
SHA-256 of the executing verifier source file.

```
python verifier.py buyer_instance.json supplier_solution.json \
  --expected-instance-sha256 BUYER_PINNED_CANONICAL_HASH
```

Exit codes: 0 certified; 1 well-formed but certificate fails; 2 invalid.
The import API is `verify(instance_path, solution_path,
expected_instance_sha256=...) -> dict` (the last argument is keyword-only).
`canonical_sha256(obj)` and `validate_instance(obj)` are public conveniences.
`verify_batch([(instance_path,solution_path,pinned_hash), ...])` additionally
invalidates **all** occurrences of duplicated instance IDs in the batch.

The buyer must select and trust the instance, tolerance, verifier source, and
source hash. For journal use, always pass the independently pinned instance
hash and match the verifier source hash against a separately pinned release.
A supplier-provided instance and a matching supplier-provided hash alone do
not authenticate a buyer's contract. A source self-hash records identity; it
does not itself prove the source is trusted or untampered.

The adapter should issue a delivery event only for `accepted is True`,
`status == 'certified'`, matching buyer-pinned instance and approved verifier
hashes, and the intended canonical solution hash. Store exact comparison
operands and error-bound fraction for audit. Reject repeated deliveries using
durable journal keys; a one-shot verifier is not an exactly-once ledger. Batch
duplicate checking is local to its input and is not durable replay prevention.

`cost` reports actual input bytes, checked node count, residual row count,
four edge-weight reads per residual row, one residual square per row, and
measured wall/process nanoseconds. Logical counts are exact work accounting,
not CPU instructions. Timings are observed environment-dependent overhead
inclusive checks, not portable cost or money estimates. Invalid cases can
report partial input byte counts and zero residual work. The verifier never
assigns a price, debit, payment, or market value. Each batch report contains
its actual one-shot verification cost even if later invalidated for duplicate
IDs. Large exact mathematical results are decimal strings for safe JSON/JS
transport; schema bounded inputs and work counts remain JSON integers.

## Tests and security limits

`python -m unittest -v test_verifier.py` runs the stdlib regression suite.
Manufactured solutions use a separate edge-incidence assembly; randomized
tests use a fixed public seed. They test residuals, boundary edges, exact
threshold equality, nonzero certificates, malformed/duplicate keys, NaN and
floats, wrong instances, corrupt vectors, zero/negative conductances, ID
validity, caps/extreme integers, and batch duplicate IDs. There are no hidden
fresh draws, undisclosed eligibility decisions, external service calls, or
numerical probabilistic proof claims.

`python spectral_check.py > SPECTRAL_ENGINEERING_CHECK.json` is an optional
NumPy/SciPy engineering check, separate from the stdlib acceptance path. It
compares eight unit-conductance grids (`n=1..8`) to SciPy's independent
Dirichlet construction and sine formula, then checks symmetry and spectral
dominance for 160 fixed-seed heterogeneous matrices. These finite numerical
checks neither establish nor replace the analytical certificate. The saved
result pins its check/test/verifier sources and package versions.

The checker assumes a correct Python runtime, trusted verifier release,
ordinary readable local files, trusted buyer pin, and enough process isolation
to prevent concurrent source replacement. It is not formally verified code,
a defense against a compromised OS/runtime, a general PDE certificate, or a
settlement system. SHA-256 collision resistance is the standard binding
assumption; it is not a proof of supplier identity or origin.
