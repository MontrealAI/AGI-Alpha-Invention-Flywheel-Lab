import unittest
from trace_snapshots import append_policy_snapshot


class TraceSnapshotTests(unittest.TestCase):
    def test_original_pattern_reproduces_observed_history_corruption(self):
        log=[];public={'available':20_000_000,'package_costs':[1_180_000,180_000]}
        log.append({'stage':'before_checks','visible':public,'decision':'buy_prospect_checks'})
        public.update(available=19_960_000,buyer_acceptances=[True,True],supplier_accepts=True)
        self.assertEqual(log[0]['visible']['available'],19_960_000)
        self.assertIn('buyer_acceptances',log[0]['visible'])

    def test_future_snapshot_preserves_prepaid_information_boundary(self):
        log=[];public={'available':20_000_000,'package_costs':[1_180_000,180_000]}
        append_policy_snapshot(log,stage='before_checks',visible=public,decision='buy_prospect_checks')
        public.update(available=19_960_000,buyer_acceptances=[True,True],supplier_accepts=True)
        append_policy_snapshot(log,stage='after_paid_checks',visible=public,decision='produce_first')
        self.assertEqual(log[0]['visible']['available'],20_000_000)
        self.assertNotIn('buyer_acceptances',log[0]['visible'])
        self.assertNotIn('supplier_accepts',log[0]['visible'])
        public['package_costs'][0]=0
        public['buyer_acceptances'][0]=False
        self.assertEqual(log[0]['visible']['package_costs'],[1_180_000,180_000])
        self.assertEqual(log[1]['visible']['buyer_acceptances'],[True,True])


if __name__=='__main__':unittest.main()
