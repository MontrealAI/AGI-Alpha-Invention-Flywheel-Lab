"""Prospective trace repair, not used by the frozen financial execution.

Generated after the independent audit exposed mutable input-history aliasing.
This is an ordinary engineering correction, not a learned discovery advantage.
"""
from copy import deepcopy


def append_policy_snapshot(log, *, stage, visible, decision):
    log.append({'stage':stage,'visible':deepcopy(visible),'decision':decision})
