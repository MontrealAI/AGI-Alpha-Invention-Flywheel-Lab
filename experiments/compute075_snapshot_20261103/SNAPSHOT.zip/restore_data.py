"""Restore only allowlisted public JSON evidence, byte-for-byte; no account opens."""
import gzip,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MAX_DECODED_BYTES=4_000_000

def canonical(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def digest(raw):return hashlib.sha256(raw).hexdigest()

def main():
 manifest=json.loads((ROOT/'DATA_MANIFEST.json').read_text())
 compressed=(ROOT/'evidence_data.json.gz').read_bytes()
 if digest(compressed)!=manifest['compressed_sha256']:raise ValueError('COMPRESSED_DATA_CHANGED')
 with gzip.GzipFile(fileobj=__import__('io').BytesIO(compressed),mode='rb') as f:raw=f.read(MAX_DECODED_BYTES+1)
 if len(raw)>MAX_DECODED_BYTES or len(raw)!=manifest['decoded_bytes'] or digest(raw)!=manifest['decoded_sha256']:
  raise ValueError('DECODED_DATA_CHANGED_OR_TOO_LARGE')
 data=json.loads(raw)
 if data['schema']!='compute075-content-deduplicated-json-v1':raise ValueError('UNKNOWN_DATA_SCHEMA')
 nodes=data['nodes'];cache={}
 for key,value in nodes.items():
  if digest(canonical(value))!=key:raise ValueError('NODE_HASH_CHANGED')
 def decode(obj,active=frozenset(),depth=0):
  if depth>16:raise ValueError('EXCESSIVE_NODE_DEPTH')
  if isinstance(obj,dict) and set(obj)=={'__compute075_list_ref__'}:
   key=obj['__compute075_list_ref__']
   if key in active:raise ValueError('CYCLIC_NODE')
   if key not in cache:cache[key]=[decode(x,active|{key},depth+1) for x in nodes[key]]
   return cache[key]
  if isinstance(obj,dict):return {k:decode(v,active,depth+1) for k,v in obj.items()}
  if isinstance(obj,list):raise ValueError('UNEXPECTED_INLINE_LIST')
  return obj
 expected={x['path']:x for x in manifest['files']}
 if len(expected)!=len(data['files']) or len(expected)!=44:raise ValueError('FILE_SET_CHANGED')
 staged=[];seen=set()
 for item in data['files']:
  relative=item['path'];path=Path(relative)
  if relative not in expected or relative in seen or path.is_absolute() or '..' in path.parts or path.as_posix()!=relative:raise ValueError('BAD_PATH')
  seen.add(relative)
  if path.suffix!='.json' or path.parts[0] not in ('native_source','experiment'):raise ValueError('UNEXPECTED_PUBLIC_FILE')
  spec=expected[relative]
  if {k:item[k] for k in ('path','sha256','bytes')}!=spec:raise ValueError('FILE_MANIFEST_CHANGED')
  out=canonical(decode(item['document']))
  if len(out)!=spec['bytes'] or digest(out)!=spec['sha256']:raise ValueError('ORIGINAL_BYTES_NOT_RECONSTRUCTED')
  target=ROOT/path
  if any(p.is_symlink() for p in (target,*target.parents)):raise ValueError('SYMLINK_REFUSED')
  if target.exists() and target.read_bytes()!=out:raise ValueError('REFUSE_TO_REPLACE_CHANGED_EVIDENCE')
  staged.append((target,out))
 for target,out in staged:
  target.parent.mkdir(parents=True,exist_ok=True)
  if not target.exists():target.write_bytes(out)
 print(json.dumps({'public_data_files_restored':len(staged),'original_bytes':sum(len(x[1]) for x in staged),'all_original_hashes_match':True}))

if __name__=='__main__':main()
