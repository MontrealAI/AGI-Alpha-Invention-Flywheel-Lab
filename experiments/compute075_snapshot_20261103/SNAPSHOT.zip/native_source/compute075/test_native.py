"""Authored local accounting regressions, never experimental commerce evidence."""
import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import uuid
from commercial.ledger import canonical, digest
from compute075 import service
from compute075.native import BusinessAccount, CATEGORIES, buyer_choice, supplier_choice, cost_contract, audit_export

ROOT = Path(__file__).resolve().parents[1]


class NativeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='compute075-FRESH-SIMULATED-')
        self.prefix = 'test-' + uuid.uuid4().hex
        self.inputs = ROOT / 'compute075' / 'test_inputs' / self.prefix
        self.outputs = ROOT / 'compute075' / 'deliveries' / self.prefix
        self.inputs.mkdir(parents=True)
        self.requests, self.solutions = [], []
        self.decision = buyer_choice(value=12_000_000, price=5_000_000, buyer_friction=0,
                                     direct_self_service=8_000_000, rival_complete=9_000_000, budget=20_000_000)
        for k in (1, 2):
            instance = {'schema': 'diffusion-instance-v1', 'instance_id': self.prefix+'-'+str(k), 'n': 1, 'q': 0,
                        'horizontal': [[1, 1]], 'vertical': [[1], [1]], 'rhs': [16*k],
                        'tolerance': {'numerator': 0, 'denominator': 1}}
            ip = self.inputs / f'{k}.json'; ip.write_bytes(canonical(instance))
            h = service.verifier.canonical_sha256(instance)
            self.requests.append({'id': f'job{k}', 'instance_path': str(ip.relative_to(ROOT)), 'instance_sha256': h,
                                  'delivery_path': f'compute075/deliveries/{self.prefix}/{k}.json',
                                  'market': {'buyer_id': f'buyer{k}', 'decision': self.decision},
                                  'resource': {'costs': self.costs(1_000_000 if k == 1 else 2_000_000),
                                               'supplier': supplier_choice(quote=500_000 if k == 1 else 1_000_000, complete_cost=400_000, outside_profit=1),
                                               'max_attempts': 2, 'expected_net': 3_000_000, 'allow_seed': k == 1}})
            self.solutions.append({'schema': 'diffusion-solution-v1', 'instance_id': instance['instance_id'], 'instance_sha256': h, 'z': [k]})
        self.manifest = service.prepare_manifest(ROOT, self.requests)
        self.path = Path(self.tmp.name) / 'fresh-simulated.sqlite'
        self.acc = BusinessAccount(ROOT, self.manifest, self.path, opening=20_000_000)

    def tearDown(self):
        self.acc.close()
        self.tmp.cleanup()
        shutil.rmtree(self.inputs)
        attempt_dir = ROOT / 'compute075' / 'attempts' / digest(self.manifest)
        if attempt_dir.exists(): shutil.rmtree(attempt_dir)
        if self.outputs.exists():
            shutil.rmtree(self.outputs)

    def costs(self, total=1_000_000):
        items = {x: 0 for x in CATEGORIES}
        items['research_construction'] = total // 4
        items['supplier_compute'] = total // 2
        items['verification'] = total // 8
        items['maintenance_support'] = total - sum(items.values())
        return cost_contract(items)

    def begin(self, k=1, day=1, deadline=2, maturity=3):
        entries = self.acc.export()['connected_journal']['entries']
        if not any(e['request'].get('id') == f'compute075-resource-job{k}' and e['status'] == 'COMPLETE' for e in entries):
            self.acc.prepay(f'job{k}', day)
        return self.acc.begin_order(f'job{k}', f'order{k}', f'buyer{k}', self.decision, day, deadline, maturity_day=maturity)

    def complete(self, k=1, day=2):
        self.assertTrue(self.acc.complete_order(f'order{k}', f'job{k}', self.solutions[k-1], day)['accepted'])
        self.acc.release(f'order{k}', day)

    def test_complete_cost_seed_and_earned_successor_actual_different_delivery(self):
        r = self.acc.prepay('job1', 0)
        self.assertEqual(r['funding'], 'SEED')
        self.begin(); self.complete()
        self.acc.advance(4)
        r = self.acc.prepay('job2', 4)
        self.assertEqual(r['funding'], 'EARNED')
        self.begin(2, 4, 5, 6); self.complete(2, 5); self.acc.advance(7)
        record = self.acc.export(); summary = record['ledger']['summary']
        self.assertEqual(summary['revenue'], 10_000_000)
        self.assertEqual(summary['expenses'], 3_000_000)
        self.assertEqual(summary['profit'], 7_000_000)
        self.assertEqual(summary['cash'], 27_000_000)
        self.assertEqual(summary['payables'], 0)
        self.assertTrue(audit_export(record, root=ROOT, manifest=self.manifest)['accepted'])
        # Projection only. This is authored regression behavior, not causal enablement or market profit.
        self.assertNotEqual(self.solutions[0]['instance_sha256'], self.solutions[1]['instance_sha256'])
        sensitive = {'_key', 'private_key', 'secret', 'nonce', 'cipher'}
        def walk(obj):
            if isinstance(obj, dict):
                self.assertFalse(set(obj) & sensitive)
                for value in obj.values(): walk(value)
            elif isinstance(obj, list):
                for value in obj: walk(value)
        walk(record)

    def test_declined_outside_option_has_no_payment(self):
        d = buyer_choice(value=12_000_000, price=5_000_000, buyer_friction=0, direct_self_service=100_000, rival_complete=9_000_000, budget=20_000_000)
        self.assertEqual(d['chosen'], 'direct_self_service')
        with self.assertRaises(ValueError):
            self.acc.begin_order('job1', 'order1', 'buyer1', d, 1, 2, maturity_day=3)
        self.assertEqual(self.acc.snapshot()['summary']['revenue'], 0)

    def test_native_replay_enforces_buyer_terms(self):
        self.acc.account.execute('wallet', {'buyer': 'buyer1', 'amount': 20_000_000}, 0)
        with self.assertRaisesRegex(ValueError, 'BUYER_CHOICE'):
            self.acc.account.execute('offer', {'id': 'bad', 'buyer': 'buyer1', 'price': 7_000_000, 'job_id': 'job1', 'deadline': 2}, 1)
        self.assertTrue(self.acc.audit()['accepted'])

    def test_invalid_supplier_and_late_refund_keep_incurred_cost(self):
        self.acc.prepay('job1', 0)
        self.begin()
        bad = copy.deepcopy(self.solutions[0]); bad['z'] = [100]
        self.assertFalse(self.acc.complete_order('order1', 'job1', bad, 2)['accepted'])
        with self.assertRaisesRegex(ValueError, 'LATE'):
            self.acc.complete_order('order1', 'job1', self.solutions[0], 3)
        self.acc.refund('order1', 3)
        s = self.acc.snapshot()['summary']
        self.assertEqual(s['revenue'], 0); self.assertEqual(s['expenses'], 1_000_000)
        self.assertEqual(s['payables'], 0)
        self.assertEqual(self.acc.audit()['metered_attempts'], 2)
        self.assertTrue(self.acc.audit()['accepted'])

    def test_idempotent_cost_prepare_release_and_changed_duplicate(self):
        a = self.acc.prepay('job1', 0)
        b = self.acc.prepay('job1', 0)
        self.assertEqual(a, b)
        with self.assertRaises(ValueError):
            self.acc.prepay('job1', 1)
        self.begin(); self.complete(); self.complete()
        self.assertEqual(self.acc.snapshot()['summary']['revenue'], 5_000_000)
        with self.assertRaises(ValueError): self.acc.release('order1', 3)
        self.assertTrue(self.acc.audit()['accepted'])

    def test_insufficient_cash_and_supplier_choice_prevent_spend(self):
        with self.assertRaisesRegex(ValueError, 'FUNDS'):
            self.acc.prepay('job2', 0)  # No earned cash yet, and no seed permission.
        self.assertFalse(supplier_choice(quote=1, complete_cost=2, outside_profit=1)['participates'])
        self.assertEqual(self.acc.snapshot()['summary']['expenses'], 0)

    def test_unprepaid_repeated_request_and_unmetered_delivery_refused(self):
        with self.assertRaisesRegex(ValueError, 'PREPAID'):
            self.acc.begin_order('job1', 'order1', 'buyer1', self.decision, 1, 2, maturity_day=3)
        self.acc.prepay('job1', 1)
        self.begin(); self.complete()
        with self.assertRaisesRegex(ValueError, 'ALREADY_SOLD'):
            self.acc.begin_order('job1', 'second-sale', 'buyer1', self.decision, 2, 3, maturity_day=4)
        self.assertEqual(self.acc.snapshot()['summary']['revenue'], 5_000_000)

    def test_failed_attempts_are_durable_and_capped(self):
        self.begin()
        for z in (100, 200):
            bad = copy.deepcopy(self.solutions[0]); bad['z'] = [z]
            self.assertFalse(self.acc.complete_order('order1', 'job1', bad, 2)['accepted'])
        with self.assertRaisesRegex(ValueError, 'ATTEMPT_LIMIT'):
            self.acc.complete_order('order1', 'job1', self.solutions[0], 2)
        self.acc.refund('order1', 3)
        verdict = self.acc.audit(); self.assertEqual(verdict['metered_attempts'], 2)
        self.assertEqual(verdict['summary']['profit'], -1_000_000)

    def test_claim_maturity_and_late_claim_stops_earned_investment(self):
        self.begin(); self.complete()
        self.acc.claim('order1', 'claim1', 300_000, 3)
        self.assertEqual(self.acc.snapshot()['summary']['payables'], 300_000)
        self.acc.resolve_claim('order1', 'claim1', 'settlement1', 'pay', 3)
        self.acc.advance(4)
        self.acc.claim('order1', 'lateclaim', 100_000, 4)
        self.assertTrue(self.acc.snapshot()['summary']['investmentStopped'])
        with self.assertRaisesRegex(ValueError, 'FUNDS'):
            self.acc.prepay('job2', 4)
        self.assertTrue(self.acc.audit()['accepted'])

    def test_reopen_preserves_account_and_reseed_refused(self):
        self.begin(); self.complete()
        old = self.acc.snapshot()['summary']; self.acc.close()
        with self.assertRaisesRegex(ValueError, 'NO_RESEED'):
            BusinessAccount(ROOT, self.manifest, self.path, opening=20_000_000)
        self.acc = BusinessAccount(ROOT, self.manifest, self.path, opening=20_000_000, fresh=False)
        self.assertEqual(old, self.acc.snapshot()['summary']); self.assertTrue(self.acc.audit()['accepted'])

    def test_large_solution_uses_compact_native_envelope(self):
        self.acc.close()
        n = 256
        instance = {'schema': 'diffusion-instance-v1', 'instance_id': self.prefix+'-large', 'n': n, 'q': 60,
                    'horizontal': [[1]*(n+1) for _ in range(n)], 'vertical': [[1]*n for _ in range(n+1)],
                    'rhs': [(n+1)**2*((i==0)+(i==n-1)+(j==0)+(j==n-1)) for i in range(n) for j in range(n)],
                    'tolerance': {'numerator': 0, 'denominator': 1}}
        ip = self.inputs / 'large.json'; ip.write_bytes(canonical(instance))
        request = copy.deepcopy(self.requests[0]); request['instance_path'] = str(ip.relative_to(ROOT))
        request['instance_sha256'] = service.verifier.canonical_sha256(instance)
        self.manifest = service.prepare_manifest(ROOT, [request])
        self.acc = BusinessAccount(ROOT, self.manifest, Path(self.tmp.name)/'large-FRESH.sqlite', opening=20_000_000)
        artifact = {'schema': 'diffusion-solution-v1', 'instance_id': instance['instance_id'],
                    'instance_sha256': request['instance_sha256'], 'z': [1<<60]*(n*n)}
        self.assertGreater(len(canonical(artifact)), 1_000_000)
        self.begin()
        result = self.acc.complete_order('order1', 'job1', artifact, 2)
        self.assertTrue(result['accepted'])
        self.assertEqual(result['solution_sha256'], digest(artifact))
        self.assertLess(len(canonical(service.delivery(ROOT, self.manifest, 'job1'))), 1000)
        self.acc.release('order1', 2)
        self.assertTrue(self.acc.audit()['accepted'])

    def test_reopen_missing_path_never_creates_fresh_capital(self):
        missing = Path(self.tmp.name) / 'missing-lineage.sqlite'
        with self.assertRaisesRegex(ValueError, 'REOPEN_REQUIRES_EXISTING'):
            BusinessAccount(ROOT, self.manifest, missing, opening=20_000_000, fresh=False)
        self.assertFalse(list(missing.parent.glob(missing.name + '*')))

    def test_supplier_refusal_retains_native_prospect_cost_without_trade(self):
        self.acc.close()
        requests = copy.deepcopy(self.requests)
        requests[0]['resource']['supplier'] = supplier_choice(quote=500_000, complete_cost=600_000, outside_profit=1)
        self.manifest = service.prepare_manifest(ROOT, requests)
        self.acc = BusinessAccount(ROOT, self.manifest, Path(self.tmp.name)/'refusal-FRESH.sqlite', opening=20_000_000)
        self.assertGreaterEqual(self.acc.snapshot()['summary']['available'], 20_000)
        self.acc.account.cost('prospect-refusal', 20_000, 0)
        with self.assertRaisesRegex(ValueError, 'SUPPLIER_DECLINED'):
            self.acc.prepay('job1', 0)
        with self.assertRaisesRegex(ValueError, 'SUPPLIER_DECLINED'):
            self.acc.begin_order('job1', 'order1', 'buyer1', self.decision, 1, 2, maturity_day=3)
        verdict = self.acc.audit()
        self.assertTrue(verdict['accepted'])
        self.assertEqual(verdict['summary']['profit'], -20_000)
        self.assertEqual(verdict['summary']['revenue'], 0)
        self.assertFalse(self.acc.export()['ledger']['orders'])

    def test_native_wallet_cannot_exceed_frozen_buyer_budget(self):
        with self.assertRaisesRegex(ValueError, 'BUYER_BUDGET'):
            self.acc.account.execute('wallet', {'buyer': 'buyer1', 'amount': 100_000_000}, 0)
        self.assertTrue(self.acc.audit()['accepted'])

    def test_output_tamper_rejected_by_public_audit(self):
        self.begin(); self.complete(); record = self.acc.export()
        p = service.safe_path(ROOT, self.requests[0]['delivery_path'])
        raw = p.read_bytes(); bad = copy.deepcopy(self.solutions[0]); bad['z'] = [2]; p.write_bytes(canonical(bad))
        try:
            with self.assertRaises(ValueError): audit_export(record, root=ROOT, manifest=self.manifest)
        finally: p.write_bytes(raw)


if __name__ == '__main__': unittest.main()
