"""Thin native account facade for authored certified-diffusion scenarios.

No additional balances. Every reported amount is a native account projection.
Prices and cost envelopes are scenario inputs, not observed demand or billing.
"""
from __future__ import annotations
import copy
from pathlib import Path
import threading
from commercial.ledger import amount, digest
from commercial.terms_exact_v2 import prospective_terms
from connected_enterprise.finance import JournalAccount, audit_journal
from . import service

CATEGORIES = ('research_construction', 'acquisition_onboarding', 'supplier_compute',
              'model_inference', 'verification', 'failed_attempts', 'delivery_payment',
              'maintenance_support', 'financing_tax')
PROVENANCE = 'AUTHORED_SCENARIO_NOT_MEASURED_MARKET_OR_BILLING'


def cost_contract(items, *, actual_billing=None):
    if not isinstance(items, dict) or set(items) != set(CATEGORIES):
        raise ValueError('COMPUTE075_COMPLETE_COST_CATEGORIES_REQUIRED')
    for value in items.values():
        amount(value)
    if actual_billing is not None:
        raise ValueError('COMPUTE075_ACTUAL_BILLING_NOT_OBSERVED')
    return {'items_microUSD': copy.deepcopy(items), 'total_microUSD': sum(items.values()),
            'provenance': PROVENANCE, 'actual_model_host_billing_microUSD': None,
            'resource_terms': 'All listed amounts are prepaid modeled resource prices including support; no unlisted invoice waived.'}


def buyer_choice(*, value, price, buyer_friction, direct_self_service, rival_complete, budget):
    for x in (value, price, buyer_friction, direct_self_service, rival_complete, budget):
        amount(x)
    candidate = price + buyer_friction
    # Ties favor a complete outside option; no purchase remains available.
    if price <= budget and candidate < min(value, direct_self_service, rival_complete):
        chosen = 'certified_supplier'
    elif min(direct_self_service, rival_complete) < value and min(direct_self_service, rival_complete) <= budget:
        chosen = 'direct_self_service' if direct_self_service <= rival_complete else 'rival_complete'
    else:
        chosen = 'no_purchase'
    return {'chosen': chosen, 'value': value, 'price': price, 'buyer_friction': buyer_friction,
            'direct_self_service': direct_self_service, 'rival_complete': rival_complete,
            'budget': budget, 'provenance': PROVENANCE}


def supplier_choice(*, quote, complete_cost, outside_profit):
    for x in (quote, complete_cost, outside_profit):
        amount(x)
    return {'participates': quote >= complete_cost + outside_profit,
            'quote': quote, 'complete_cost': complete_cost, 'outside_profit': outside_profit,
            'provenance': PROVENANCE}


class BusinessAccount:
    def __init__(self, root, manifest, path, *, opening, working=0, contract='compute075-authored-fresh', fresh=True):
        amount(opening); amount(working)
        self.root, self.manifest = Path(root).absolute(), copy.deepcopy(manifest)
        self._lock = threading.RLock()
        path = Path(path).absolute()
        if type(fresh) is not bool:
            raise ValueError('COMPUTE075_EXPLICIT_FRESH_OR_REOPEN_REQUIRED')
        if fresh and any(path.parent.glob(path.name + '*')):
            raise ValueError('COMPUTE075_FRESH_ACCOUNT_PATH_REQUIRED_NO_RESEED')
        if not fresh:
            # The action tape is recovery authority; SQLite checkpoint may be
            # absent after interruption. Never create history or signing state
            # under a request to reopen an existing lineage.
            required = ('.actions.jsonl', '.adaptive-simulation-key', '.connected-journal.json')
            if any(not path.with_name(path.name + suffix).is_file() or path.with_name(path.name + suffix).is_symlink() for suffix in required):
                raise ValueError('COMPUTE075_REOPEN_REQUIRES_EXISTING_DURABLE_HISTORY_AND_AUTHORITY')
        service.load_contracts(root, manifest)
        self.account = JournalAccount(root, manifest, path, opening=opening, working=working, contract=contract)

    def prepay(self, job_id, day):
        """Pay frozen complete package before any attempt or funded order."""
        job = service._bound(self.root, self.manifest, job_id)
        request = resource_request(job, day)
        with self._lock:
            receipt = self.account.spend(request['id'], request['kind'], request['amount'], day,
                                         request['work'], request['expected_net'], allow_seed=request['allow_seed'])
            if receipt is None:
                raise ValueError('COMPUTE075_NATIVE_AVAILABLE_FUNDS_REQUIRED')
            return receipt

    def begin_order(self, job_id, order_id, buyer_id, decision, day, deadline, *, maturity_day, residual=0):
        job = service._bound(self.root, self.manifest, job_id)
        if job['request']['market'] != {'buyer_id': buyer_id, 'decision': decision}:
            raise ValueError('COMPUTE075_PRECOMMITTED_BUYER_CHANGED')
        expected = buyer_choice(**{k: decision[k] for k in ('value', 'price', 'buyer_friction', 'direct_self_service', 'rival_complete', 'budget')})
        if decision != expected or decision['chosen'] != 'certified_supplier':
            raise ValueError('COMPUTE075_BUYER_PREFERS_OUTSIDE_OPTION')
        if type(day) is not int or type(deadline) is not int or day < 0 or deadline < day:
            raise ValueError('COMPUTE075_EXPLICIT_DEADLINE_REQUIRED')
        price = decision['price']
        terms = prospective_terms(order_id, price, maturity_day, deadline, residual=residual,
                                  counterparty_obligations='Authored buyer choice; exact discrete diffusion certificate only; no physical claim; supplier resources prepaid separately')
        with self._lock:
            actions = self.account.export()['ledger']['actions']
            # Validate paid resources and unique request before any order mutation.
            existing_offer = [a for a in actions if a['op'] == 'offer' and a['args']['id'] == order_id]
            if not existing_offer:
                service.validate_offer(self.root, self.manifest, {'job_id': job_id, 'buyer': buyer_id, 'price': price}, actions)
            prior = [a for a in actions if a['op'] == 'wallet' and a['args']['buyer'] == buyer_id]
            if not prior:
                self.account.execute('wallet', {'buyer': buyer_id, 'amount': decision['budget']}, day)
            elif len(prior) != 1 or prior[0]['args']['amount'] != decision['budget']:
                raise ValueError('COMPUTE075_BUYER_BUDGET_CHANGED')
            self.account.execute('register_terms', {'id': order_id + '-terms', 'terms': terms}, day)
            self.account.execute('offer', {'id': order_id, 'buyer': buyer_id, 'price': price,
                                         'job_id': job_id, 'deadline': deadline, 'terms_id': order_id + '-terms'}, day)
            for event in ('consent', 'fund'):
                self.account.execute('event', {'id': order_id, 'action': event, 'event_id': order_id + '-' + event}, day)
            return self.snapshot()

    def complete_order(self, order_id, job_id, artifact, day):
        with self._lock:
            ledger = self.account.export()['ledger']
            offers = [a for a in ledger['actions'] if a['op'] == 'offer' and a['args']['id'] == order_id]
            rows = [r for r in ledger['orders'] if r['id'] == order_id]
            if len(offers) != 1 or offers[0]['args']['job_id'] != job_id or len(rows) != 1 or rows[0]['state'] not in {'funded', 'verified', 'released'}:
                raise ValueError('COMPUTE075_MATCHING_FUNDED_ORDER_REQUIRED')
            marker = service.register_attempt(self.root, self.manifest, job_id, order_id, artifact)
            self.account.cost(marker, 0, day)
            if day > offers[0]['args']['deadline']:
                raise ValueError('COMPUTE075_LATE_DELIVERY_REFUND_REQUIRED')
            result = service.write_delivery(self.root, self.manifest, job_id, artifact)
            if result['accepted']:
                self.account.execute('event', {'id': order_id, 'action': 'prepare', 'event_id': order_id + '-prepare',
                                              'artifact_sha256': result['artifact_sha256']}, day)
            return result

    def release(self, order_id, day):
        return self.account.execute('event', {'id': order_id, 'action': 'release', 'event_id': order_id + '-release'}, day)

    def refund(self, order_id, day):
        return self.account.execute('event', {'id': order_id, 'action': 'refund', 'event_id': order_id + '-refund'}, day)

    def claim(self, order_id, claim_id, value, day, *, kind='ordinary'):
        return self.account.execute('claim', {'id': order_id, 'claim_id': claim_id, 'amount': value, 'kind': kind}, day)

    def resolve_claim(self, order_id, claim_id, settlement_id, resolution, day):
        return self.account.execute('resolve_claim', {'id': order_id, 'claim_id': claim_id, 'settlement_id': settlement_id, 'resolution': resolution}, day)

    def advance(self, day):
        return self.account.advance_financial(day)

    def snapshot(self):
        return self.account.snapshot()

    def export(self):
        return self.account.export()

    def audit(self):
        return audit_export(self.export(), root=self.root, manifest=self.manifest)

    def close(self):
        self.account.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()



def validate_resource(resource):
    if not isinstance(resource, dict) or set(resource) != {'costs', 'supplier', 'expected_net', 'allow_seed', 'max_attempts'}:
        raise ValueError('COMPUTE075_EXACT_RESOURCE_CONTRACT_REQUIRED')
    costs = resource['costs']
    if not isinstance(costs, dict) or costs != cost_contract(costs.get('items_microUSD')) or costs['total_microUSD'] <= 0:
        raise ValueError('COMPUTE075_COMPLETE_PREPAID_RESOURCE_PRICE_REQUIRED')
    if type(resource['expected_net']) is not int or type(resource['allow_seed']) is not bool or type(resource['max_attempts']) is not int or resource['max_attempts'] < 1:
        raise ValueError('COMPUTE075_EXPLICIT_RESOURCE_TERMS_REQUIRED')
    supplier = resource['supplier']
    if not isinstance(supplier, dict) or supplier != supplier_choice(**{k: supplier[k] for k in ('quote', 'complete_cost', 'outside_profit')}):
        raise ValueError('COMPUTE075_EXPLICIT_SUPPLIER_CHOICE_REQUIRED')
    if costs['items_microUSD']['supplier_compute'] != supplier['quote']:
        raise ValueError('COMPUTE075_SUPPLIER_PRICE_CHANGED')
    return resource


def resource_request(job, day):
    q = job['request']; r = validate_resource(q['resource'])
    if not r['supplier']['participates']:
        raise ValueError('COMPUTE075_SUPPLIER_DECLINED')
    return {'operation': 'spend', 'id': 'compute075-resource-' + job['id'],
            'kind': 'certified_diffusion_resources', 'amount': r['costs']['total_microUSD'], 'day': day,
            'work': {'scope': 'AUTHORED_SIMULATION', 'job_id': job['id'], 'request_sha256': digest(q),
                     'resource_contract': copy.deepcopy(r)},
            'expected_net': r['expected_net'], 'allow_seed': r['allow_seed']}


def audit_export(record, *, root, manifest):
    native = audit_journal(record, root=root, manifest=manifest)
    jobs = service.load_contracts(root, manifest)
    paid = {}
    for entry in record['connected_journal']['entries']:
        request = entry['request']
        if request['operation'] != 'spend' or entry['status'] != 'COMPLETE':
            continue
        work = request['work']
        job_id = work.get('job_id') if isinstance(work, dict) else None
        if job_id not in jobs or request != resource_request(jobs[job_id]['job'], request['day']) or job_id in paid:
            raise ValueError('COMPUTE075_NATIVE_RESOURCE_CONTRACT_MISMATCH')
        paid[job_id] = entry['receipt']
    for a in record['ledger']['actions']:
        if a['op'] == 'offer':
            job_id = a['args']['job_id']
            if job_id not in paid or paid[job_id]['native_event_sequence'] >= a['seq']:
                raise ValueError('COMPUTE075_RESOURCES_MUST_PRECEDE_ORDER')
    native['resource_packages_checked'] = len(paid)
    native['complete_cost_scope'] = 'Frozen authored prepaid packages with durable attempt limits; actual external billing unknown.'
    native['metered_attempts'] = sum(a['op'] == 'cost' and a['args']['id'].startswith('compute075-attempt-') for a in record['ledger']['actions'])
    return native


def public_dependencies(record, *, root, manifest):
    """Exact allowlist for key-free independent replay, including rejected attempts."""
    audit_export(record, root=root, manifest=manifest)
    files = set(manifest['source_hashes'])
    jobs = service.load_contracts(root, manifest)
    for job in jobs.values():
        files.add(job['job']['request']['instance_path'])
    # Rejected prepare replay may read an output even without committed prepare.
    for job in jobs.values():
        relative = job['job']['delivery_path']
        if service.safe_path(root, relative).is_file(): files.add(relative)
    for entry in record['connected_journal']['entries']:
        r = entry['request']
        if r['operation'] == 'execute' and r['op'] == 'cost' and r['args']['id'].startswith('compute075-attempt-'):
            try:
                path = service.attempt_path(root, manifest, r['args']['id'])
            except ValueError:
                continue  # Malformed ID was rejected before reading an artifact.
            if path.is_file(): files.add(str(path.relative_to(Path(root).absolute())))
    return sorted(files)


def write_public_export(record, *, root, manifest, destination):
    """Create fresh source/JSON-only replay package; never copy account sidecars."""
    import json
    from commercial.ledger import canonical
    paths = public_dependencies(record, root=root, manifest=manifest)
    target = Path(destination).absolute()
    if target.exists(): raise ValueError('COMPUTE075_NEW_EXPORT_DIRECTORY_REQUIRED')
    target.mkdir(parents=True)
    for relative in paths:
        source = service.safe_path(root, relative)
        dest = service.safe_path(target, relative); dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(source.read_bytes())
    (target/'MANIFEST.json').write_bytes(canonical(manifest))
    (target/'ACCOUNT_EXPORT.json').write_bytes(canonical(record))
    replay = audit_export(record, root=target, manifest=manifest)
    return {'scope': 'SIMULATED_KEY_FREE_AUDIT_ONLY', 'files': len(paths) + 2,
            'exported_replay_accepted': replay['accepted'],
            'account_export_sha256': digest(record), 'manifest_sha256': digest(manifest)}


def main():
    import argparse
    import json
    from commercial.ledger import strict_json
    parser = argparse.ArgumentParser(description='Independently audit a key-free compute075 simulation export.')
    parser.add_argument('command', choices=['audit'])
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--record', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(audit_export(strict_json(args.record.read_bytes()), root=args.source,
                                 manifest=strict_json(args.manifest.read_bytes())), sort_keys=True))


if __name__ == '__main__': main()
