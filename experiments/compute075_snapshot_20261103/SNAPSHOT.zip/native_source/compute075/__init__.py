"""Authored finite certified-diffusion experiment; no real commerce."""
