# Certified diffusion native accounting adapter

This is a development adapter on public Lab main `54f33ce6d3b19d37050717c2c1a4e1e4380caa6b`, not a new ledger. Money, custody, earned-cash reservation, refunds, claims and maturity use `JournalAccount` → mandatory adaptive `Account` → pinned exact prospective native exchange. All amounts are simulated integer microUSD. No existing private account is migrated or read. `fresh=False` strictly reopens a supplied existing lineage: its action tape, simulation authority and connected journal must exist; a missing path never creates new seed capital.

## What is certified

The independent verifier certifies only the fixed discrete diffusion problem's exact-integer residual/error bound. Input identity comes from the buyer-owned request. Physical value, demand, supplier reliability and actual billing are not certified. Native preparation carries a small envelope committing the complete actual solution, request and verifier source; native checking and public replay reread and independently verify the full solution. The native artifact size guard remains unchanged.

## Freeze before producing

Import from the final staged source root without modifying its source afterward. Copy a freshly generated buyer input into that root, then build a manifest before producing any paid output:

```python
from compute075 import service
from compute075.native import BusinessAccount, buyer_choice, supplier_choice, cost_contract

choice = buyer_choice(value=10_000_000, price=2_000_000,
    buyer_friction=100_000, direct_self_service=5_000_000,
    rival_complete=3_000_000, budget=10_000_000)
# These values are authored scenario inputs. Price selection must not secretly
# inspect a buyer's private value/outside costs. No purchase remains an option.
items = dict(research_construction=1_000_000, acquisition_onboarding=0,
    supplier_compute=40_000, model_inference=20_000, verification=30_000,
    failed_attempts=10_000, delivery_payment=20_000,
    maintenance_support=40_000, financing_tax=20_000)
request = dict(id='fresh-request-1', instance_path='compute075/inputs/one.json',
    instance_sha256=BUYER_PINNED_CANONICAL_HASH,
    delivery_path='compute075/deliveries/one.json',
    market=dict(buyer_id='authored-buyer-1', decision=choice),
    resource=dict(costs=cost_contract(items),
        supplier=supplier_choice(quote=40_000, complete_cost=30_000, outside_profit=10_000),
        expected_net=800_000, allow_seed=True, max_attempts=2))
manifest = service.prepare_manifest(ROOT, [request])
with BusinessAccount(ROOT, manifest, NEW_PRIVATE_ACCOUNT_PATH,
                     opening=20_000_000) as business:
    # Only when this arm's prospect/participation and liquidity conditions pass:
    spend_receipt = business.prepay('fresh-request-1', 0)
    business.begin_order('fresh-request-1', 'order-1', 'authored-buyer-1',
        choice, 1, 2, maturity_day=3)
    # Run actual producer now, not before prepayment. Time the complete outer
    # solve, diagnostics, serialization, checking, native work and retries.
    result = business.complete_order('order-1', 'fresh-request-1', ACTUAL_OUTPUT, 2)
    if result['accepted']:
        business.release('order-1', 2)
    else:
        business.refund('order-1', 2)
    business.advance(4)
    verdict = business.audit()
    export = business.export()
```

The example prices/costs are explanatory scenario numbers, not measured market prices or evidence of profitability. Actual host/model billing remains null. All nine cost categories must be explicit. Include complete construction/search and failed work; unused optimistic assumptions are not facts. Each resource contract is a prepaid package with a finite attempt allowance and prepaid support. The supply quote must match its package expense. Declined suppliers may appear as input evidence but cannot receive a resource prepayment or order.

`expected_net` is a planning value, never cash. A second request with `allow_seed=False` can spend only when the canonical account supplies an `EARNED` reservation receipt. Seed capital, cash, revenue, expenses, profit and unrestricted earned cash are separate native fields. Another instance of the same service is not a different opportunity class or a causal enabling result.

The runner owns prospective search costs: use an explicitly registered native expense and admit the search only after auditing and confirming native available cash, then debit before reading the response. `business.account.cost(...)` records genuine incurred costs even if liquidity prevents payment; it is not an admission guard. Do not use it to assume funding or hide liabilities. A declined buyer/supplier may leave native expenses and negative profit without any resource package or order. Independent scenario audit must reconcile these costs as well as package costs.

## Failure and duplicate handling

- Full request, source closure, exact buyer wallet budget and voluntary choice are validated in native replay.
- A funded order needs its exact prepaid complete package. One job can be consumed by only one order.
- Every submitted supplier artifact is first committed by a zero-money native attempt marker. Failed and late attempts retain evidence; duplicate identical calls do not create new revenue. The package's attempt allowance is enforced independently.
- Invalid solutions never prepare. Late solutions never prepare or release, but are metered before the late-delivery exception; refund the existing order. Do not silently replace a failed output or change acceptance.
- Claims, refunds, inclusive maturity and late residual exposure use the unchanged native engine. Late claims can stop investments even if seed liquidity exists.
- Native account ownership is single-writer/local POSIX. Cross-thread SQLite access is unsupported. Sequential oversubscription and competing writers must fail safely; no hostile-host security claim is made.

## Independent audit and key-free export

Use `BusinessAccount.audit` or `compute075.native.audit_export`, not a generic ledger check as a complete domain verdict. The custom audit replays native behavior and reconciles frozen resource packages and durable attempts. Extra ordinary native costs remain in full expenses, not excluded because they are not resource spends.

`write_public_export(record, root=ROOT, manifest=manifest, destination=NEW_PATH)` writes only an explicit source/input/output/attempt allowlist plus manifest and exported native record. It includes rejected-action dependencies and independently replays the copied destination before returning success. It never copies account databases, account signing files, private checkpoints or recovery authority. Exported HMAC signatures are public proof fields, not signing secrets.

From the exported directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m compute075.native audit \
  --source "$PWD" --manifest MANIFEST.json --record ACCOUNT_EXPORT.json
```

## Verification and limits

Run `PYTHONDONTWRITEBYTECODE=1 python -m unittest compute075.test_native -v`. The authored tests include >1MB n=256 exact output, prepaid costs, seed/earned separation, outside options, raw native wallet checks, repeated jobs, failed/late attempts, refunds, claims, resume, tamper rejection, and supplier refusal with prospect cost.

Positive test-fixture balances are software regression expectations, not a business result. Full repository CI, integrated qualification against other concurrent domains, public release and operation from release are separate and have not been performed by this adapter task. Original counterexamples are retained by the independent reviewer; engineering lessons are not evidence of autonomous weight learning.
