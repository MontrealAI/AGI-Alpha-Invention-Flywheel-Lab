"""Late-bound exact diffusion delivery on the canonical account, not a ledger.

Request and checker are frozen before production. Supplier statements are never
acceptance authority. Mathematical certification says nothing about physical use.
"""
from __future__ import annotations
import copy
import hashlib
from pathlib import Path
import tempfile
from commercial.ledger import canonical, digest, strict_json
from commercial.persistence import atomic_bytes
from . import verifier

SCHEMA = 'compute075/native-services/v1'
BOUND = 8_000_000


def source_paths(root):
    return ('compute075/__init__.py', 'compute075/service.py', 'compute075/native.py',
            'compute075/verifier.py', 'commercial/ledger.py', 'connected_enterprise/finance.py',
            'commercial/__init__.py', 'adaptive_enterprise/__init__.py', 'connected_enterprise/__init__.py',
            'vendor/__init__.py', 'vendor/alpha_claim/__init__.py')


def safe_path(root, relative):
    if not isinstance(relative, str) or not relative:
        raise ValueError('COMPUTE075_RELATIVE_PATH_REQUIRED')
    p = Path(relative)
    if p.is_absolute() or '..' in p.parts or p.as_posix() != relative:
        raise ValueError('COMPUTE075_RELATIVE_PATH_REQUIRED')
    full = Path(root).absolute() / p
    if any(p.is_symlink() for p in (full, *full.parents)):
        raise ValueError('COMPUTE075_SYMLINK_REFUSED')
    return full


def read(root, relative):
    p = safe_path(root, relative)
    with p.open('rb') as f:
        raw = f.read(BOUND + 1)
    if len(raw) > BOUND:
        raise ValueError('COMPUTE075_BOUNDED_ARTIFACT_REQUIRED')
    return strict_json(raw)


def source_hashes(root):
    from connected_enterprise.finance import SOURCE_PATHS
    paths = tuple(dict.fromkeys(tuple(SOURCE_PATHS) + source_paths(root)))
    return {p: hashlib.sha256(safe_path(root, p).read_bytes()).hexdigest() for p in paths}


def _validate(root, manifest):
    if (not isinstance(manifest, dict) or set(manifest) != {'schema', 'native_engine', 'account_namespace', 'source_hashes', 'jobs'}
            or manifest['schema'] != SCHEMA or manifest['native_engine'] != 'exact-prospective-v2'
            or manifest['account_namespace'] != 'adaptive012' or not isinstance(manifest['jobs'], list) or not manifest['jobs']):
        raise ValueError('COMPUTE075_EXACT_MANIFEST_REQUIRED')
    expected = source_hashes(root)
    if expected != manifest['source_hashes'] or source_hashes(Path(__file__).resolve().parents[1]) != expected:
        raise ValueError('COMPUTE075_SOURCE_CLOSURE_CHANGED')


def _request(root, row):
    if (not isinstance(row, dict) or set(row) != {'id', 'request', 'delivery_path'}
            or not isinstance(row['id'], str) or not row['id'] or len(row['id']) > 140):
        raise ValueError('COMPUTE075_EXACT_REQUEST_REQUIRED')
    q = row['request']
    if (not isinstance(q, dict) or set(q) != {'id', 'instance_path', 'instance_sha256', 'acceptance_scope', 'market', 'resource'}
            or q['id'] != row['id'] or q['acceptance_scope'] != 'fixed_discrete_model_l2_error_only'):
        raise ValueError('COMPUTE075_EXACT_REQUEST_REQUIRED')
    from .native import buyer_choice, validate_resource
    validate_resource(q['resource'])
    market = q['market']
    if not isinstance(market, dict) or set(market) != {'buyer_id', 'decision'} or not isinstance(market['buyer_id'], str) or not market['buyer_id'] or len(market['buyer_id']) > 140:
        raise ValueError('COMPUTE075_BUYER_MARKET_REQUIRED')
    d = market['decision']
    if not isinstance(d, dict) or d != buyer_choice(**{k: d[k] for k in ('value', 'price', 'buyer_friction', 'direct_self_service', 'rival_complete', 'budget')}):
        raise ValueError('COMPUTE075_BUYER_CHOICE_CHANGED')
    instance = read(root, q['instance_path'])
    verifier.validate_instance(instance)
    if verifier.canonical_sha256(instance) != q['instance_sha256']:
        raise ValueError('COMPUTE075_BUYER_INSTANCE_CHANGED')
    safe_path(root, row['delivery_path'])
    if not row['delivery_path'].startswith('compute075/deliveries/') or row['delivery_path'] == q['instance_path']:
        raise ValueError('COMPUTE075_DELIVERY_NAMESPACE_REQUIRED')
    return q


def load_contracts(root, manifest):
    _validate(root, manifest)
    result, outputs, ids, buyer_budgets = {}, set(), set(), {}
    checker = manifest['source_hashes']['compute075/verifier.py']
    for row in manifest['jobs']:
        q = _request(root, row)
        buyer, budget = q['market']['buyer_id'], q['market']['decision']['budget']
        if buyer in buyer_budgets and buyer_budgets[buyer] != budget:
            raise ValueError('COMPUTE075_BUYER_BUDGET_CONFLICT')
        buyer_budgets[buyer] = budget
        instance_id = read(root, q['instance_path'])['instance_id']
        if row['id'] in result or row['delivery_path'] in outputs or instance_id in ids:
            raise ValueError('COMPUTE075_UNIQUE_REQUEST_AND_OUTPUT_REQUIRED')
        outputs.add(row['delivery_path']); ids.add(instance_id)
        result[row['id']] = {'job': {'id': row['id'], 'artifact_sha256': digest(q),
                                    'receipt_sha256': checker, 'request': copy.deepcopy(q),
                                    'delivery_path': row['delivery_path']},
                            'artifact': {'precommitted_request': digest(q)},
                            'receipt': {'checker_sha256': checker}}
    return result


def prepare_manifest(root, requests):
    # Caller supplies a buyer-owned hash, never one learned from the supplier.
    rows = []
    for r in requests:
        if set(r) != {'id', 'instance_path', 'instance_sha256', 'delivery_path', 'market', 'resource'}:
            raise ValueError('COMPUTE075_BUYER_PIN_REQUIRED')
        q = {k: r[k] for k in ('id', 'instance_path', 'instance_sha256', 'market', 'resource')}
        q['acceptance_scope'] = 'fixed_discrete_model_l2_error_only'
        rows.append({'id': r['id'], 'request': q, 'delivery_path': r['delivery_path']})
    manifest = {'schema': SCHEMA, 'native_engine': 'exact-prospective-v2', 'account_namespace': 'adaptive012',
                'source_hashes': source_hashes(root), 'jobs': rows}
    load_contracts(root, manifest)
    return manifest


def _bound(root, manifest, job_id):
    jobs = load_contracts(root, manifest)
    if job_id not in jobs:
        raise ValueError('COMPUTE075_UNKNOWN_REQUEST')
    return jobs[job_id]['job']


def verify_delivery(root, manifest, job_id, artifact):
    job = _bound(root, manifest, job_id)
    q = job['request']
    raw = canonical(artifact)
    if len(raw) > BOUND:
        raise ValueError('COMPUTE075_BOUNDED_ARTIFACT_REQUIRED')
    with tempfile.TemporaryDirectory(prefix='compute075-untrusted-verification-') as tmp:
        path = Path(tmp) / 'solution.json'
        path.write_bytes(raw)
        result = verifier.verify(safe_path(root, q['instance_path']), path,
                                 expected_instance_sha256=q['instance_sha256'])
    result.update(request_sha256=digest(q), artifact_sha256=digest(artifact))
    return result


def solution(root, manifest, job_id):
    return read(root, _bound(root, manifest, job_id)['delivery_path'])


def delivery(root, manifest, job_id):
    job = _bound(root, manifest, job_id)
    artifact = solution(root, manifest, job_id)
    return {'schema': 'compute075/native-certified-envelope/v1', 'job_id': job_id,
            'request_sha256': digest(job['request']), 'solution_sha256': digest(artifact),
            'checker_sha256': manifest['source_hashes']['compute075/verifier.py']}


def check_delivery(root, manifest, job_id, envelope):
    if envelope != delivery(root, manifest, job_id):
        raise ValueError('COMPUTE075_NATIVE_ENVELOPE_CHANGED')
    result = verify_delivery(root, manifest, job_id, solution(root, manifest, job_id))
    return {'accepted': result['accepted'] is True, 'decisive': True, 'scope': 'SIMULATED',
            'authority': manifest['source_hashes']['compute075/verifier.py']}


def write_delivery(root, manifest, job_id, artifact):
    result = verify_delivery(root, manifest, job_id, artifact)
    if result['accepted'] is not True:
        return result
    job = _bound(root, manifest, job_id)
    path = safe_path(root, job['delivery_path']); raw = canonical(artifact)
    if path.exists() and path.read_bytes() != raw:
        raise ValueError('COMPUTE075_IMMUTABLE_DELIVERY_CHANGED')
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        atomic_bytes(path, raw)
    result['solution_sha256'] = digest(artifact)
    result['artifact_sha256'] = digest(delivery(root, manifest, job_id))
    result['native_artifact_scope'] = 'Compact envelope commits full solution; native checker independently revalidates full solution bytes.'
    return result


def rebind_prepared(root, manifest, actions, contracts=None):
    jobs = load_contracts(root, manifest) if contracts is None else contracts
    offers = {}
    for action in actions:
        args = action['args']
        if action['op'] == 'offer':
            if args['id'] in offers:
                raise ValueError('COMPUTE075_DUPLICATE_ORDER')
            offers[args['id']] = args['job_id']
        elif action['op'] == 'event' and args['action'] == 'prepare':
            job_id = offers.get(args['id'])
            if job_id not in jobs:
                raise ValueError('COMPUTE075_MISSING_ORDER')
            artifact = delivery(root, manifest, job_id)
            if digest(artifact) != args.get('artifact_sha256') or not check_delivery(root, manifest, job_id, artifact)['accepted']:
                raise ValueError('COMPUTE075_PREPARED_OUTPUT_CHANGED')


def validate_offer(root, manifest, args, actions):
    job = _bound(root, manifest, args['job_id'])
    market = job['request']['market']
    if (market['decision']['chosen'] != 'certified_supplier'
            or args['buyer'] != market['buyer_id'] or args['price'] != market['decision']['price']):
        raise ValueError('COMPUTE075_NATIVE_BUYER_CHOICE_VIOLATED')

    if any(a['op'] == 'offer' and a['args']['job_id'] == args['job_id'] for a in actions):
        raise ValueError('COMPUTE075_REQUEST_ALREADY_SOLD')
    require_paid(root, manifest, job, actions)


def require_paid(root, manifest, job, actions):
    from .native import resource_request
    from connected_enterprise.finance import source_identity, _seed_id
    from commercial.ledger import digest
    source = source_identity(root, manifest)['sha256']
    matches = []
    for a in actions:
        request = resource_request(job, a['day'])
        if a['op'] == 'cost' and a['args'] == {'id': _seed_id(request, source), 'amount': request['amount']}:
            matches.append(a)
        elif a['op'] == 'finish' and a['args']['id'] == 'connected014-resource-' + digest(request['id'])[:32] and a['args']['amount'] == request['amount']:
            matches.append(a)
    if len(matches) != 1:
        raise ValueError('COMPUTE075_PREPAID_COMPLETE_RESOURCES_REQUIRED')


def attempt_id(body):
    return 'compute075-attempt-' + digest(body)


def attempt_path(root, manifest, ident):
    if not isinstance(ident, str) or not ident.startswith('compute075-attempt-') or len(ident) != 83:
        raise ValueError('COMPUTE075_ATTEMPT_ID_REQUIRED')
    return safe_path(root, 'compute075/attempts/' + digest(manifest) + '/' + ident + '.json')


def register_attempt(root, manifest, job_id, order_id, artifact):
    _bound(root, manifest, job_id)
    body = {'job_id': job_id, 'order_id': order_id, 'artifact': artifact}
    raw = canonical(body)
    if len(raw) > BOUND:
        raise ValueError('COMPUTE075_BOUNDED_ATTEMPT_REQUIRED')
    ident = attempt_id(body); path = attempt_path(root, manifest, ident)
    if path.exists() and path.read_bytes() != raw:
        raise ValueError('COMPUTE075_IMMUTABLE_ATTEMPT_CHANGED')
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists(): atomic_bytes(path, raw)
    return ident


def read_attempt(root, manifest, ident):
    path = attempt_path(root, manifest, ident)
    with path.open('rb') as f: raw = f.read(BOUND + 1)
    if len(raw) > BOUND: raise ValueError('COMPUTE075_BOUNDED_ATTEMPT_REQUIRED')
    body = strict_json(raw)
    if not isinstance(body, dict) or set(body) != {'job_id', 'order_id', 'artifact'} or attempt_id(body) != ident:
        raise ValueError('COMPUTE075_ATTEMPT_CHANGED')
    return body


def validate_attempt(root, manifest, args, actions):
    body = read_attempt(root, manifest, args['id'])
    job = _bound(root, manifest, body['job_id'])
    require_paid(root, manifest, job, actions)
    if args['amount'] != 0:
        raise ValueError('COMPUTE075_ATTEMPT_MARKER_NOT_MONEY')
    offers = [a for a in actions if a['op'] == 'offer' and a['args']['id'] == body['order_id']]
    if len(offers) != 1 or offers[0]['args']['job_id'] != body['job_id']:
        raise ValueError('COMPUTE075_ATTEMPT_REQUIRES_ORDER')
    terminal = [a for a in actions if a['op'] == 'event' and a['args']['id'] == body['order_id'] and a['args']['action'] in {'release', 'refund', 'cancel', 'late_reversal'}]
    funded = [a for a in actions if a['op'] == 'event' and a['args']['id'] == body['order_id'] and a['args']['action'] == 'fund']
    if terminal or not funded:
        raise ValueError('COMPUTE075_ATTEMPT_REQUIRES_FUNDED_ACTIVE_ORDER')
    prior = [read_attempt(root, manifest, a['args']['id']) for a in actions
             if a['op'] == 'cost' and a['args']['id'].startswith('compute075-attempt-')]
    if sum(b['job_id'] == body['job_id'] for b in prior) >= job['request']['resource']['max_attempts']:
        raise ValueError('COMPUTE075_PREPAID_ATTEMPT_LIMIT_REACHED')
    return body


def validate_prepared(root, manifest, order_id, job_id, artifact, actions):
    if artifact != delivery(root, manifest, job_id):
        raise ValueError('COMPUTE075_NATIVE_ENVELOPE_CHANGED')
    artifact = solution(root, manifest, job_id)
    ident = attempt_id({'job_id': job_id, 'order_id': order_id, 'artifact': artifact})
    if not any(a['op'] == 'cost' and a['args'] == {'id': ident, 'amount': 0} for a in actions):
        raise ValueError('COMPUTE075_PREPARE_REQUIRES_METERED_ATTEMPT')
    body = read_attempt(root, manifest, ident)
    if digest(body['artifact']) != digest(artifact):
        raise ValueError('COMPUTE075_ATTEMPT_ARTIFACT_CHANGED')


def validate_wallet(root, manifest, args):
    jobs = load_contracts(root, manifest)
    budgets = {j['job']['request']['market']['buyer_id']: j['job']['request']['market']['decision']['budget'] for j in jobs.values()}
    if args['buyer'] not in budgets or args['amount'] != budgets[args['buyer']]:
        raise ValueError('COMPUTE075_NATIVE_BUYER_BUDGET_CHANGED')
