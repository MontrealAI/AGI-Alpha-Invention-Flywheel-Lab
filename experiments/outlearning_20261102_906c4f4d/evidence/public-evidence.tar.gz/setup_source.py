import argparse, hashlib, json, shutil, subprocess
from pathlib import Path, PurePosixPath

def checked_path(root, name):
    rel=PurePosixPath(name)
    if rel.is_absolute() or '..' in rel.parts or str(rel)!=name: raise ValueError('RELATIVE_PATH_REQUIRED')
    p=root.joinpath(*rel.parts)
    if any(q.is_symlink() for q in (p,*p.parents)): raise ValueError('SYMLINK_REFUSED')
    return p

def main():
    p=argparse.ArgumentParser(); p.add_argument('--checkout',required=True,type=Path); p.add_argument('--evidence-root',default=Path(__file__).resolve().parent,type=Path); a=p.parse_args()
    root=a.evidence_root.resolve(); checkout=a.checkout.resolve()
    manifest=json.loads((root/'BUNDLE_MANIFEST.json').read_text())
    if manifest.get('schema')!='outlearning-public-bundle/v1' or manifest.get('private_authority_included') is not False: raise ValueError('EXTRACTED_PUBLIC_BUNDLE_REQUIRED')
    for name,entry in manifest['files'].items():
        f=checked_path(root,name)
        if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=entry['sha256']: raise ValueError('PUBLIC_PAYLOAD_CHANGED:'+name)
    inv=json.loads((root/'SOURCE_INVENTORY.json').read_text())
    commit=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()
    if commit!=inv['source_commit']: raise ValueError('EXACT_FROZEN_COMMIT_REQUIRED')
    jobs=[]
    for name,entry in inv['files'].items():
        src=checked_path(checkout,name); dst=checked_path(root/'native/source',name)
        if not src.is_file() or hashlib.sha256(src.read_bytes()).hexdigest()!=entry['sha256']: raise ValueError('FROZEN_SOURCE_BYTES_CHANGED:'+name)
        if dst.exists() and (not dst.is_file() or hashlib.sha256(dst.read_bytes()).hexdigest()!=entry['sha256']): raise ValueError('EXISTING_SOURCE_WOULD_CHANGE:'+name)
        jobs.append((src,dst))
    for name in ('postfreeze_replay.py','package_public_evidence.py'):
        src=checked_path(root,'checks/'+name); dst=checked_path(root/'native/source',inv['campaign_folder']+'/'+name)
        if dst.exists() and dst.read_bytes()!=src.read_bytes(): raise ValueError('EXISTING_ADDITIVE_CHECKER_WOULD_CHANGE')
        jobs.append((src,dst))
    for src,dst in jobs:
        if not dst.exists():
            dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src,dst)
    print(json.dumps({'source_commit':commit,'source_files_verified':len(inv['files']),'copied_or_already_identical':len(jobs),'native_account_authority_required':False}))

if __name__=='__main__': main()
