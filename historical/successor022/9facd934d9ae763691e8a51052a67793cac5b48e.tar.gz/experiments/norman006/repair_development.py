import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.norman006 import model


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(data_path, original_path, constraint_path, adjudication_path, output, mapping_path=None):
    output.mkdir(parents=True, exist_ok=False)
    source_sha = sha(ROOT / 'experiments/norman006/model.py')
    original = json.loads(original_path.read_text())
    constraint = json.loads(constraint_path.read_text())
    adjudication = json.loads(adjudication_path.read_text())
    if constraint['evidence_sha256'] != sha(adjudication_path) or adjudication['status'] != 'established' or adjudication['candidate_source_sha256'] != source_sha or adjudication['artifact_file_sha256'] != sha(original_path) or adjudication['candidate_artifact_sha256'] != original['artifact_sha256'] or adjudication['data_sha256'] != sha(data_path):
        raise ValueError('ADJUDICATION_CANDIDATE_DATA_OR_SOURCE_BINDING')
    data = dict(np.load(data_path, allow_pickle=False))
    mapping_identity = None
    if mapping_path is not None:
        from experiments.norman006 import inheritance
        mapped = json.loads(mapping_path.read_text())
        derived = inheritance.constructive_constraint(adjudication_path, mapped)
        if derived != constraint:
            raise ValueError('MAPPING_CONSTRAINT_MISMATCH')
        constraint = derived
        mapping_identity = sha(mapping_path)
    construction = model.repair(original['configuration'], [constraint])
    with (output / 'CONSTRUCTION.json').open('x') as stream:
        json.dump(construction, stream, indent=2)
        stream.write('\n')
    fit_data = model.subset(data, data['fit_indices'])
    calibration = model.subset(data, data['calibration_indices'], False)
    truth = data['AB'][data['calibration_indices']]
    metrics = {}
    for name, configuration in [('original', original['configuration']), ('repaired', construction['configuration'])]:
        fit_artifact = model.fit(fit_data, configuration, source_sha)
        prediction = model.predict(fit_artifact, calibration)['prediction']
        error = np.sqrt(np.mean((prediction - truth) ** 2, axis=1))
        metrics[name] = {'median_pair_rmse': float(np.median(error)), 'pooled_rmse': float(np.sqrt(np.mean((prediction - truth) ** 2))), 'pair_rmse': error.tolist(), 'fit_artifact_sha256': fit_artifact['artifact_sha256']}
    repaired = model.fit(data, construction['configuration'], source_sha)
    with (output / 'ARTIFACT.json').open('x') as stream:
        json.dump(repaired, stream, indent=2)
        stream.write('\n')
    inputs = model.subset(data, range(len(data['pairs'])), False)
    first = model.predict(repaired, inputs)['prediction']
    swapped = dict(inputs)
    swapped['A'], swapped['B'] = inputs['B'], inputs['A']
    second = model.predict(repaired, swapped)['prediction']
    maximum_difference = float(np.max(np.abs(first - second)))
    report = {'schema': 'agi-alpha-cycle006-norman-constructive-repair/v1', 'status': 'development-repair-executed',
              'original_artifact_sha256': original['artifact_sha256'], 'repaired_artifact_sha256': repaired['artifact_sha256'],
              'source_sha256': source_sha, 'data_sha256': sha(data_path), 'adjudication_sha256': sha(adjudication_path),
              'constraint': constraint, 'construction': construction, 'mapping_input_sha256': mapping_identity, 'same_development_split_metrics': metrics,
              'max_absolute_swap_difference': maximum_difference, 'functional_scope_passed': maximum_difference <= adjudication['tolerance'],
              'scientific_advantage': 'UNRUN: independent protected specification controls unchanged; these are exposed development metrics',
              'scope': 'Generic averaging of all generated basis expressions under intervention-role exchange; same measurements and objective, no per-case patch'}
    with (output / 'REPORT.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for name in ('data', 'original', 'constraint', 'adjudication', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--mapping', type=Path)
    args = parser.parse_args()
    result = run(args.data, args.original, args.constraint, args.adjudication, args.output, args.mapping)
    print(json.dumps({key: result[key] for key in ('status', 'repaired_artifact_sha256', 'max_absolute_swap_difference', 'functional_scope_passed', 'same_development_split_metrics')}))
