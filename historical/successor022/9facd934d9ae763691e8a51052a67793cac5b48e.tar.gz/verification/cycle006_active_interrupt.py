"""Versioned live-worker handshake; preserves positive adoption and no-leak criteria."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import select
import signal
import subprocess
import sys
import time

OLD_FREEZE = "fa2a87c8bc6a41c4444fea28b10d8d09e25971e06d1e61d0cbb84ba399e2a55c"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot(root):
    return {str(p.relative_to(root)): sha(p) for p in root.rglob("*") if p.is_file()}


def proc_state(host_pid):
    try:
        raw = Path("/proc", str(host_pid), "stat").read_text()
        fields = raw.rsplit(")", 1)[1].split()
        return {"state": fields[0], "parent_host_pid": int(fields[1]), "start_ticks": int(fields[19])}
    except FileNotFoundError:
        return None


def children(host_pid):
    try:
        direct = [int(p) for p in Path("/proc", str(host_pid), "task", str(host_pid), "children").read_text().split()]
    except FileNotFoundError:
        return []
    return direct + [grandchild for child in direct for grandchild in children(child)]


def worker_identity(actual):
    host_self = int(Path("/proc/self/stat").read_text().split()[0])
    own_nspids = [int(x) for x in next(line for line in Path("/proc/self/status").read_text().splitlines() if line.startswith("NSpid:")).split()[1:]]
    namespace_index = max(i for i, value in enumerate(own_nspids) if value == os.getpid())
    states = {}
    entries = [path for path in Path("/proc").iterdir() if path.name.isdigit()]
    if len(entries) > 50000:
        raise ValueError("PROC_IDENTITY_SCAN_BOUND")
    for path in entries:
        state = proc_state(int(path.name))
        if state:
            states[int(path.name)] = state
    for host_pid, state in states.items():
        try:
            ancestor, seen = state["parent_host_pid"], set()
            while ancestor != host_self and ancestor in states and ancestor not in seen:
                seen.add(ancestor)
                ancestor = states[ancestor]["parent_host_pid"]
            if ancestor != host_self or state["state"] == "Z":
                continue
            if Path("/proc", str(host_pid), "ns/pid").stat().st_ino != Path("/proc/self/ns/pid").stat().st_ino:
                continue
            command = Path("/proc", str(host_pid), "cmdline").read_bytes().split(b"\0")
            if b"--worker" not in command or str(actual).encode() not in command or not any(part.endswith(b"run_cycle.py") for part in command):
                continue
            ids = [int(x) for x in next(line for line in Path("/proc", str(host_pid), "status").read_text().splitlines() if line.startswith("NSpid:")).split()[1:]]
            current = proc_state(host_pid)
            if current and current["start_ticks"] == state["start_ticks"] and current["state"] != "Z":
                return {"host_pid": host_pid, "namespace_pid": ids[namespace_index], "namespace_index": namespace_index, **state}
        except FileNotFoundError:
            continue
    return None


def verify_sources(root):
    freeze = root / "campaign/cycle-004/FREEZE.json"
    if sha(freeze) != OLD_FREEZE:
        raise ValueError("HISTORICAL_FREEZE_IDENTITY_MISMATCH")
    sources = json.loads(freeze.read_text())["sources"]
    if len(sources) != 22 or any((root / name).is_symlink() or sha(root / name) != expected for name, expected in sources.items()):
        raise ValueError("HISTORICAL_SOURCE_IDENTITY_MISMATCH")


def termination_observation(pidfd, identity, wait_ms=1000):
    polling = select.poll()
    polling.register(pidfd, select.POLLIN | select.POLLHUP | select.POLLERR)
    events = polling.poll(wait_ms)
    exit_ready = any(bits & select.POLLIN for _, bits in events)
    state = proc_state(identity["host_pid"])
    not_live = state is None or state["start_ticks"] != identity["start_ticks"] or state["state"] == "Z"
    return {"exit_ready": exit_ready, "not_live": not_live, "events": events, "proc_state": state}


def probe(root, output):
    started, cpu = time.monotonic(), time.process_time()
    prior = resource.getrusage(resource.RUSAGE_CHILDREN)
    root, output = root.resolve(), output.resolve()
    verify_sources(root)
    output.mkdir(parents=True, exist_ok=False)
    actual = output / "actual-run"
    if ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) != 0:
        raise RuntimeError("VERIFIER_SUBREAPER_UNAVAILABLE")
    command = [sys.executable, "-I", str(root / "run_cycle.py"), "--output", str(actual)]
    env = {"PATH": os.defpath, "LANG": "C.UTF-8", "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"}
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
    deadline, identity, pidfd, handshake = time.monotonic() + 15, None, None, None
    try:
        while time.monotonic() < deadline and proc.poll() is None:
            if (actual / "SANDBOX.json").exists() and not (actual / "REPORT.json").exists():
                identity = worker_identity(actual)
                if identity:
                    pidfd = os.pidfd_open(identity["namespace_pid"])
                    current = proc_state(identity["host_pid"])
                    if not current or any(current[key] != identity[key] for key in ("parent_host_pid", "start_ticks")):
                        raise RuntimeError("WORKER_IDENTITY_CHANGED_BEFORE_HANDSHAKE")
                    signal.pidfd_send_signal(pidfd, signal.SIGSTOP)
                    stopped_deadline = time.monotonic() + 2
                    while time.monotonic() < stopped_deadline:
                        state = proc_state(identity["host_pid"])
                        if state and state["start_ticks"] == identity["start_ticks"] and state["state"] in ("T", "t"):
                            handshake = {"identity": identity, "stopped_state": state,
                                "sandbox_receipt_exists": (actual / "SANDBOX.json").exists(),
                                "report_absent": not (actual / "REPORT.json").exists(), "parent_live": proc.poll() is None}
                            break
                        time.sleep(.002)
                    break
            time.sleep(.002)
        if not handshake or not all(handshake[key] for key in ("sandbox_receipt_exists", "report_absent", "parent_live")):
            raise RuntimeError("LIVE_WORKER_HANDSHAKE_NOT_ESTABLISHED")
        proc.send_signal(signal.SIGINT)
        stdout, stderr = proc.communicate(timeout=10)
        deadline, reaped, no_children = time.monotonic() + 3, [], False
        while time.monotonic() < deadline:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
                if pid:
                    reaped.append({"namespace_pid": pid, "wait_status": status})
                else:
                    time.sleep(.01)
            except ChildProcessError:
                no_children = True
                break
        before = snapshot(actual)
        restart = subprocess.run(command, capture_output=True, text=True, timeout=10, env=env)
        after = snapshot(actual)
        adopted_worker = any(item["namespace_pid"] == identity["namespace_pid"] for item in reaped)
        termination = termination_observation(pidfd, identity)
        identity_exit_ready, identity_not_live = termination["exit_ready"], termination["not_live"]
        passed = identity_exit_ready and identity_not_live and no_children and (actual / "INTERRUPTED.json").exists() and not (actual / "COMPLETE.json").exists() and restart.returncode != 0 and before == after
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        report = {"schema": "agi-alpha-cycle006-active-worker-handshake/v3", "passed": passed,
            "runner_sha256": sha(root / "run_cycle.py"), "verifier_sha256": sha(Path(__file__)),
            "historical_sources_verified": 22, "handshake": handshake, "parent_returncode": proc.returncode,
            "adopted_descendants_reaped": reaped, "identified_worker_reaped": adopted_worker,
            "identity_bound_pidfd_exit_ready": identity_exit_ready, "identity_bound_pidfd_events": termination["events"],
            "identified_worker_not_live": identity_not_live, "final_worker_proc_state": termination["proc_state"],
            "reaping_route": "Verifier adopted identified worker" if adopted_worker else "No adoption required; identified worker exited and ECHILD establishes all descendants already reaped",
            "no_children_after_reaping": no_children, "interrupted_marker": (actual / "INTERRUPTED.json").exists(),
            "complete_absent": not (actual / "COMPLETE.json").exists(),
            "restart_refused_unchanged": restart.returncode != 0 and before == after,
            "files_sha256": before, "stdout": stdout, "stderr": stderr, "restart_stderr": restart.stderr,
            "resources": {"wall_seconds": time.monotonic() - started, "verifier_cpu_seconds": time.process_time() - cpu,
                "child_cpu_seconds": usage.ru_utime + usage.ru_stime - prior.ru_utime - prior.ru_stime},
            "scope": "External SIGSTOP establishes an identity-bound live-worker barrier after sandbox initialization and before its final report; real SIGINT goes to the unchanged historical parent. Kernel pidfd readiness must prove that exact worker exited, procidentity must not be live, and ECHILD must establish all children reaped. Parent cleanup may legitimately reap its worker; any adopted descendants are also reaped. Marker/noCOMPLETE/unchangedreplay remain mandatory. Candidate source is unchanged.",
            "limits": ["Linux pidfd/proc/subreaper qualification; no host crash or storage durability claim.", "Procedural verification shares host/model/libraries; no scientific or commercial inference."]}
        with (output / "REPORT.json").open("x") as stream:
            json.dump(report, stream, indent=2); stream.write("\n")
        return report
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.communicate(timeout=10)
        if pidfd is not None:
            try:
                signal.pidfd_send_signal(pidfd, signal.SIGKILL)
            except ProcessLookupError:
                pass
            os.close(pidfd)
        while True:
            try:
                pid, _ = os.waitpid(-1, os.WNOHANG)
                if not pid:
                    break
            except ChildProcessError:
                break


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = probe(args.root, args.output)
    print(json.dumps({"passed": result["passed"], "identified_worker_reaped": result["identified_worker_reaped"], "no_children": result["no_children_after_reaping"]}))
    raise SystemExit(0 if result["passed"] else 1)
