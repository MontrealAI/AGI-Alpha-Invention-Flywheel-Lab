"""Frozen, read-only outcome judge for two pre-registered intervention-mean pilots."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time
import zipfile

SPLITS = {'norman': '01ab11b6972ad79c5791e02a726d8833811804f585e047972ee89c94617e4fa2',
          'wessels': '8259cf981a911e33a22f51bc7151fe480f9b8ff462cf0e0fcc5b30eb28b7ff17'}
ALPHAS = (0.0001, 0.001, 0.01, 0.1, 1., 10., 100., 1000., 10000.)
PRIMARY_CONTROLS = ['additive', 'matching_mean', 'full_kernel_ridge', 'residual_mean']
ALL_CONTROLS = PRIMARY_CONTROLS + ['direct_kernel_ridge', 'residual_kernel_ridge', 'training_mean']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')


def scoped(root, value):
    if type(value) is not str or '\\' in value:
        raise ValueError('VERIFIER_PATH_SCOPE')
    relative = Path(value)
    if relative.is_absolute() or '..' in relative.parts or relative.as_posix() != value:
        raise ValueError('VERIFIER_PATH_SCOPE')
    path = root / relative
    if path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise ValueError('VERIFIER_SYMLINK_REFUSED')
    return path


def frozen_sources(root, freeze_path, expected):
    if not expected or sha(freeze_path) != expected:
        raise ValueError('CONFIRMATION_FREEZE_IDENTITY_MISMATCH')
    freeze = json.loads(freeze_path.read_text())
    if type(freeze.get('sources')) is not dict or not freeze['sources']:
        raise ValueError('CONFIRMATION_FREEZE_SCHEMA')
    for name, identity in freeze['sources'].items():
        if sha(scoped(root, name)) != identity:
            raise ValueError('CONFIRMATION_SOURCE_IDENTITY_MISMATCH ' + name)
    own = str(Path(__file__).resolve().relative_to(root))
    if freeze['sources'].get(own) != sha(Path(__file__)):
        raise ValueError('VERIFIER_NOT_FROZEN')
    for name in ('flywheel/__init__.py', 'flywheel/sandbox.py', 'experiments/norman006/model.py'):
        if name not in freeze['sources']:
            raise ValueError('EXECUTING_DEPENDENCY_NOT_FROZEN ' + name)
    return freeze


def npz(path, keys):
    import numpy as np
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        if len(entries) > 12 or sum(item.file_size for item in entries) > 20 * 1024**2 or len({item.filename for item in entries}) != len(entries):
            raise ValueError('NPZ_RESOURCE_OR_DUPLICATE_BOUND')
    with np.load(path, allow_pickle=False) as source:
        if set(source.files) != set(keys):
            raise ValueError('NPZ_KEY_SCOPE')
        return {key: source[key].copy() for key in source.files}


def axes(data, features):
    import numpy as np
    if not np.array_equal(data['pairs'], features['pairs']) or not np.array_equal(data['genes'], features['genes']):
        raise ValueError('PREDICTION_AXIS_IDENTITY_MISMATCH')
    expected = features['A'].shape
    if data['prediction'].shape != expected or not np.isfinite(data['prediction']).all() or np.max(np.abs(data['prediction'])) > 1e12:
        raise ValueError('PREDICTION_SHAPE_OR_FINITE_SCOPE')


def kernel_prediction(train, inputs, alpha, residual):
    import numpy as np
    training_x = train['A'] + train['B'] - 2 * train['ctrl']
    center, scale = training_x.mean(axis=0), np.maximum(training_x.std(axis=0), 1e-8)
    x = (training_x - center) / scale
    target = train['AB'] - (train['A'] + train['B'] - train['ctrl'] if residual else train['ctrl'])
    mean = target.mean(axis=0)
    gram = (x @ x.T) / x.shape[1]
    coefficient = np.linalg.solve(gram + float(alpha) * np.eye(len(x)), target - mean)
    xx = (inputs['A'] + inputs['B'] - 2 * inputs['ctrl'] - center) / scale
    base = inputs['A'] + inputs['B'] - inputs['ctrl'] if residual else inputs['ctrl']
    return base + mean + (xx @ x.T / x.shape[1]) @ coefficient


def subset(data, indices, outcome):
    return {**{key: data[key][indices] for key in ('A', 'B', 'ctrl', 'pairs') + (('AB',) if outcome else ())}, 'genes': data['genes']}


def independently_qualify_controls(development, features):
    import numpy as np
    first, second = development['fit_indices'], development['calibration_indices']
    if set(first) & set(second) or set(first) | set(second) != set(range(len(development['pairs']))):
        raise ValueError('CONTROL_DEVELOPMENT_SPLIT')
    train, calibration = subset(development, first, True), subset(development, second, False)
    truth = development['AB'][second]
    trials = []
    for residual in (False, True):
        for alpha in ALPHAS:
            prediction = kernel_prediction(train, calibration, alpha, residual)
            trials.append({'alpha': alpha, 'residual': residual,
                'median_pair_rmse': float(np.median(np.sqrt(np.mean((prediction - truth)**2, axis=1)))),
                'pooled_rmse': float(np.sqrt(np.mean((prediction - truth)**2)))})
    key = lambda row: (row['median_pair_rmse'], row['pooled_rmse'], -row['alpha'], not row['residual'])
    winners = {'full_kernel_ridge': min(trials, key=key),
        'direct_kernel_ridge': min((row for row in trials if not row['residual']), key=key),
        'residual_kernel_ridge': min((row for row in trials if row['residual']), key=key)}
    additive = features['A'] + features['B'] - features['ctrl']
    predictions = {'additive': additive, 'matching_mean': (features['A'] + features['B']) / 2,
        'training_mean': features['ctrl'] + np.mean(development['AB'] - development['ctrl'], axis=0),
        'residual_mean': additive + np.mean(development['AB'] - (development['A'] + development['B'] - development['ctrl']), axis=0)}
    predictions.update({name: kernel_prediction(development, features, row['alpha'], row['residual']) for name, row in winners.items()})
    return predictions, winners, trials


def preflight(root, manifest_path, output, freeze=None):
    import numpy as np
    manifest = json.loads(manifest_path.read_text())
    family = manifest.get('family')
    if manifest.get('schema') != 'agi-alpha-cycle006-arm-manifest/v1' or family not in SPLITS or manifest.get('primary_controls') != PRIMARY_CONTROLS:
        raise ValueError('FROZEN_ARM_MANIFEST_SCHEMA')
    if freeze and str(manifest_path.relative_to(root)) not in freeze['sources']:
        raise ValueError('ARM_MANIFEST_NOT_FROZEN')
    for key in ('development', 'features', 'split'):
        if sha(scoped(root, manifest[key + '_path'])) != manifest[key + '_sha256']:
            raise ValueError('ARM_INPUT_IDENTITY_MISMATCH ' + key)
    split_path = scoped(root, manifest['split_path'])
    if sha(split_path) != SPLITS[family]:
        raise ValueError('PRE_REGISTERED_SPLIT_IDENTITY_MISMATCH')
    split = json.loads(split_path.read_text())
    for name, identity in split['public_files'].items():
        if sha(split_path.parent / name) != identity:
            raise ValueError('PRE_REGISTERED_ARRAY_IDENTITY_MISMATCH')
    features = npz(scoped(root, manifest['features_path']), ['A', 'B', 'ctrl', 'pairs', 'genes'])
    development = npz(scoped(root, manifest['development_path']), ['A', 'B', 'ctrl', 'AB', 'pairs', 'genes', 'fit_indices', 'calibration_indices'])
    expected_n = 44 if family == 'norman' else 58
    if features['A'].shape != (expected_n, 1000) or not np.array_equal(development['genes'], features['genes']) or set(development['pairs']) & set(features['pairs']):
        raise ValueError('PRE_REGISTERED_COHORT_MISMATCH')
    for name in ALL_CONTROLS:
        if name not in manifest['arms'] or manifest['arms'][name]['status'] != 'complete':
            raise ValueError('QUALIFIED_NAMED_CONTROL_MISSING ' + name)
    independent, winners, trials = independently_qualify_controls(development, features)
    model_path = root / 'experiments/norman006/model.py'
    for record in manifest['arms'].values():
        for name, identity in record['source_versions'].items():
            if sha(scoped(root, name)) != identity:
                raise ValueError('ARM_SOURCE_VERSION_MISMATCH ' + name)
    from flywheel import sandbox
    qualification = sandbox.qualify()
    if not qualification['qualified']:
        raise ValueError('GENERATED_INTERPRETER_SANDBOX_UNQUALIFIED')
    spec = importlib.util.spec_from_file_location('frozen_readonly_norman_model', model_path)
    model = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(model)
    predictions, checked = {}, {}
    for name, record in manifest['arms'].items():
        if record['status'] != 'complete':
            checked[name] = {'state': record['status'], 'reason': record.get('reason', 'frozen failed/refused arm'), 'functional_passed': False}
            continue
        path = scoped(root, record['prediction_path'])
        if sha(path) != record['prediction_sha256']:
            raise ValueError('NOMINATED_PREDICTION_IDENTITY_MISMATCH ' + name)
        values = npz(path, ['prediction', 'pairs', 'genes'])
        axes(values, features)
        prediction = values['prediction']
        if name in independent:
            replay = independent[name]
            if record['kind'] == 'ridge':
                winner = winners[name]
                if record['hyperparameters']['alpha'] != winner['alpha'] or record['hyperparameters']['residual'] != winner['residual']:
                    raise ValueError('RIDGE_SELECTION_NOT_REPRODUCED ' + name)
            maximum = float(np.max(np.abs(prediction - replay)))
            symmetry = 0.
            if not np.allclose(prediction, replay, rtol=1e-9, atol=1e-10):
                raise ValueError('CONVENTIONAL_CONTROL_NOT_INDEPENDENTLY_REPRODUCED ' + name)
            evidence = {'independent_equation_replay_max_difference': maximum, 'ridge_selected': winners.get(name)}
        elif record['kind'] == 'model':
            artifact_path = scoped(root, record['artifact_path'])
            if sha(artifact_path) != record['artifact_file_sha256']:
                raise ValueError('NOMINATED_ARTIFACT_IDENTITY_MISMATCH ' + name)
            artifact = json.loads(artifact_path.read_text())
            if artifact['interpreter_source_sha256'] != sha(model_path) or record['hyperparameters'] != artifact['configuration']:
                raise ValueError('ARTIFACT_CONFIGURATION_OR_SOURCE_MISMATCH ' + name)
            original = model.predict(artifact, features)
            swapped = model.predict(artifact, dict(features, A=features['B'], B=features['A']))
            if not np.allclose(prediction, original['prediction'], rtol=1e-10, atol=1e-11):
                raise ValueError('NOMINATED_MODEL_OUTPUT_NOT_REPRODUCED ' + name)
            symmetry = float(np.max(np.abs(original['prediction'] - swapped['prediction'])))
            evidence = {'artifact_sha256': artifact['artifact_sha256'], 'original_basis_receipt': original['basis_receipt'], 'swapped_basis_receipt': swapped['basis_receipt']}
        else:
            raise ValueError('UNSUPPORTED_PREDICTION_KIND ' + name)
        checked[name] = {'state': 'executed', 'functional_passed': symmetry <= 1e-10, 'max_absolute_exchange_difference': symmetry,
            'prediction_sha256': record['prediction_sha256'], 'independent_reproduction': evidence}
        predictions[name] = prediction
    if manifest['primary_candidate'] not in predictions:
        raise ValueError('PRIMARY_CANDIDATE_NOT_EXECUTABLE')
    result = {'family': family, 'manifest_sha256': sha(manifest_path), 'split_sha256': sha(split_path),
        'verifier_source_sha256': sha(Path(__file__)),
        'sandbox_qualification': qualification, 'arms': checked, 'independent_ridge_winners': winners, 'independent_development_ridge_trials': trials,
        'all_named_controls_reproduced': True, 'protected_outcomes_opened': False}
    write(output / 'PREFLIGHT.json', result)
    return manifest, split, features, predictions, result


def ranking(prediction, truth, features, family):
    import numpy as np
    reference = features['A'] + features['B'] - features['ctrl']
    observed, predicted = np.abs(truth - reference), np.abs(prediction - reference)
    discounts = 1 / np.log2(np.arange(2, 52))
    scores = []
    for i, pair in enumerate(features['pairs']):
        if observed[i].max() <= 1e-12:
            scores.append(None)
            continue
        source_identity = 'f35c9efe3bf0f917068b2aaf2c2236b593c06e2c' if family == 'norman' else '5da0485aed81b23bda57b4a7b4510a394682d54911416db89b4846ff6dd34732'
        ties = [hashlib.sha256((source_identity + '|' + str(pair) + '|' + str(gene)).encode()).hexdigest() for gene in features['genes']]
        actual_order = sorted(range(1000), key=lambda j: (-observed[i, j], ties[j]))
        predicted_order = sorted(range(1000), key=lambda j: (-predicted[i, j], ties[j]))
        positive = set(actual_order[:100])
        scores.append(float(sum(discounts[k] for k, gene in enumerate(predicted_order[:50]) if gene in positive) / discounts.sum()))
    usable = [score for score in scores if score is not None]
    return {'per_pair_ndcg_at50_top100_observed_deviations': scores, 'mean_ndcg': float(np.mean(usable)) if usable else None,
        'defined_pairs': len(usable), 'scope': 'Observed normalized mean-deviation rankings, not biological interaction significance or FPR'}


def compare(loss, control, pairs):
    import numpy as np
    invalid = (control <= 1e-15) & (loss > 1e-15)
    gain = np.divide(control - loss, control, out=np.zeros_like(loss), where=control > 1e-15)
    median = float(np.median(gain))
    harm = float(np.quantile(-gain, .9))
    pair_loo = [float(np.median(np.delete(gain, i))) for i in range(len(gain))]
    genes = sorted({part for pair in pairs for part in str(pair).split('+')})
    gene_loo = []
    for gene in genes:
        keep = np.asarray([gene not in str(pair).split('+') for pair in pairs])
        if keep.sum() >= 10:
            gene_loo.append({'omitted_perturbation': gene, 'remaining_pairs': int(keep.sum()), 'median_gain': float(np.median(gain[keep]))})
    pooled_improves = float(np.mean(loss**2)) < float(np.mean(control**2))
    return {'per_pair_relative_rmse_gain': [None if invalid[i] else float(value) for i, value in enumerate(gain)],
        'zero_control_nonzero_candidate_cases': int(invalid.sum()), 'median_relative_gain': median,
        'pooled_rmse_improves': pooled_improves, 'ninetieth_percentile_relative_loss_increase': harm,
        'leave_one_pair_out_median_range': [min(pair_loo), max(pair_loo)], 'leave_one_constituent_out': gene_loo,
        'practical_threshold_met': not invalid.any() and median >= .05 and pooled_improves and harm <= .10}


def validate_functional_contract(root, contract_path, expected_sha, freeze):
    if sha(contract_path) != expected_sha:
        raise ValueError('PRE_OUTCOME_FUNCTIONAL_CONTRACT_IDENTITY_MISMATCH')
    relative = str(contract_path.resolve().relative_to(root))
    if freeze['sources'].get(relative) != expected_sha:
        raise ValueError('FUNCTIONAL_CONTRACT_NOT_FROZEN_BEFORE_OUTCOMES')
    contract = json.loads(contract_path.read_text())
    fields = {'schema', 'scope', 'requirements', 'verifier_source', 'functional_obligations', 'scenario', 'commercial_cohort_admitted'}
    requirements = ['artifact-identity', 'receipt-identity', 'verifier-source-identity', 'frozen-obligations-identity', 'independent-scoped-acceptance']
    if set(contract) != fields or contract['schema'] != 'agi-alpha/conditional-functional-contract006/v1' or contract['scope'] != 'source-bound-pilot-report-delivery' or contract['requirements'] != requirements or contract['commercial_cohort_admitted'] is not False:
        raise ValueError('UNSUPPORTED_FUNCTIONAL_CONTRACT')
    own = str(Path(__file__).resolve().relative_to(root))
    if contract['verifier_source'] != {'path': own, 'sha256': sha(Path(__file__))}:
        raise ValueError('FUNCTIONAL_CONTRACT_VERIFIER_IDENTITY')
    document = contract['functional_obligations']
    if set(document) != {'path', 'sha256'} or not document['path'].startswith('verification/'):
        raise ValueError('FUNCTIONAL_OBLIGATION_DOCUMENT_SCOPE')
    path = scoped(root, document['path'])
    if sha(path) != document['sha256'] or freeze['sources'].get(document['path']) != document['sha256']:
        raise ValueError('FUNCTIONAL_OBLIGATION_IDENTITY')
    value = json.loads(path.read_text())
    expected = {'schema': 'agi-alpha/functional-obligations006/v1', 'scope': contract['scope'],
        'requires_truthful_all_arms_and_failures': True, 'does_not_require_scientific_advantage': True,
        'buyer_participation_is_fixture_only': True, 'commercial_price_is_not_established': True}
    if value != expected:
        raise ValueError('UNSUPPORTED_OR_WEAKENED_FUNCTIONAL_OBLIGATIONS')
    return contract


def confirm(root, manifest_path, truth_path, output, freeze_path=None, freeze_sha=None, preflight_only=False, contract_path=None, contract_sha=None):
    started, cpu = time.monotonic(), time.process_time()
    prior = resource.getrusage(resource.RUSAGE_CHILDREN)
    root, output = root.resolve(), output.resolve()
    manifest_path = manifest_path.resolve()
    freeze = None if preflight_only else frozen_sources(root, freeze_path.resolve(), freeze_sha)
    contract = None
    if contract_path is not None:
        if preflight_only or not contract_sha:
            raise ValueError('FUNCTIONAL_CONTRACT_REQUIRES_FROZEN_FINAL_EXECUTION')
        contract = validate_functional_contract(root, contract_path.resolve(), contract_sha, freeze)
    output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(root))
    manifest, split, features, predictions, checks = preflight(root, manifest_path, output, freeze)
    if preflight_only:
        return {'status': 'PUBLIC_DATA_PREFLIGHT_ONLY', 'protected_outcomes_opened': False, **checks}
    protocol_name = 'verification/cycle006_' + manifest['family'] + '_protocol.json'
    if freeze['sources'].get(protocol_name) != sha(root / protocol_name):
        raise ValueError('ACCEPTANCE_PROTOCOL_NOT_FROZEN')
    if truth_path is None or sha(truth_path) != split['protected_truth_sha256']:
        raise ValueError('REGISTERED_PROTECTED_TRUTH_IDENTITY_MISMATCH')
    import numpy as np
    truth = npz(truth_path, ['A', 'B', 'ctrl', 'AB', 'pairs', 'genes'])
    for key in ('A', 'B', 'ctrl', 'pairs', 'genes'):
        if not np.array_equal(truth[key], features[key]):
            raise ValueError('PROTECTED_TRUTH_INPUT_AXES_MISMATCH')
    if truth['AB'].shape != features['A'].shape or not np.isfinite(truth['AB']).all():
        raise ValueError('PROTECTED_TRUTH_SCOPE')
    arms = {}
    for name, record in checks['arms'].items():
        if name not in predictions:
            arms[name] = record
            continue
        loss = np.sqrt(np.mean((predictions[name] - truth['AB'])**2, axis=1))
        arms[name] = {**record, 'per_pair_rmse': loss.tolist(), 'median_pair_rmse': float(np.median(loss)),
            'pooled_rmse': float(np.sqrt(np.mean(loss**2))), 'ranking': ranking(predictions[name], truth['AB'], features, manifest['family'])}
    primary = manifest['primary_candidate']
    primary_loss = np.asarray(arms[primary]['per_pair_rmse'])
    contrasts = {name: compare(primary_loss, np.asarray(arms[name]['per_pair_rmse']), features['pairs']) for name in PRIMARY_CONTROLS}
    threshold = checks['arms'][primary]['functional_passed'] and all(value['practical_threshold_met'] for value in contrasts.values())
    raw = {'truth': truth['AB'], 'pairs': features['pairs'], 'genes': features['genes'], **{'prediction_' + name: value for name, value in predictions.items()}}
    np.savez_compressed(output / 'EVALUATED_OUTCOMES.npz', **raw)
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    report = {'schema': 'agi-alpha-cycle006-frozen-confirmation/v1', 'status': 'COMPLETE_FIXED_COHORT_EVALUATION',
        'family': manifest['family'], 'source_freeze_sha256': freeze_sha, 'source_manifest_sha256': sha(manifest_path),
        'verifier_source_sha256': sha(Path(__file__)), 'protocol_sha256': sha(root / ('verification/cycle006_' + manifest['family'] + '_protocol.json')),
        'split_sha256': SPLITS[manifest['family']], 'protected_truth_sha256': split['protected_truth_sha256'],
        'primary_candidate': primary, 'primary_controls': PRIMARY_CONTROLS, 'pairs': list(map(str, features['pairs'])),
        'readout_genes': 1000, 'arms': arms, 'primary_contrasts': contrasts,
        'practical_pilot_threshold_met': threshold, 'functional_audit_gates_passed': checks['all_named_controls_reproduced'],
        'raw_evaluated_outcomes_sha256': sha(output / 'EVALUATED_OUTCOMES.npz'),
        'scope': 'Fixed published-data summarymean prediction pilot; all raw outcomes now exposed. Threshold does not establish population, biological, clinical, discovery-policy or commercial superiority.',
        'verdicts': {'engineering_qualification': 'DEMONSTRATED_IN_DECLARED_SCOPE',
            'consequential_enabling_capability': 'NOT_ESTABLISHED', 'combination_advantage': 'UNESTABLISHED_BEYOND_THIS_FINITE_COMPARISON',
            'experience_advantage': 'UNESTABLISHED_OVER_EQUIVALENT_REUSE', 'conditional_modeled_commercial_viability': 'SEPARATE_CONTRACT_REQUIRED',
            'investment_attractiveness': 'UNKNOWN', 'AGI_ALPHA_value_capture': 'UNKNOWN', 'earned_funded_successor_benefit': 'NOT_ESTABLISHED', 'live_commercial_success': 'NOT_ESTABLISHED'},
        'resources': {'wall_seconds': time.monotonic() - started, 'verifier_cpu_seconds': time.process_time() - cpu,
            'child_cpu_seconds': usage.ru_utime + usage.ru_stime - prior.ru_utime - prior.ru_stime, 'complete_monetary_cost': None},
        'confirmation_alpha_spent': 0,
        'limitations': ['44Norman or58Wessels pairs share single-intervention inputs/control/readoutgenes; not thousands of independentreplicates.',
            'Role separation shares host/model/libraries and public primarydata may have prior exposure; not externalcertification.',
            'GEARS/PRESAGE/completeSystema benchmark notrun; equationcontrol qualification is not parity with every published workflow.',
            'Search/acquisition/repair/checking costs remain charged separately; marginalruntime is not total lifecycle or monetarycost.']}
    write(output / 'REPORT.json', report)
    write(output / 'EXPOSURE.json', {'status': 'ALL_PROTECTED_CASES_NOW_EXPOSED', 'report_sha256': sha(output / 'REPORT.json'),
        'no_reuse_as_fresh_confirmation': True, 'source_freeze_sha256': freeze_sha})
    if contract is not None:
        receipt = {'schema': 'agi-alpha/functional-acceptance006/v1', 'artifact_sha256': sha(output / 'REPORT.json'),
            'contract_sha256': contract_sha, 'functional_obligations_sha256': contract['functional_obligations']['sha256'],
            'verifier_source_sha256': sha(Path(__file__)), 'accepted': report['functional_audit_gates_passed'],
            'scope': 'source-bound-pilot-report-delivery'}
        write(output / 'FUNCTIONAL_ACCEPTANCE.json', receipt)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'manifest', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--truth', type=Path)
    parser.add_argument('--freeze', type=Path)
    parser.add_argument('--freeze-sha256')
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--contract', type=Path)
    parser.add_argument('--contract-sha256')
    args = parser.parse_args()
    result = confirm(args.root, args.manifest, args.truth, args.output, args.freeze, args.freeze_sha256, args.preflight_only, args.contract, args.contract_sha256)
    print(json.dumps({'status': result['status'], 'family': result['family'], 'protected_outcomes_opened': not args.preflight_only,
        'practical_pilot_threshold_met': result.get('practical_pilot_threshold_met')}))
