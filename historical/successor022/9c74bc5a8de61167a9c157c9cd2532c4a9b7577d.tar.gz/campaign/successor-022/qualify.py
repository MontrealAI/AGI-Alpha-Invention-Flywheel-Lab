import argparse
import collections
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from commercial.ledger import canonical,digest


def read(path):
    return json.loads(Path(path).read_text())


def write(path,value):
    Path(path).write_bytes(canonical(value)+b'\n')


def call(output,name,args,*,cwd=ROOT):
    done=subprocess.run([sys.executable,'-m','connected_enterprise',*args],cwd=cwd,
                        text=True,capture_output=True,timeout=650)
    (output/(name+'.stdout')).write_text(done.stdout);(output/(name+'.stderr')).write_text(done.stderr)
    if done.returncode:raise RuntimeError(name+' failed: '+done.stderr[-3000:])
    return json.loads(done.stdout.strip().splitlines()[-1])


def setup(output,arm):
    from tests.connected_legacy_fixture import materialize
    from adaptive_enterprise.instruments import prepare_services
    from connected_enterprise.runner import identity
    if output.exists():raise FileExistsError('NEW_QUALIFICATION_BUSINESS_REQUIRED')
    output.mkdir(parents=True);protocol=read(ROOT/'campaign/successor-022/QUALIFICATION_PROTOCOL.json')
    cfg=read(ROOT/protocol['config']);policy=read(ROOT/protocol['policies'][arm]);old=output/'legacy-source'
    materialize(ROOT,protocol['legacy_commit'],old)
    manifest=prepare_services(old,'service-inputs',cohort_seed=protocol['service_cohort_seed'])
    write(output/'SERVICES.json',manifest);write(output/'CONFIG.json',cfg);write(output/'POLICY.json',policy)
    payload={'root':str(old),'manifest':manifest,'config':cfg,'seed':protocol['world_seed'],'arm':'growth',
             'output':str(output/'business'),'source':identity(old),'stop_after_events':250}
    code='''import json,sys
from pathlib import Path
from connected_enterprise.engine import run_world
p=json.load(sys.stdin)
def stop(where,state,account):
 checkpoint=json.loads((Path(p['output'])/'STATE.json').read_text())
 kinds={e['kind'] for e in checkpoint['body']['state']['queue']}
 if {'produce','accept','clear'}<=kinds and account.snapshot()['summary']['tailReserve']>0:
  (Path(p['output']).parent/'LEGACY_RECORD.json').write_text(json.dumps(account.export()))
  raise InterruptedError('registered nonempty prepared legacy checkpoint')
try:run_world(**p,failpoint=stop)
except InterruptedError:pass
else:raise ValueError('REGISTERED_LEGACY_COVERAGE_NOT_REACHED')
'''
    done=subprocess.run([sys.executable,'-c',code],input=json.dumps(payload),cwd=old,
                        env={**os.environ,'PYTHONPATH':str(old)},text=True,capture_output=True,timeout=300)
    (output/'legacy.stdout').write_text(done.stdout);(output/'legacy.stderr').write_text(done.stderr)
    if done.returncode:raise RuntimeError(done.stderr)
    business=output/'business';checkpoint=read(business/'STATE.json');write(output/'ORIGINAL_CHECKPOINT.json',checkpoint)
    key=business/'account.sqlite.adaptive-simulation-key';inode=key.stat().st_ino
    receipt=call(output,'upgrade',['upgrade','--output',str(business),'--historical-source',str(old),
                 '--manifest',str(output/'SERVICES.json'),'--policy',str(output/'POLICY.json'),
                 '--expected-checkpoint',digest(checkpoint),'--id','qualification-'+arm+'-1'])
    after=read(business/'STATE.json')['body']['state'];before=checkpoint['body']['state']
    for field in ['queue','current','orders','buyers','events','decisions','investments','used_jobs','processed_events','last_time']:
        if after[field]!=before[field]:raise ValueError('UPGRADE_LOST_OPERATING_STATE:'+field)
    if after['costs'][:len(before['costs'])]!=before['costs'] or key.stat().st_ino!=inode:
        raise ValueError('UPGRADE_LOST_COST_HISTORY_OR_KEY_IDENTITY')
    d=read(business/'OPERATOR.json')
    registration={'schema':'agi-alpha/successor022-business-registration/v1','arm':arm,'protocol':protocol,
                  'protocol_sha256':digest(protocol),'config_sha256':digest(cfg),'policy_sha256':digest(policy),
                  'manifest_sha256':digest(manifest),'source_sha256':d['source']['sha256'],
                  'original_native_actions_sha256':read(output/'LEGACY_RECORD.json')['ledger']['actions_sha256'],
                  'original_checkpoint_sha256':digest(checkpoint),'key_inode':inode,'migration':receipt}
    write(output/'REGISTRATION.json',registration)
    print(json.dumps({'registered':True,'arm':arm,'source_sha256':registration['source_sha256'],'legacy_queue_kinds':sorted({e['kind'] for e in before['queue']})}))


def step(output):
    registration=read(output/'REGISTRATION.json');business=output/'business';before=read(business/'STATE.json')['body']['state']
    if not before['queue']:raise ValueError('REGISTERED_BUSINESS_ALREADY_COMPLETE')
    number=len(list(output.glob('quantum-*.json')))+1
    result=call(output,'quantum-'+str(number),['operate','--output',str(business),'--max-events',str(registration['protocol']['quantum_event_limit'])])
    after=read(business/'STATE.json')['body']['state']
    if after['processed_events']<=before['processed_events']:raise ValueError('QUANTUM_MADE_NO_PROGRESS')
    if (business/'account.sqlite.adaptive-simulation-key').stat().st_ino!=registration['key_inode']:
        raise ValueError('CONTINUING_ACCOUNT_KEY_CHANGED')
    receipt={'schema':'agi-alpha/successor022-quantum/v1','number':number,'before_events':before['processed_events'],
             'after_events':after['processed_events'],'remaining_events':len(after['queue']),'complete':result['complete'],
             'source_sha256':registration['source_sha256'],'summary':result['summary']}
    write(output/('quantum-'+str(number)+'.json'),receipt);print(json.dumps(receipt))


def finish(output):
    registration=read(output/'REGISTRATION.json');business=output/'business';before=read(business/'RESULT.json')
    if not before['complete']:raise ValueError('ALL_REGISTERED_EVENTS_MUST_COMPLETE')
    call(output,'resume-complete',['resume','--output',str(business)])
    result=read(business/'RESULT.json')
    if result['owned_account']['ledger']!=before['owned_account']['ledger']:
        raise ValueError('COMPLETE_RESUME_CHANGED_NATIVE_LEDGER')
    checked=call(output,'audit',['audit','--output',str(business)])
    score=call(output,'scoreboard',['scoreboard','--output',str(business)])
    prior=read(output/'LEGACY_RECORD.json')['ledger'];actions=result['owned_account']['ledger']['actions']
    if actions[:len(prior['actions'])]!=prior['actions'] or result['source']['sha256']!=registration['source_sha256']:
        raise ValueError('CONTINUING_NATIVE_HISTORY_OR_SOURCE_CHANGED')
    old_state=read(output/'ORIGINAL_CHECKPOINT.json')['body']['state'];old_orders=list(old_state['orders'])
    if old_state['current']:old_orders+=old_state['current'].get('orders',[])
    protected=sum(o['price']+200000 for o in result['orders'] if o['id'] in {r['id'] for r in old_orders} and o['outcome']=='SETTLED')
    if result['summary']['tailReserve']<protected:raise ValueError('LEGACY_PERMANENT_TAIL_WAS_ERASED')
    verdict=score['profitable_settlements_funded_after_maturity']>=2 and score['summary']['profit']>0 and checked['accepted']
    receipt={'schema':'agi-alpha/successor022-business-verdict/v1','arm':registration['arm'],'audit_accepted':checked['accepted'],
             'complete_resume_unchanged':True,'same_key_inode':(business/'account.sqlite.adaptive-simulation-key').stat().st_ino==registration['key_inode'],
             'source_sha256':registration['source_sha256'],'summary':result['summary'],'paid_jobs':result['paid_jobs'],
             'service_counts':dict(collections.Counter(o['offer']['service_id'] for o in result['orders'] if o['outcome']=='SETTLED')),
             'maturities':score['maturities'],'profitable_settlements_funded_after_maturity':score['profitable_settlements_funded_after_maturity'],
             'prospective_positive_region_criterion':verdict if registration['arm']=='prospective' else None,
             'scope':'CONDITIONAL_AUTHORED_SYNTHETIC_ENGINEERING_NOT_EXTERNAL_OR_ANNUAL_PROFIT'}
    write(output/'VERDICT.json',receipt);print(json.dumps(receipt))


def export(output):
    verdict=read(output/'VERDICT.json');business=output/'business';d=read(business/'OPERATOR.json')
    public=output/'public'
    if public.exists():raise FileExistsError('NEW_PUBLIC_EXPORT_REQUIRED')
    public.mkdir();shutil.copytree(business/d['source_dir'],public/'source')
    record=read(business/'RESULT.json')['owned_account'];ticket=record['source_transitions']['qualification-'+verdict['arm']+'-1']
    fallback=public/'source'/'historical-source-versions'/ticket['body']['from_source']['sha256']
    shutil.copytree(output/'legacy-source',fallback)
    for name,path in [('RESULT.json',business/'RESULT.json'),('STATE.json',business/'STATE.json'),('SERVICES.json',output/'SERVICES.json'),
                      ('SCOREBOARD.json',business/'SCOREBOARD.json'),('VERDICT.json',output/'VERDICT.json'),('REGISTRATION.json',output/'REGISTRATION.json')]:
        shutil.copyfile(path,public/name)
    old=output/'legacy-source';hidden=output/'legacy-source-portability-offline';old.rename(hidden)
    try:
        code='import json,sys;from pathlib import Path;from connected_enterprise.verify import audit;p=Path(sys.argv[1]);print(json.dumps(audit(p/"source",json.load(open(p/"SERVICES.json")),json.load(open(p/"RESULT.json"))),sort_keys=True))'
        done=subprocess.run([sys.executable,'-c',code,str(public)],cwd=public/'source',text=True,capture_output=True,timeout=300)
        (output/'portable-audit.stdout').write_text(done.stdout);(output/'portable-audit.stderr').write_text(done.stderr)
        if done.returncode:raise RuntimeError(done.stderr)
        checked=json.loads(done.stdout)
    finally:hidden.rename(old)
    if not checked['accepted']:raise ValueError('EXPORTED_PORTABLE_AUDIT_FAILED')
    receipt={'accepted':True,'scope':'CLEAN_KEY_FREE_SOURCE_COPY_REPRODUCTION_NOT_A_PUBLISHED_RELEASE_DOWNLOAD',
             'historical_absolute_source_unavailable_during_audit':True,'private_account_or_keys_exported':False,
             'audit':checked}
    write(output/'PORTABLE_EXPORT.json',receipt);print(json.dumps({'accepted':True,'public':str(public)}))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['setup','step','finish','export']);parser.add_argument('--output',required=True)
    parser.add_argument('--arm',choices=['prospective','permanent_control']);args=parser.parse_args();output=Path(args.output).absolute()
    if args.action=='setup':
        if args.arm is None:parser.error('--arm required for setup')
        setup(output,args.arm)
    else:globals()[args.action](output)


if __name__=='__main__':main()
