import argparse, datetime, hashlib, json, os, resource, signal, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from connected_enterprise.runner import identity

def read(p): return json.loads(p.read_text())
def write(p, value): p.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def run(output):
    output = Path(output).absolute()
    if output.exists(): raise FileExistsError('NEW_EXPERIMENT_OUTPUT_REQUIRED')
    protocol = read(HERE / 'PROTOCOL.json')
    if identity(ROOT) != protocol['source']: raise ValueError('REGISTERED_SOURCE_CHANGED')
    output.mkdir(parents=True, mode=0o700)
    write(output / 'PROTOCOL.json', protocol)
    receipt = {'schema': 'agi-alpha/native-recycling025-execution/v1', 'accepted': False,
               'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'protocol_sha256': sha(HERE / 'PROTOCOL.json'), 'source_sha256': protocol['source']['sha256'],
               'helper_sha256': sha(Path(__file__)), 'commands': [], 'cases': []}
    started = time.monotonic()
    def command(label, args):
        before = resource.getrusage(resource.RUSAGE_CHILDREN); tick = time.monotonic()
        with (output / (label + '.stdout')).open('w') as stdout, (output / (label + '.stderr')).open('w') as stderr:
            child = subprocess.Popen([sys.executable, '-m', 'connected_enterprise', *map(str, args)], cwd=ROOT,
                                     env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=stdout,
                                     stderr=stderr, start_new_session=True)
            try: returncode = child.wait(timeout=180)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL); child.wait(); raise
        after = resource.getrusage(resource.RUSAGE_CHILDREN)
        receipt['commands'].append({'label': label, 'arguments': list(map(str, args)), 'returncode': returncode,
                                    'wall_seconds': time.monotonic() - tick,
                                    'command_cpu_seconds': after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime,
                                    'stdout_sha256': sha(output / (label + '.stdout')), 'stderr_sha256': sha(output / (label + '.stderr'))})
        write(output / 'EXECUTION.json', receipt)
        if returncode: raise RuntimeError('PUBLIC_COMMAND_FAILED:' + label)
    try:
        for case in protocol['cases']:
            name = case['id']; config = output / (name + '.config.json'); target = output / name
            write(config, case['config'])
            command(name + '-01-operate', ['comparison', '--config', config, '--output', target])
            command(name + '-02-audit', ['audit', '--output', target])
            first = {arm: read(target / 'arms' / arm / 'RESULT.json')['owned_account']['ledger']
                     for arm in ['recycling_enabled', 'recycling_disabled']}
            command(name + '-03-unchanged-resume', ['comparison', '--output', target])
            for arm, ledger in first.items():
                if read(target / 'arms' / arm / 'RESULT.json')['owned_account']['ledger'] != ledger:
                    raise ValueError('COMPLETED_RESUME_CHANGED_FINANCES:' + name + ':' + arm)
            command(name + '-04-audit-resume', ['audit', '--output', target])
            comparison = read(target / 'COMPARISON.json'); audit = read(target / 'CAPITAL_AUDIT.json')
            if audit['accepted'] is not True: raise ValueError('NATIVE_OR_OPERATING_AUDIT_REJECTED')
            rows = {}
            for arm, score in comparison['arms'].items():
                result = read(target / 'arms' / arm / 'RESULT.json'); summary = result['summary']
                positive_deferred = [d for d in result['state']['decisions']
                                     if d['audited_before']['summary']['profit'] > 0 and not d['affordable']]
                if (not result['complete'] or result['state']['queue'] or
                    summary['revenue'] - summary['expense'] != summary['profit']):
                    raise ValueError('INDEPENDENT_NATIVE_COMPLETION_OR_PROFIT_RECONCILIATION_FAILED')
                rows[arm] = {'source_sha256': result['source_sha256'], 'native_summary': summary,
                             'settled_orders': score['settled_orders'], 'matured_orders': score['matured_orders'],
                             'profitable_earned_continuations': score['profitable_earned_continuations'],
                             'repeated_earned_financed_expansion': score['repeated_earned_financed_expansion'],
                             'all_arrivals': score['arrivals_observed'], 'last_hour': result['state']['last_hour'],
                             'remaining_queue': len(result['state']['queue']), 'unchanged_resume': True,
                             'profit_positive_cash_deferred': [{'order_id': d['order_id'], 'hour': d['hour'],
                                                               'native_profit_microUSD': d['audited_before']['summary']['profit'],
                                                               'available_microUSD': d['audited_before']['summary']['available']}
                                                              for d in positive_deferred],
                             'funding_lineage': score['funding_lineage'], 'per_order_native_profit_microUSD': score['per_order_native_profit_microUSD'],
                             'result_sha256': sha(target / 'arms' / arm / 'RESULT.json')}
            receipt['cases'].append({'id': name, 'config': read(target / 'FROZEN.json')['config'], 'arms': rows,
                                     'settled_order_delta': comparison['settled_order_delta'],
                                     'profit_delta_microUSD': comparison['profit_delta_microUSD'],
                                     'audit_sha256': sha(target / 'CAPITAL_AUDIT.json')})
            write(output / 'EXECUTION.json', receipt)
            print(json.dumps({'case': name, 'arms': {a: {k: r[k] for k in ['settled_orders', 'native_summary', 'profitable_earned_continuations']}
                                                       for a, r in rows.items()}}, sort_keys=True), flush=True)
        primary = receipt['cases'][0]['arms']['recycling_enabled']
        if not (primary['settled_orders'] == 24 and primary['repeated_earned_financed_expansion']):
            raise ValueError('REGISTERED_PRIMARY_CRITERION_NOT_MET')
        receipt['accepted'] = True
    except BaseException as error:
        receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}; raise
    finally:
        receipt['wall_seconds'] = time.monotonic() - started
        receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(output / 'EXECUTION.json', receipt)
    return receipt

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', required=True)
    run(parser.parse_args().output)
