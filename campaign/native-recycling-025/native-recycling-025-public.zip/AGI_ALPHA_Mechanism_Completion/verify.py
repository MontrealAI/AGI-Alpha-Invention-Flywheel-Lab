import json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
protocol=json.loads((root/'PROTOCOL.json').read_text())
rows=[]
for case in protocol['cases']:
 temporary=tempfile.TemporaryDirectory(prefix='native025-public-audit-')
 output=Path(temporary.name)/case['id']
 shutil.copytree(root/case['id'],output)
 shutil.copytree(root/'runtime',output/'source')
 shutil.copytree(output/'service-files',output/'source',dirs_exist_ok=True)
 run=subprocess.run([sys.executable,'-m','connected_enterprise','audit','--output',str(output)],cwd=output/'source',env={**os.environ,'PYTHONPATH':str(output/'source'),'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=180)
 if run.returncode:raise RuntimeError(case['id']+':'+run.stderr[-3000:])
 audit=json.loads(run.stdout)
 if audit['accepted'] is not True:raise ValueError('NATIVE_OR_SERVICE_AUDIT_FAILED')
 rows.append({'case':case['id'],'accepted':True,'arms':{arm:{'settled_orders':score['settled_orders'],'profit_microUSD':score['native_summary']['profit']} for arm,score in audit['arms'].items()}})
 temporary.cleanup()
print(json.dumps({'accepted':True,'scope':'Key-free native/service audits on extracted bytes; no private signing/recovery authority, annual scale or live revenue.','cases':rows},sort_keys=True))
