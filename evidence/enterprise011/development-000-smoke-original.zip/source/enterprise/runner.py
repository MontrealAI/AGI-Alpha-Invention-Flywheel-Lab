"""Freeze, execute and audit the current experiment without Git at runtime."""
import argparse
import copy
import gzip
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time
import zipfile

SCHEMA = 'agi-alpha/enterprise011-run/v1'
ROOT = Path(__file__).resolve().parents[1]


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def write_json(path, value):
    from commercial.persistence import atomic_bytes
    atomic_bytes(path, json.dumps(value, indent=2, sort_keys=True, allow_nan=False).encode() + b'\n')


def source_paths(root):
    paths = []
    for directory in ['enterprise', 'commercial', 'vendor/alpha_claim', 'portfolio_scale', 'portfolio25']:
        paths += [p for p in (root / directory).glob('*') if p.is_file() and p.suffix in {'.py', '.json', '.md'}]
    paths += [root / p for p in ['vendor/__init__.py', 'experiments/__init__.py', 'experiments/commerce006.py', 'requirements-commercial010.txt']]
    paths += list((root / 'campaign/enterprise-011').glob('*'))
    paths += list((root / 'tests').glob('test_enterprise*.py'))
    return sorted({p.relative_to(root).as_posix() for p in paths if p.is_file()})


def source_identity(root):
    files = {}
    for name in source_paths(root):
        path = root / name
        if path.is_symlink():
            raise ValueError('SOURCE_SYMLINK_REFUSED')
        files[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {'files': files, 'sha256': digest(files)}


def protocol(smoke=False):
    return {'schema': 'agi-alpha/enterprise011-confirmation/v1', 'scope': 'CONDITIONAL_SIMULATION',
            'edition': 'engineering-smoke' if smoke else 'fresh-confirmation-001',
            'seeds': [11011] if smoke else list(range(2610301101, 2610301109)),
            'development_seeds': [11011, 11012],
            'regimes': ['ordinary'] if smoke else ['ordinary', 'price_war', 'differentiation', 'correlated_shock'],
            'choice_models': ['utility'] if smoke else ['utility', 'logit'],
            'rival_models': ['responsive'] if smoke else ['responsive', 'lagged'],
            'central_region': ['ordinary', 'differentiation'], 'minimum_region_success_fraction': .75,
            'paired_control_seed_count': 1 if smoke else 2,
            'thresholds': {'cycles': 12, 'acquired_customers': 3, 'paid_jobs': 12, 'repeat_customers': 2,
                           'earned_funded_cycles': 2, 'positive_complete_cost_profit': True, 'cash_survival': True},
            'weights': 'Equal finite-design weights, not estimated real-world probabilities',
            'uncertainty': 'Wilson interval describes finite seeded simulation proportions; scenario worlds and paired arms are dependent, not an inferential sample of real buyers.',
            'selection': 'Policy and price-search procedure frozen before confirmation. No outcome-driven threshold or regime reclassification.',
            'scale_seeds': [11011] if smoke else list(range(2610302101, 2610302117))}


def freeze_run(output, smoke=False):
    output = Path(output).absolute()
    if output.exists() or output.is_symlink() or any(p.is_symlink() for p in output.parents):
        raise FileExistsError('NEW_UNSYMLINKED_OUTPUT_REQUIRED')
    output.mkdir(parents=True)
    identity = source_identity(ROOT)
    snapshot = output / 'source'
    for name in identity['files']:
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    (snapshot / 'tests/__init__.py').touch()
    if source_identity(snapshot) != identity:
        raise ValueError('SNAPSHOT_IDENTITY_MISMATCH')
    from .model import default_policy
    frozen = {'schema': SCHEMA, 'source': identity, 'protocol': protocol(smoke), 'policy': default_policy(),
              'registered_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'git_commit': None, 'model_usage': 'Code-authored deterministic service tools; no paid model calls. Host assistant billing unavailable; conditional conservative costs, never CPU-as-human-time.'}
    try:
        frozen['git_commit'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True, stderr=subprocess.DEVNULL).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass
    frozen['freeze_sha256'] = digest(frozen)
    write_json(output / 'FROZEN.json', frozen)
    return output


def wilson(successes, n):
    if not n:
        return None
    p, z = successes / n, 1.959963984540054
    d = 1 + z*z/n
    mid = (p + z*z/(2*n))/d
    half = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return [max(0, mid-half), min(1, mid+half)]


def compact(result):
    return {k: v for k, v in result.items() if k not in {'ledger', 'cycles', 'decisions', 'events', 'pricing_receipts'}}


def result_paid(result):
    return result.get('paid_jobs', result.get('settled_jobs', 0))


def result_go(result):
    return result.get('conditional_simulated_go', result.get('conditional_flywheel_succeeded', False))


def aggregate(results):
    successes = sum(result_go(r) for r in results)
    summaries = [r['ledger']['summary'] for r in results]
    return {'runs': len(results), 'successful_runs': successes, 'success_fraction': successes / len(results) if results else 0,
            'wilson_simulation_interval': wilson(successes, len(results)),
            'paid_jobs_total': sum(result_paid(r) for r in results),
            'profit_microUSD': {'minimum': min((s['profit'] for s in summaries), default=0),
                                'mean': sum(s['profit'] for s in summaries) / len(summaries) if summaries else 0,
                                'maximum': max((s['profit'] for s in summaries), default=0)},
            'cash_survival_fraction': sum(s['cash'] >= s['payables'] + s['custodyReserve'] + s['tailReserve'] + s['workingCapital'] and not s['investmentStopped'] for s in summaries) / len(summaries) if summaries else 0,
            'scope': 'Finite conditional simulation; sums across alternative worlds are not enterprise revenue.'}


def _save_result(path, result):
    raw = canonical(result)
    with path.open('xb') as stream:
        stream.write(gzip.compress(raw, mtime=0))
    return {'path': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'uncompressed_sha256': hashlib.sha256(raw).hexdigest()}


def execute_frozen(output):
    output = Path(output).absolute()
    frozen = json.loads((output / 'FROZEN.json').read_text())
    freeze_sha = frozen.pop('freeze_sha256')
    if digest(frozen) != freeze_sha or source_identity(ROOT) != frozen['source']:
        raise ValueError('FROZEN_SOURCE_OR_PROTOCOL_CHANGED')
    frozen['freeze_sha256'] = freeze_sha
    from .services import prepare_services
    from .model import run_world
    from .scale import default_config, evaluate_scale
    start, cpu = time.monotonic(), time.process_time()
    manifest_path = ROOT / 'runtime-services/MANIFEST.json'
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
    else:
        manifest = prepare_services(ROOT, 'runtime-services')
    write_json(output / 'SERVICES.json', manifest)
    p = frozen['protocol']
    results, index, compact_results = [], [], []
    results_dir = output / 'worlds'
    results_dir.mkdir(exist_ok=True)
    controls = []
    arms = ['strategic_autonomous', 'fixed_autonomous', 'strategic_original', 'fixed_original']
    tasks = []
    for seed, regime, choice, rival in itertools.product(p['seeds'], p['regimes'], p['choice_models'], p['rival_models']):
        tasks.append((seed, regime, choice, rival, arms[0], False))
    for seed, regime, choice in itertools.product(p['seeds'][:p['paired_control_seed_count']], [r for r in p['regimes'] if r in p['central_region']], p['choice_models']):
        for arm in arms[1:]:
            tasks.append((seed, regime, choice, 'responsive', arm, True))
    for seed, regime in itertools.product(p['seeds'][:p['paired_control_seed_count']], [r for r in p['regimes'] if r in p['central_region']]):
        for arm in ['strategic_no_bundle', 'strategic_fixed_allocation']:
            tasks.append((seed, regime, p['choice_models'][0], 'responsive', arm, True))
    for n, (seed, regime, choice, rival, arm, control) in enumerate(tasks):
        ident = f'{seed}-{regime}-{choice}-{rival}-{arm}'
        path = results_dir / (ident + '.json.gz')
        world_policy = copy.deepcopy(frozen['policy'])
        if arm == 'strategic_no_bundle':
            world_policy['bundle_enabled'] = False
        if arm == 'strategic_fixed_allocation':
            world_policy['dynamic_allocation'] = False
        declared_arm = next(a for a in world_policy['arms'] if a['id'] == (arms[0] if arm in {'strategic_no_bundle', 'strategic_fixed_allocation'} else arm))
        if path.exists():
            result = json.loads(gzip.decompress(path.read_bytes()))
            if result.get('policy_sha256') != digest(world_policy) or result.get('seed') != seed or result.get('regime') != regime or result.get('choice_model') != choice or result.get('competitor_model') != rival or result.get('arm') != declared_arm:
                raise ValueError('RESUME_POLICY_IDENTITY_MISMATCH')
        else:
            result = run_world(ROOT, manifest, world_policy, seed, regime, choice, declared_arm, competitor_model=rival)
            _save_result(path, result)
        record = {'id': ident, 'control': control, **_file_record(path, output)}
        index.append(record)
        brief = {'id': ident, 'control': control, **compact(result)}
        compact_results.append(brief)
        (controls if control else results).append(result)
        write_json(output / 'PROGRESS.json', {'completed': n+1, 'planned': len(tasks), 'last': ident, 'freeze_sha256': freeze_sha})
        if time.monotonic() - start > 1500 or time.process_time() - cpu > 6000:
            raise TimeoutError('REGISTERED_EVALUATION_RESOURCE_BOUNDARY; CHECKPOINT_PRESERVED')
    central = [r for r in results if r.get('regime', r.get('world')) in p['central_region']]
    grouped = {}
    for regime in p['regimes']:
        grouped[regime] = aggregate([r for r in results if r.get('regime', r.get('world')) == regime])
    central_summary = aggregate(central)
    go = central_summary['runs'] > 0 and central_summary['success_fraction'] >= p['minimum_region_success_fraction'] and central_summary['cash_survival_fraction'] == 1
    scale = evaluate_scale(default_config(), p['scale_seeds'])
    write_json(output / 'SCALE.json', scale)
    representative = next((r for r in results if result_go(r)), results[0])
    report = {'schema': SCHEMA, 'scope': 'CONDITIONAL_SIMULATION', 'source_sha256': frozen['source']['sha256'], 'freeze_sha256': freeze_sha,
              'protocol': p, 'service_count': len({j['service_id'] for j in manifest['jobs'] if j['accepted']}),
              'actual_artifacts': len(manifest['jobs']), 'central_region': central_summary, 'regimes': grouped,
              'representative': compact(representative), 'representative_ledger_summary': representative['ledger']['summary'],
              'controls': compact_results[len(results):], 'all_world_summaries': compact_results,
              'verdicts': {'executed_service_capability': 'PASS_BOUNDED_SYNTHETIC_INPUTS',
                           'conditional_simulated_commercial_flywheel': 'SUCCEEDED' if go else 'NOT_ESTABLISHED',
                           'actual_commercial_operation': 'NOT_EXECUTED', 'capability_compounding_invention': 'NOT_ESTABLISHED', 'blue_sky_enablement': 'NOT_ESTABLISHED'},
              'conclusion': 'A conditional simulated commercial flywheel succeeded under the tested central conditions.' if go else 'Current conditional criteria were not met; all trajectories retained.',
              'resource_receipt': {'worker_cpu_seconds': time.process_time()-cpu, 'worker_wall_seconds': time.monotonic()-start, 'billing': 'UNAVAILABLE', 'model_calls': 0},
              'evidence_limits': ['Demand, willingness to pay, human task hours, service latency and autonomous costs are disclosed assumptions, not observed market receipts.', 'Actual execution uses deterministic tools constructed by the assistant; no frontier provider API was called.', 'Procedurally separate checkers share authors and host; no external certification.', 'Initial seed may continue backing reserves. Earned delivery financing is separately witnessed.', 'Scale trajectories are conditional planning simulations, separate from the native audited small-cohort ledger.']}
    write_json(output / 'INDEX.json', {'freeze_sha256': freeze_sha, 'worlds': index})
    write_json(output / 'REPORT.json', report)
    write_json(output / 'COMPLETE.json', {'report_sha256': hashlib.sha256((output/'REPORT.json').read_bytes()).hexdigest(), 'source_sha256': frozen['source']['sha256'], 'completed_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
    print(json.dumps({'conclusion': report['conclusion'], 'worlds': len(tasks), 'report': str(output/'REPORT.json')}), flush=True)


def _file_record(path, root):
    return {'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}


def audit_run(output):
    output = Path(output).absolute()
    frozen = json.loads((output/'FROZEN.json').read_text())
    expected = frozen.pop('freeze_sha256')
    if digest(frozen) != expected or source_identity(output/'source') != frozen['source']:
        raise ValueError('FREEZE_OR_SOURCE_TAMPERED')
    from commercial.ledger import audit
    manifest = json.loads((output/'SERVICES.json').read_text())
    records = json.loads((output/'INDEX.json').read_text())['worlds']
    for item in records:
        path = output/item['path']
        if _file_record(path, output) != {k: item[k] for k in ['path', 'sha256', 'bytes']}:
            raise ValueError('RESULT_BYTES_CHANGED')
        result = json.loads(gzip.decompress(path.read_bytes()))
        audit(result['ledger'], root=output/'source', manifest=manifest)
    report_raw = (output/'REPORT.json').read_bytes()
    completion = json.loads((output/'COMPLETE.json').read_text())
    if hashlib.sha256(report_raw).hexdigest() != completion['report_sha256']:
        raise ValueError('REPORT_SUMMARY_TAMPERED')
    return {'accepted': True, 'source_sha256': frozen['source']['sha256'], 'world_ledgers_independently_replayed': len(records)}


def package_run(output, archive):
    output, archive = Path(output).absolute(), Path(archive).absolute()
    if archive.exists() or output in archive.parents:
        raise FileExistsError('NEW_ARCHIVE_OUTSIDE_RUN_REQUIRED')
    audit_run(output)
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(output.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and not path.is_symlink():
                z.write(path, path.relative_to(output))
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError('ARCHIVE_CRC_FAILURE')
    return {'path': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    run = sub.add_parser('run'); run.add_argument('--output', required=True); run.add_argument('--smoke', action='store_true')
    for name in ['audit', 'resume', '_worker']:
        sub.add_parser(name).add_argument('--output', required=True)
    package = sub.add_parser('package'); package.add_argument('--output', required=True); package.add_argument('--archive', required=True)
    args = parser.parse_args()
    if args.command == 'run':
        output = freeze_run(args.output, args.smoke)
        subprocess.run([sys.executable, '-m', 'enterprise', '_worker', '--output', str(output)], cwd=output/'source', check=True)
    elif args.command in {'resume', '_worker'}:
        if args.command == 'resume' and ROOT != Path(args.output).absolute()/'source':
            subprocess.run([sys.executable, '-m', 'enterprise', '_worker', '--output', str(Path(args.output).absolute())], cwd=Path(args.output).absolute()/'source', check=True)
        else:
            execute_frozen(args.output)
    elif args.command == 'audit':
        print(json.dumps(audit_run(args.output)))
    else:
        print(json.dumps(package_run(args.output, args.archive)))
