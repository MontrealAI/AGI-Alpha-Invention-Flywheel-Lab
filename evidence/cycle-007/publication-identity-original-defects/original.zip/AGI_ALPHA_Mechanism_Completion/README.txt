Original bound payload
