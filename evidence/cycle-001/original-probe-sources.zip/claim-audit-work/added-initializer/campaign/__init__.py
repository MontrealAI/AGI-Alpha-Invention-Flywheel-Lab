from pathlib import Path
Path(__file__).with_name('CLAIM_AUDIT_MARKER.txt').write_text('harmless added initializer executed')
raise RuntimeError('CLAIM_AUDIT_ADDED_INITIALIZER')
