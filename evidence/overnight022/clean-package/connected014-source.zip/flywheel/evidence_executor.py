"""Fixed narrow effect broker for validated evidence-phase plans.

Strategy evaluation runs in seccomp. This trusted broker supplies the declared
exclusive local-output effect: fixed filenames, no proposed paths or code.
It is not a general filesystem sandbox or a host-crash transaction manager.
"""
import hashlib
import json
import os
from pathlib import Path

from .strategy import validate


def execute(task, program, output, interrupt_at=None):
    validate(task, program)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    trace, files = [], {}
    for index, phase in enumerate(program['body']):
        if phase == 'reserve':
            trace.append(phase)
            continue
        try:
            filename = {'start': 'STARTED.json', 'complete': 'COMPLETE.json'}.get(phase, phase.upper() + '.json')
            leaf = output / filename
            pending = output / 'PENDING_COMPLETE.json' if phase == 'complete' else leaf
            with pending.open('x') as stream:
                if interrupt_at == phase:
                    raise KeyboardInterrupt('verifier process-interruption boundary')
                json.dump({'phase': phase, 'task': task['id']}, stream, allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            if phase == 'complete':
                os.link(pending, leaf)
            files[filename] = hashlib.sha256(leaf.read_bytes()).hexdigest()
            trace.append(phase)
        except BaseException as error:
            marked = index >= program['protected_from']
            if marked:
                leaf = output / 'INTERRUPTED.json'
                with leaf.open('x') as stream:
                    json.dump({'state': 'INCOMPLETE', 'phase': phase, 'reason': type(error).__name__}, stream)
                files[leaf.name] = hashlib.sha256(leaf.read_bytes()).hexdigest()
            return {'state': 'INCOMPLETE' if marked else 'UNMARKED', 'interrupted_marker': marked,
                    'completed': False, 'trace': trace, 'files_sha256': files, 'failure_at': phase,
                    'effect_boundary': 'Fixed trusted executor, exclusive output directory and filenames only'}
    return {'state': 'COMPLETE', 'completed': True, 'interrupted_marker': False,
            'trace': trace, 'files_sha256': files}
