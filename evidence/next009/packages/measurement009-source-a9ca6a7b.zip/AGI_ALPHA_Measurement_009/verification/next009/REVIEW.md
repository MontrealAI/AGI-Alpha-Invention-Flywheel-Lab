# Independent verification record — campaign next-009

Verifier role: `/root/verifier`. Construction was performed by other session agents. The verifier did not edit primary candidate or successor candidate code. The host, assistant model, source simulator and several Python libraries are shared; this is procedural separation, not external certification.

## Qualified primary result

The one protected primary confirmation used public source freeze `5e486d711acdd07aba3db13df38e5f57744851d0`, manifest SHA-256 `bfa8014d638d64a434c87a952b54cf586bf79419b08ab529518a041b435d88b4`. The verifier generated the seed after that freeze. Its source was frozen before these cases and has not been modified afterward.

`evidence/next009/verification/primary-confirmation/artifacts/ACCEPTANCE.json` (SHA-256 `58da3c195b1d7b22e91601d33f1434a16cfc92339db7ac6074314e6c15e60824`) accepts the Net1 plan in the declared finite model. Every one of the 36 source pairs remains distinguishable after no selected sensor is erased or any one selected sensor is erased. The four selected sensors are 13, 23, 31 and 32. Independently enumerating subsets proves minimum cardinality four. Both the independently implemented exact decoder and the actual candidate runtime passed all 72 protected observations. The runtime received observations without truth labels, in a separate process.

The exact uncalibrated witness shows sources 23 and 32 can produce identical observations at every one of the nine sensors under allowed constant offsets and bounded reading errors. The added same-sensor known-zero reference changes available information. Its error is shared across sample times; the verifier preserves this correlation through interval intersection. A conventional solver given the same additional reference information achieves the same four-sensor result. Thus the qualified claim is a causal benefit from the added measurement under specified assumptions, not superiority over conventional calibrated methods or a newly discovered mathematical technique.

The data use `canonical-json-finite-binary64-decimal-rational-v1`: canonical decimal renderings of finite parsed binary64 values are interpreted as exact rational numbers. Neither physical signal uncertainty nor simulator numerical error is certified. Unknown reference validity, time-varying bias and real contamination scenarios are outside the primary claim.

## Preserved disagreements and established defect

The original binary-rational checker produced 19 candidate disagreements among 72 exposed development observations. These are preserved under `evidence/next009/verification/runtime-adversary-v1/`. The candidate already used decimal-rational semantics. The original checker, protocol, probe and candidate source are retained under `numeric-spec-adjudication/original/`. Under the prospectively resolved decimal specification, all 19 original observations fall outside the resolved latent error envelope, and all 19 canonical counterparts pass. This was a specification disagreement, not a reproduced candidate defect within a shared specification. These development cases are not protected confirmation.

A separate genuine successor provenance defect was reproduced in `parent-binding-v1/artifacts/REPORT.json`: the original successor accepted a replacement, unverified parent compiler while retaining an old acceptance receipt. The replacement source existed only in a verifier-owned shadow root. The repaired successor binds an externally frozen parent candidate hash to both the current compiler bytes and the receipt, and verifies receipt scope. The unchanged original witness is now refused, and all three fresh regressions pass in `parent-binding-v2/artifacts/REPORT.json`. The tested original successor was recovered by an inverse patch and its SHA-256 was checked against the original probe; this recovery method is recorded rather than represented as an untouched original snapshot.

## Numerical edition and Net3

The original Net3 corpus failed the unchanged strict [0,100] input gate. It includes 1,211 simulator values slightly above 100, with maximum 100.00000000000006. That failure remains preserved and does not change Net1 qualification.

A separately identified numerical edition rounds every coordinate to 12 decimal places with ties to even, preserving all raw bytes and cohort identities. Each exact representation change must be at most `1/2000000000000` percentage points, and all transformed values must lie in [0,100]. This is a new finite numerical model, not selective clipping or a physical error guarantee.

The independent numerical checker recomputes the transform through exact integer arithmetic, without importing the adapter's Decimal arithmetic. Its all-coordinate Net3 check passed: 203,136 coordinates, 50,324 changed values, maximum exact change `1/2000000000000`, transformed range [0,100]. The receipt is `evidence/next009/verification/numeric-edition-all-coordinates/NUMERIC_CHECK.json`.

The additional Net3 derivative feasibility run was executed by the original builder with a new composition driver using frozen verifier arithmetic. Inspection of that driver found it covers all 4,186 source pairs, every one of 92 sensors, all 24 times and all 26 permitted outage states of the selected 25-sensor plan. Sensor slicing is mathematically valid because each sensor's nuisance and reference error constraints are independent coordinates of the permitted set; this does not assert probabilistic independence. The driver reports feasibility, not independent exact global optimality or a new protected runtime confirmation. Its result is retained in `evidence/next009/numeric-edition/verification-v1/artifacts/NET3_NUMERIC_FEASIBILITY.json`.

## Commercial arithmetic and claim audit

The independently implemented Decimal audit imports no candidate commercial arithmetic. All six declared scenario calculations and the final primary source/receipt bindings passed. See `evidence/next009/verification/commercial-audit/artifacts/AUDIT.json`.

The authored base scenario produces CAD 2,057.8102 accounting profit and CAD 1,557.8102 conditional earned cash after delayed receipts and modeled costs. The remaining full principal-plus-dispute reserve is CAD 3,710 and is backed by declared starting equity in the scenario. The combined demand/benefit/warranty stress loses CAD 2,388.6098. All these numbers are scenario calculations, not observed orders or measured enterprise profitability. The cohort is 20 hypothetical opportunities for the single accepted artifact, not 20 separately executed water-system jobs.

Qualified unrestricted simulated earned funds remain zero, and reinvestment is deferred. Actual matched-task human duration, complete model execution billing, enterprise cost recovery, AGI ALPHA-specific willingness to pay and empirical uptake are unestablished. The 23.4456-minute wage threshold compares human wages only with variable autonomous production cost; it does not include fixed construction or payment expense. The 194.0885-minute threshold is a sufficient modeled wage-only human loss condition under declared revenue and fees, not an observed duration or demonstrated profitability crossing.

The native protected exchange is an idealized nonrecourse simulated route. Its refusal of reversible rails is exercised. The reversible card calculation is a separate analytical model with processing fees, disputes, retained reserves and delays. Neither is a live escrow integration or actual commerce.

## Interruption and accounting limits

Four targeted early startup signal schedules passed under the unchanged wrapper, with no worker launch or surviving descendant after stop. Native resource/protocol tests also passed. These current checks do not overturn the older frozen cycle001 SIGINT timing failure.

The common resource ledger conservatively charges the full reserved CPU allowance without refunds. Wrapper waited-child CPU and supervisor CPU are reported separately, but complete process-group attribution and complete monetary cost remain unknown. The wrapper is for trusted commands and is not a sandbox. Failed and interrupted runs remain in the ledger and their artifacts are retained.

## Successor status

The original successor freeze v1 was never executed on Net2 and is preserved under `verification/next009/history/successor_v1/`. The v2 freeze adds the uniform numerical edition and independent per-coordinate verification before Net2 acquisition. Manifest SHA-256 `18fcf172156ea18ccb5c343844e160779884b3d44f8a04cfd1dae7ce7b99cb30` was published at commit `31c05cb2f698f7e5b9159774482e8a9e5278beac`; the integration owner fetched that commit and reported byte/hash verification of all 19 frozen files and the manifest before acquisition. This verifier then independently compared all 19 local files and the manifest to that fetched commit object; see `source-freeze-v2-independent/CHECK.json`. The candidate and checker were not modified after that freeze. No final seed or Net2 output was used to develop them.

The required successor endpoint is prospectively fixed: every Net2 junction as a source and sensor candidate; all 24 hourly samples; reading noise bounded by one percentage point; at most one known selected-sensor erasure; and all five drift bounds 0, 1, 5, 10 and 25 percentage points reported. Useful benefit requires an exact ambiguity in the old zero-drift plan and an accepted revised plan under the same nonzero drift obligation. Retained, equal-content ordinary reuse, reset and a separately implemented conventional multicover control remain in the comparison. No earned funding or after-cost discovery advantage is inferred from research-funded transfer.

For one sensor, let `d_t` denote the signal difference between two source hypotheses. The independent compatibility test intersects `[-2 epsilon, 2 epsilon]` with every interval `[d_t - 2(epsilon + D), d_t + 2(epsilon + D)]`. A nonempty intersection admits one shared difference of reference errors and admissible sample errors/drift under both hypotheses. An empty intersection separates the pair at that sensor. At least two selected sensors must separate each pair to tolerate one known sensor erasure. The verifier explicitly enumerates every permitted outage as an additional check. It constructs a two-truth ambiguity witness for an old-plan failure, including identical raw traces and references, permissible offsets, bounded read errors and bounded drift components.

The successor checker also binds the supplied protocol to frozen bytes, checks all three comparison arms and four fresh latent worlds per source and drift level, matches every junction in the acquired INP file to the corpus cohort, and checks the simulator identity and complete simulation receipt. Actual runtime receives observations without truth labels. `--replay-seed` preserves the same checks but marks the result `EXPOSED_REPRODUCTION_NO_NEW_CONFIRMATION` and records zero new protected worlds.

The single final successor run completed on 2026-10-30. Its acceptance receipt is `evidence/next009/verification/successor-primary-final-v2/artifacts/ACCEPTANCE.json`, SHA-256 `d98414b9a095297889f146d4b96f20209410c9e49ead66adc35aba6254bce78b`. It covers all 35 source identities, all 595 source pairs and all 24 times in the prospective Net2 numerical edition. The independent transform check covered all 29,400 coordinates; 14,705 changed under the uniform rule and the maximum exact change was `1/2000000000000`.

| Drift bound (percentage points) | Failed pair obligations in old 12-sensor plan | Revised sensors | Permitted outage states checked per revised arm | Revised result |
|---:|---:|---:|---:|---|
| 0 | 0 | 12 | 13 | All pairs pass; no unmet old-plan constraint |
| 1 | 1 | 13 | 14 | All pairs pass; exact old-plan ambiguity removed |
| 5 | 15 | 15 | 16 | All pairs pass; exact old-plan ambiguity removed |
| 10 | 16 | 15 | 16 | All pairs pass; exact old-plan ambiguity removed |
| 25 | 19 | 17 | 18 | All pairs pass; exact old-plan ambiguity removed |

At each drift level, each retained, equal-content ordinary reuse and reset arm passed all 140 fresh observations in both independent decoding and the actual candidate runtime. There were 700 distinct latent worlds, shared across the three arms, and 2,100 runtime evaluations. These are not 2,100 independent observations. All arms tie the conventional cardinality at every level. The conventional control independently constructs exact pair relations and checks its returned subset; its optimality status is reported by shared SciPy/HiGHS, not a separate exact integer certificate.

For a concrete old-plan witness at drift bound one, sources 17 and 18 generate identical raw observations at all 11 remaining selected sensors after sensor 18 is erased, with permissible noise and drift under each source truth. See `old-plan-drift-1-witness.json` in the final artifact directory (SHA-256 `dadf3bafcd8a56f1083942c70d310d83976ef62f2cbe5ee9c0aa802309acfec2`). Analogous exact witnesses are preserved at bounds 5, 10 and 25. The revised plans remove these ambiguities under the same corresponding obligations.

The final wrapper reports 69.331409 waited CPU seconds, 69.307472 wall seconds, no surviving descendants, and a conservative 600-CPU-second charge. Before admission, charged storage plus the full new 128-MiB reservation was checked at 426,948,050 bytes, below the two-GiB campaign limit. No bound was expanded.

This establishes useful fresh model transfer at the four nonzero prospective drift levels. It does not establish retained-discovery superiority, complete-cost advantage, qualified earnings or an earned-funded successor. The successor was constructed from the declared research allowance; all comparison arms tie. The connected commercial invention mission therefore remains incomplete at this evidence scope.
