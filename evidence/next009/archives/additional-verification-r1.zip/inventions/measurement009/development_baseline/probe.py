import ctypes as c, hashlib, json, itertools, time, resource
from pathlib import Path
import numpy as np
p=Path(__file__).parent
lib=c.CDLL(str(p/'libepanet22.so'))
project=c.c_uint64()
def call(name,*args):
    e=getattr(lib,'EN_'+name)(project,*args)
    if e>=100: raise RuntimeError((name,e))
    return e
e=lib.EN_createproject(c.byref(project))
if e: raise RuntimeError(e)
call('open',str(p/'Net1.inp').encode(),str(p/'probe.rpt').encode(),str(p/'probe.bin').encode())
n=c.c_int();call('getcount',0,c.byref(n))
names=[];indices=[]
for i in range(1,n.value+1):
    kind=c.c_int();call('getnodetype',i,c.byref(kind))
    if kind.value: continue
    buf=c.create_string_buffer(64);call('getnodeid',i,buf)
    names.append(buf.value.decode());indices.append(i)
call('solveH')
all_signal=[];times=[]
start=time.monotonic()
for name in names:
    call('setqualtype',3,b'',b'',name.encode())
    call('openQ');call('initQ',0)
    rows=[];ts=[]
    while True:
        t=c.c_long();call('runQ',c.byref(t));row=[]
        if t.value%3600==0 and t.value<86400:
            for i in indices:
                v=c.c_double();call('getnodevalue',i,12,c.byref(v));row.append(v.value)
            rows.append(row);ts.append(t.value)
        dt=c.c_long();call('nextQ',c.byref(dt))
        if not dt.value: break
    call('closeQ');all_signal.append(rows);times=ts
call('close');lib.EN_deleteproject(project)
a=np.array(all_signal);np.savez(p/'signal.npz',signal=a,times=times,nodes=names)
det=np.full((len(names),len(names)),max(times)*1.5)
for i,j in itertools.product(range(len(names)),repeat=2):
    hit=np.flatnonzero(a[i,:,j]>=20)
    if len(hit):det[i,j]=times[hit[0]]
rank=sorted((float(det[:,s].min(axis=1).mean()),tuple(names[x] for x in s)) for s in itertools.combinations(range(len(names)),3))
def indist(s, noise):
    return [[names[i],names[j]] for i in range(len(names)) for j in range(i+1,len(names)) if np.max(np.abs(a[i,:,s]-a[j,:,s]))<=2*noise]
stats=[]
for count in range(1,5):
    plans=sorted((len(indist(s,1)),tuple(names[x] for x in s)) for s in itertools.combinations(range(len(names)),count))
    stats.append({'count':count,'best_ambiguous_pairs_noise_pct_1':plans[0][0],'sensors':plans[0][1]})
out={'source_commit':'11eec7d5bf0a9367ffe04d75707918f0c0a890a1','scope':'DEVELOPMENT simulation of source-pinned public EPA Net1 model; no field measurement or physical certification','shape':list(a.shape),'nodes':names,'times_seconds':times,'mean_detection_optimum_3':rank[0], 'noise_1_pct_pair_plans':stats,'wall_seconds':time.monotonic()-start,'process_cpu_seconds':time.process_time(),'rusage_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'sha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in [p/'Net1.inp',p/'libepanet22.so',p/'signal.npz']}}
(p/'probe_receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
