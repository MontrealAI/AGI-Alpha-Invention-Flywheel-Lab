raise RuntimeError('unverified replacement instrument')
