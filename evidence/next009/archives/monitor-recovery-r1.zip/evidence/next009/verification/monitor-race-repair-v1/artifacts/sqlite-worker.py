import json,sqlite3,time
from pathlib import Path
root=Path('/tmp/next009-independent-monitor-y_del8yg/sqlite-monitor-run');db=root/'active.sqlite';connection=sqlite3.connect(db)
mode=connection.execute('PRAGMA journal_mode=DELETE').fetchone()[0]
connection.execute('CREATE TABLE values_table(id INTEGER PRIMARY KEY,value BLOB)')
connection.execute('INSERT INTO values_table VALUES(1,zeroblob(4096))');connection.commit()
present=absent=0
for index in range(300):
 connection.execute('BEGIN IMMEDIATE');connection.execute('UPDATE values_table SET value=randomblob(4096) WHERE id=1')
 present+=int(Path(str(db)+'-journal').is_file())
 connection.commit();absent+=int(not Path(str(db)+'-journal').exists())
 if index%10==0:time.sleep(.004)
connection.close()
(root/'CHURN.json').write_text(json.dumps({'sqlite_version':sqlite3.sqlite_version,'journal_mode':mode,'transactions':300,'journal_observed_before_commit':present,'journal_absent_after_commit':absent,'database_bytes':db.stat().st_size}))
