import importlib.util,os,signal,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('monitor_under_test','/workspace/scratch/85dffc7b798c/lab/research/next009/resource_monitor009.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
output=Path('/tmp/next009-independent-monitor-y_del8yg/SIGINT-pending_write/run');fired=False
original_mkdir=Path.mkdir;original_write=module._write
def mkdir(path,*args,**kwargs):
 global fired
 result=original_mkdir(path,*args,**kwargs)
 if path==output and 'pending_write'=='mkdir' and not fired:
  fired=True;os.kill(os.getpid(),2)
 return result
def write(path,value):
 global fired
 if path.name=='PENDING.json' and 'pending_write'=='pending_write' and not fired:
  fired=True;os.kill(os.getpid(),2)
 return original_write(path,value)
Path.mkdir=mkdir;module._write=write
result=module.run([sys.executable,'-c',"from pathlib import Path;Path('/tmp/next009-independent-monitor-y_del8yg/SIGINT-pending_write/worker-launched').write_text('ran')"],output,Path('/tmp/next009-independent-monitor-y_del8yg/SIGINT-pending_write/fixture-ledger.json'),'SIGINT-pending_write',dict(wall_seconds=2,cpu_seconds=2,memory_bytes=134217728,output_bytes=65536,storage_bytes=131072))
assert fired
assert result['receipt']['state']=='interrupted',result
assert result['receipt']['descendant_survivors'] is False,result
assert not Path('/tmp/next009-independent-monitor-y_del8yg/SIGINT-pending_write/worker-launched').exists()
